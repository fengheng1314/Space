package Space.hack.hacks.Visual;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.utils.SUtils;
import Space.hack.HackCategory;
import Space.utils.Utils;
import Space.utils.ValidUtils;
import Space.utils.ui.RenderUtils;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class Tracers extends Hack
{
    public Tracers() {
        super("Tracers", HackCategory.Visual);
    }

    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        for (final Object object : Utils.getEntityList()) {
            if (object instanceof EntityLivingBase && !(object instanceof EntityArmorStand)) {
                final EntityLivingBase entity = (EntityLivingBase)object;
                this.render(entity, SUtils.getPartialTicks(event));
            }
        }
    }

    void render(final EntityLivingBase entity, final float ticks) {
        if (ValidUtils.isValidEntity(entity) || entity == Wrapper.player()) {
            return;
        }

        if (entity.isInvisible()) {
            RenderUtils.drawTracer(entity, 0.0f, 0.0f, 0.0f, 0.5f, ticks);
            return;
        }
        if (entity.hurtTime > 0) {
            RenderUtils.drawTracer(entity, 1.0f, 0.0f, 0.0f, 1.0f, ticks);
            return;
        }
        RenderUtils.drawTracer(entity, 1.0f, 1.0f, 1.0f, 0.5f, ticks);
    }
}
