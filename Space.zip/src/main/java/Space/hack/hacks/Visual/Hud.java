package Space.hack.hacks.Visual;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.managers.HackManager;
import Space.hack.HackCategory;
import Space.value.BooleanValue;
import Space.value.Mode;
import Space.value.ModeValue;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderGameOverlayEvent;

import java.awt.*;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Hud extends Hack
{
    public ModeValue mode;
    public BooleanValue ArrayList;
    public BooleanValue Keystrokes;
    public BooleanValue ArmorHUD;
    public BooleanValue EnemyInfo;
    public static int SameColor;
    public static ArrayList<String> modexy = new ArrayList<>();
    public Hud() {
        super("Hud", HackCategory.Visual);
        this.mode = new ModeValue("Settings", new Mode("DoubleClick", true));
        this.ArrayList = new BooleanValue("ArrayList", true);
        this.Keystrokes = new BooleanValue("Keystrokes", false);
        this.ArmorHUD = new BooleanValue("ArmorHUD", false);
        this.EnemyInfo = new BooleanValue("EnemyInfo", false);
        this.addValue(this.mode, this.ArrayList, this.Keystrokes, this.ArmorHUD, this.EnemyInfo);
    }

    @Override
    public void onRenderGameOverlay(RenderGameOverlayEvent.Text event) {
        int rainbowTickc = 0;
        for (Hack h : HackManager.getSortedHacks()) {
            if (!h.isToggled()) {
                continue;
            }
            if (++rainbowTickc > 100) {
                rainbowTickc = 0;
            }
            Color rainbow = new Color(Color.HSBtoRGB((float) (Wrapper.player().ticksExisted / 50.0 - Math.sin(rainbowTickc / 40.0 * 1.4)) % 1.0f, 1.0f, 1.0f));
            SameColor = rainbow.getRGB();
        }

        if (this.ArrayList.getValue()) {
            HArrayList2();
        }

        if (this.Keystrokes.getValue()) {
            HKeystrokes2();
        }

        if (this.ArmorHUD.getValue()){
            HArmorHUD2();
        }

        if (this.EnemyInfo.getValue()){
            HEnemyInfo2(null);
        }
    }

    public static void HArrayList2(){
        String Name = "ArrayList";
        for (String line : modexy) {
            if (line.contains("[Name:" + "\"" + Name + "\"")){
                Pattern pattern = Pattern.compile("X:\"(-?\\d+(?:\\.\\d+)?)\" Y:\"(-?\\d+(?:\\.\\d+)?)\"");
                Matcher matcher = pattern.matcher(line);

                if (matcher.find()) {
                    double x = Double.parseDouble(matcher.group(1));
                    double y = Double.parseDouble(matcher.group(2));
                    HudNSDArrayList.HArrayList(x, y);
                }
            }
        }
    }

    public static void HKeystrokes2(){
        String Name = "Keystrokes";
        for (String line : modexy) {
            if (line.contains("[Name:" + "\"" + Name + "\"")){
                Pattern pattern = Pattern.compile("X:\"(-?\\d+(?:\\.\\d+)?)\" Y:\"(-?\\d+(?:\\.\\d+)?)\"");
                Matcher matcher = pattern.matcher(line);

                if (matcher.find()) {
                    double x = Double.parseDouble(matcher.group(1));
                    double y = Double.parseDouble(matcher.group(2));
                    HudNSDKeystrokes.getRenderer().renderKeystrokes((int) x, (int) y);
                }
            }
        }
    }

    public static void HEnemyInfo2(EntityPlayer target){
        String Name = "EnemyInfo";
        for (String line : modexy) {
            if (line.contains("[Name:" + "\"" + Name + "\"")) {
                Pattern pattern = Pattern.compile("X:\"(-?\\d+(?:\\.\\d+)?)\" Y:\"(-?\\d+(?:\\.\\d+)?)\"");
                Matcher matcher = pattern.matcher(line);

                if (matcher.find()) {
                    double x = Double.parseDouble(matcher.group(1));
                    double y = Double.parseDouble(matcher.group(2));
                    HudNSDEnemyInfo.HEnemyInfo(x, y, target);
                }
            }
        }
    }

    public static void HArmorHUD2() {
        final Hack hack = HackManager.getHack("HudNSDArmorHUD");

        if (hack.isBooleanValue("AutoPos")) {
            HudNSDArmorHUD.HArmorHUD(0.0, 0.0, true);
        }else {
            HArmorHUD3();
        }
    }

    public static void HArmorHUD3(){
        String Name = "ArmorHUD";
        for (String line : modexy) {
            if (line.contains("[Name:" + "\"" + Name + "\"")) {
                Pattern pattern = Pattern.compile("X:\"(-?\\d+(?:\\.\\d+)?)\" Y:\"(-?\\d+(?:\\.\\d+)?)\"");
                Matcher matcher = pattern.matcher(line);

                if (matcher.find()) {
                    double x = Double.parseDouble(matcher.group(1));
                    double y = Double.parseDouble(matcher.group(2));
                    HudNSDArmorHUD.HArmorHUD(x, y, false);
                }
            }
        }
    }

}
