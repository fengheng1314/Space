package Space.hack.hacks.Visual;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Space.hack.HackCategory;
import Space.utils.Utils;
import Space.value.NumberValue;
import net.minecraft.client.settings.GameSettings;

public class Fov extends Hack
{
    public NumberValue FOV;
    private float oldFov = 0F;
    public Fov() {
        super("Fov", HackCategory.Visual);
        this.FOV = new NumberValue("FOV", 113.0,50.0,130.0);
        this.addValue(this.FOV);
    }

    @Override
    public void onEnable() {
        if (!Utils.isPlayerInGame()) return;

        oldFov = Wrapper.mc().gameSettings.getOptionFloatValue(GameSettings.Options.FOV);
        Wrapper.mc().gameSettings.fovSetting = FOV.getValue().floatValue();
    }

    @Override
    public void onDisable() {
        if (!Utils.isPlayerInGame()) return;

        Wrapper.mc().gameSettings.fovSetting = oldFov;
    }



}