package Space.hack.hacks.Visual;

import Nirvana.hack.Hack;
import Space.hack.HackCategory;
import Space.hack.hacks.Visual.UI.keystrokesmod.KeystrokesRenderer;
import Space.value.BooleanValue;
import Space.value.NumberValue;

public class HudNSDKeystrokes extends Hack
{
    public BooleanValue Mouse;
    public BooleanValue TitleRainbow;
    public NumberValue TitleRed;
    public NumberValue TitleGreen;
    public NumberValue TitleBlue;
    public BooleanValue ShadeDefault;
    public NumberValue ShadeRed;
    public NumberValue ShadeGreen;
    public NumberValue ShadeBlue;

    private static KeystrokesRenderer renderer;
    public HudNSDKeystrokes() {
        super("HudNSDKeystrokes", HackCategory.None, true);
        this.Mouse = new BooleanValue("Mouse", true);
        this.TitleRainbow = new BooleanValue("TitleRainbow", false);
        this.TitleRed = new NumberValue("TitleRed", 84.0,0.0,255.0);
        this.TitleGreen = new NumberValue("TitleGreen", 255.0,0.0,255.0);
        this.TitleBlue = new NumberValue("TitleBlue", 159.0,0.0,255.0);
        this.ShadeDefault = new BooleanValue("ShadeDefault", false);
        this.ShadeRed = new NumberValue("ShadeRed", 79.0,0.0,255.0);
        this.ShadeGreen = new NumberValue("ShadeGreen", 79.0,0.0,255.0);
        this.ShadeBlue = new NumberValue("ShadeBlue", 79.0,0.0,255.0);
        this.addValue(this.Mouse, this.TitleRainbow, this.TitleRed, this.TitleGreen, this.TitleBlue, this.ShadeDefault, this.ShadeRed, this.ShadeGreen, this.ShadeBlue);
        HudNSDKeystrokes.renderer = new KeystrokesRenderer();
    }

    public static KeystrokesRenderer getRenderer() {
        return HudNSDKeystrokes.renderer;
    }
}