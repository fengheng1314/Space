package Space.hack.hacks.Visual;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SHudNSDArmorHUD;
import Space.hack.HackCategory;
import Space.value.BooleanValue;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.item.ItemStack;

public class HudNSDArmorHUD extends Hack
{
    public BooleanValue AutoPos;
    public HudNSDArmorHUD() {
        super("HudNSDArmorHUD", HackCategory.None, true);
        this.AutoPos = new BooleanValue("AutoPos", true);
        this.addValue(this.AutoPos);
    }

    public static void HArmorHUD(double X, double Y, Boolean AutoPos){
        final ScaledResolution resolution = new ScaledResolution(Wrapper.mc());
        SHudNSDArmorHUD.itemRender();
        GlStateManager.enableTexture2D();
        final int i = AutoPos ? resolution.getScaledWidth() / 2 : (int) X;
        int iteration = 0;
        final int y = AutoPos ? resolution.getScaledHeight() - 55 - (Wrapper.player().isInWater() ? 10 : 0) : (int) Y;
        for (final ItemStack is : Wrapper.player().inventory.armorInventory) {
            ++iteration;
            if (is == null) {
                continue;
            }
            final int x = i - 90 + (9 - iteration) * 20 + 2;
            GlStateManager.pushMatrix();
            GlStateManager.popMatrix();
            GlStateManager.enableDepth();
            SHudNSDArmorHUD.itemRender.zLevel = 200.0f;
            SHudNSDArmorHUD.itemRender.renderItemAndEffectIntoGUI(is, x, y);
            SHudNSDArmorHUD.itemRender.renderItemOverlayIntoGUI(Wrapper.fontRenderer(), is, x, y, "");
            SHudNSDArmorHUD.itemRender.zLevel = 0.0f;
            GlStateManager.enableTexture2D();
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            final String s = SHudNSDArmorHUD.Strings(is);
            Wrapper.fontRenderer().drawStringWithShadow(s, (float)(x + 19 - 2 - Wrapper.fontRenderer().getStringWidth(s)), (float)(y + 9), 16777215);
            GlStateManager.enableDepth();
            GlStateManager.disableLighting();
        }
    }

}
