package Space.hack.hacks.Visual;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SHudNSDEnemyInfo;
import Nirvana.managers.HackManager;
import Space.hack.HackCategory;
import Space.utils.Utils;
import Space.utils.ValidUtils;
import Space.utils.ui.RenderUtils;
import Space.value.BooleanValue;
import Space.value.NumberValue;
import net.minecraft.client.gui.Gui;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class HudNSDEnemyInfo extends Hack
{
    public BooleanValue HealthRainbow;
    public NumberValue HealthRed;
    public NumberValue HealthGreen;
    public NumberValue HealthBlue;
    public NumberValue MaxFov;
    public NumberValue MaxRange;
    public HudNSDEnemyInfo() {
        super("HudNSDEnemyInfo", HackCategory.None);
        this.MaxFov = new NumberValue("MaxFov", 80.0,20.0,100.0);
        this.MaxRange = new NumberValue("MaxRange", 4.0,3.0,6.0);
        this.HealthRainbow = new BooleanValue("HealthRainbow", false);
        this.HealthRed = new NumberValue("HealthRed", 84.0,0.0,255.0);
        this.HealthGreen = new NumberValue("HealthGreen", 255.0,0.0,255.0);
        this.HealthBlue = new NumberValue("HealthBlue", 159.0,0.0,255.0);
        //old 255 88 41
        this.addValue(this.MaxFov, this.MaxRange, this.HealthRainbow, this.HealthRed, this.HealthGreen, this.HealthBlue);
    }


    public static void HEnemyInfo(double X, double Y, EntityPlayer target){
        EntityPlayer Target = null;
        if (Utils.IsNull(target)){
            Hack hack = HackManager.getHack("HudNSDEnemyInfo");
            Target = (EntityPlayer) ValidUtils.killAuraUpdate("RangeX", hack.isNumberValue("MaxFov"), hack.isNumberValue("MaxRange"), Target, "Players");
        }else {
            Target = target;
        }

        if (Utils.IsNull(Target)){
            return;
        }

        float Health = Target.getHealth() < 0 ? 0 : Target.getHealth();
        Wrapper.fontRenderer().drawString(Target.getName(), (int) X, (int) Y - 10, new Color(255,255,255).getRGB());
        Wrapper.fontRenderer().drawString("Distanse: " + SHudNSDEnemyInfo.Distanse(Target),(int) X + 1, (int) Y, new Color(255,255,255).getRGB());
        Wrapper.fontRenderer().drawString("HP: " + Math.round(Health), (int) X + 1, (int) Y + 10, new Color(255,255,255).getRGB());
        drawHead(SHudNSDEnemyInfo.drawHead(Target), (int) X - 31, (int) Y - 9, 28, 28, 1F);
        RenderUtils.drawBorderedRect((int) X - 45 + ((Health > 20 ? 20 : Health) < 4 ? 15 : (Health > 20 ? 20 : Health)*6), (int) Y + 21, (int) X - 31, (int) Y + 19.98, HackManager.getHack("HudNSDEnemyInfo").isBooleanValue("HealthRainbow") ? Hud.SameColor :new Color(HackManager.getHack("HudNSDEnemyInfo").isNumberValue("HealthRed").intValue(), HackManager.getHack("HudNSDEnemyInfo").isNumberValue("HealthGreen").intValue(), HackManager.getHack("HudNSDEnemyInfo").isNumberValue("HealthBlue").intValue()).getRGB());
    }

    private static void drawHead(ResourceLocation skin, int x, int y, int width, int height, float alpha) {
        GL11.glColor4f(1F, 1F, 1F, alpha);
        Wrapper.mc().getTextureManager().bindTexture(skin);
        Gui.drawScaledCustomSizeModalRect(x, y, 8F, 8F, 8, 8, width, height, 64F, 64F);
    }

}
