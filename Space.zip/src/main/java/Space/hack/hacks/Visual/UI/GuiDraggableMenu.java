package Space.hack.hacks.Visual.UI;

import Nirvana.Wrapper;
import Nirvana.managers.HackManager;
import Space.hack.hacks.Visual.Hud;
import Space.managers.FileManager;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;

public class GuiDraggableMenu extends GuiScreen {
    private int posX, posY;
    private int lastMouseX, lastMouseY;
    private final String Name;
    public GuiDraggableMenu(String name) {
        FileManager.loadHud(name);
        this.Name = name;
    }

    @Override
    public void initGui() {
        super.initGui();
    }

    @Override
    public void onGuiClosed() {
        HackManager.getHack("Hud").setToggledD(true);
        FileManager.saveHud();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        super.drawScreen(mouseX, mouseY, partialTicks);
        if (this.Name.contains("ArrayList")){
            Hud.HArrayList2();
        }else if (this.Name.contains("Keystrokes")){
            Hud.HKeystrokes2();
        }else if (this.Name.contains("ArmorHUD")){
            Hud.HArmorHUD2();
        }else if (this.Name.contains("EnemyInfo")){
            Hud.HEnemyInfo2(Wrapper.player());
        }

    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);

        if (mouseX >= posX && mouseY >= posY && mouseX < posX + 100 && mouseY < posY + 20) {
            lastMouseX = mouseX;
            lastMouseY = mouseY;

        }
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        super.mouseClickMove(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);

        posX += mouseX - lastMouseX;
        posY += mouseY - lastMouseY;
        lastMouseX = mouseX;
        lastMouseY = mouseY;
        FileManager.SetHud(Name ,String.valueOf(posX), String.valueOf(posY));

    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        super.actionPerformed(button);
    }
}
