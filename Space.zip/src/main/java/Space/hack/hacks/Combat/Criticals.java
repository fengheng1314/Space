package Space.hack.hacks.Combat;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.utils.SPacket;
import Nirvana.utils.SUtils;
import Space.hack.HackCategory;
import Space.value.Mode;
import Space.value.ModeValue;
import Space.value.NumberValue;
import net.minecraftforge.event.entity.player.AttackEntityEvent;

public class Criticals extends Hack {
    public ModeValue mode;
    public NumberValue delay;
    public int ticks = 0;

    public Criticals() {
        super("Criticals", HackCategory.Combat);
        this.mode = new ModeValue("Mode", new Mode("Packet", true), new Mode("LPacket", false), new Mode("Hypixel", false), new Mode("Visual", false),new Mode("Jump", false),new Mode("LowJump", false));
        this.delay = new NumberValue("Delay", 3.0,0.0,20.0);
        this.addValue(this.mode,this.delay);
    }

    @Override
    public void onAttackEntity(final AttackEntityEvent event) {
        if(!Wrapper.player().onGround || Wrapper.player().isOnLadder() || Wrapper.player().isInWater() || Wrapper.player().isInLava()){
            return;
        }
        ++this.ticks;
        if (this.ticks >= delay.getValue()){
            if(this.mode.getMode("Visual").isToggled()){
                Wrapper.player().onCriticalHit(SUtils.getTarget(event));
            } else if(this.mode.getMode("Jump").isToggled()){
                Wrapper.player().motionY = 0.42;
            } else if(this.mode.getMode("LowJump").isToggled()){
                Wrapper.player().motionY = 0.3425;
            }else if(this.mode.getMode("Packet").isToggled()){
                double x = Wrapper.player().posX;
                double y = Wrapper.player().posY;
                double z = Wrapper.player().posZ;
                Wrapper.sendPacket(SPacket.CPacketPlayerPosition(x, y + 0.0625, z, true));
                Wrapper.sendPacket(SPacket.CPacketPlayerPosition(x, y, z, false));
                Wrapper.sendPacket(SPacket.CPacketPlayerPosition(x, y + 1.1E-5, z, false));
                Wrapper.sendPacket(SPacket.CPacketPlayerPosition(x, y, z, false));
                Wrapper.player().onCriticalHit(SUtils.getTarget(event));
            }else if(this.mode.getMode("LPacket").isToggled()){
                Wrapper.sendPacket(SPacket.CPacketPlayerPosition(Wrapper.player().posX, Wrapper.player().posY + 0.0627D, Wrapper.player().posZ, false));
                Wrapper.player().onCriticalHit(SUtils.getTarget(event));
            }else if(this.mode.getMode("Hypixel").isToggled()){
                double x = Wrapper.player().posX;
                double y = Wrapper.player().posY;
                double z = Wrapper.player().posZ;
                Wrapper.sendPacket(SPacket.CPacketPlayerPosition(x, y + 0.0123237654168D, z, false));
                Wrapper.sendPacket(SPacket.CPacketPlayerPosition(x, y + 0.0128372365D, z, false));
                Wrapper.sendPacket(SPacket.CPacketPlayerPosition(x, y + 0.0923129837D, z, false));
                Wrapper.sendPacket(SPacket.CPacketPlayerPosition(x, y, z, false));
                Wrapper.player().onCriticalHit(SUtils.getTarget(event));
            }
            this.ticks = 0;
        }
    }
}
