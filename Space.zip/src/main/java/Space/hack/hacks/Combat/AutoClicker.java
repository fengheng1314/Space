package Space.hack.hacks.Combat;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Space.hack.HackCategory;
import Space.utils.TimerUtils;
import Space.utils.Utils;
import Space.value.BooleanValue;
import Space.value.NumberValue;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.RenderGameOverlayEvent;

public class AutoClicker extends Hack {
    public TimerUtils Righttimer;
    public TimerUtils Lefttimer;
    public BooleanValue NoCapped;
    public NumberValue MaxRightCPS;
    public NumberValue MaxLeftCPS;
    public NumberValue MinRightCPS;
    public NumberValue MinLeftCPS;
    public BooleanValue RightClick;
    public BooleanValue LeftClick;

    public AutoClicker() {
        super("AutoClicker", HackCategory.Combat);
        this.RightClick = new BooleanValue("RightClick", true);
        this.MaxRightCPS = new NumberValue("MaxRightCPS", 8.0, 1.0, 90.0);
        this.MinRightCPS = new NumberValue("MinRightCPS", 6.0, 1.0, 89.0);

        this.LeftClick = new BooleanValue("LeftClick", true);
        this.MaxLeftCPS = new NumberValue("MaxLeftCPS", 8.0, 1.0, 90.0);
        this.MinLeftCPS = new NumberValue("MinLeftCPS", 6.0, 1.0, 89.0);

        this.NoCapped = new BooleanValue("NoCapped", false);

        this.addValue(this.RightClick, this.MaxRightCPS, this.MinRightCPS, this.LeftClick, this.MaxLeftCPS, this.MinLeftCPS, this.NoCapped);
        this.Righttimer = new TimerUtils();
        this.Lefttimer = new TimerUtils();
    }

    @Override
    public void onRenderGameOverlay(RenderGameOverlayEvent.Text event) {
        if (Wrapper.mc().gameSettings.keyBindAttack.isKeyDown() && this.RightClick.getValue()) {
            if (!NoCapped.getValue()){
            int i = Utils.random(this.MinRightCPS.getValue().intValue() ,this.MaxRightCPS.getValue().intValue());
            int j = Utils.random(1, 50);
            int k = Utils.random(1, 60);
            int l = Utils.random(1, 70);


            if (this.Righttimer.isDelay(((1000 + j - k + l) / i))) {
                KeyBinding.onTick(Wrapper.mc().gameSettings.keyBindAttack.getKeyCode());
                this.Righttimer.setLastMS();
            }
        }else {
                KeyBinding.onTick(Wrapper.mc().gameSettings.keyBindAttack.getKeyCode());
            }

        }else if (Wrapper.mc().gameSettings.keyBindUseItem.isKeyDown() && this.LeftClick.getValue()) {
            if (!NoCapped.getValue()){
                int i = Utils.random(this.MinLeftCPS.getValue().intValue() ,this.MaxLeftCPS.getValue().intValue());
                int j = Utils.random(1, 50);
                int k = Utils.random(1, 60);
                int l = Utils.random(1, 70);


                if (this.Lefttimer.isDelay(((1000 + j - k + l) / i))) {
                    KeyBinding.onTick(Wrapper.mc().gameSettings.keyBindUseItem.getKeyCode());
                    this.Lefttimer.setLastMS();
                }
            }else {
                KeyBinding.onTick(Wrapper.mc().gameSettings.keyBindUseItem.getKeyCode());
            }
        }
    }


}