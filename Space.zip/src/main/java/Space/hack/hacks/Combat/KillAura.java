package Space.hack.hacks.Combat;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.utils.SPacket;
import Nirvana.utils.SUtils;
import Space.hack.HackCategory;
import Space.utils.TimerUtils;
import Space.utils.Utils;
import Space.utils.ValidUtils;
import Space.utils.ui.RenderUtils;
import Space.value.BooleanValue;
import Space.value.Mode;
import Space.value.ModeValue;
import Space.value.NumberValue;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.EntityLivingBase;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class KillAura extends Hack {
    public static EntityLivingBase target = null;
    public ModeValue mode;
    public ModeValue priority;
    public NumberValue MaxCPS;
    public NumberValue MinCPS;
    public NumberValue FOV;
    public TimerUtils timer;
    public NumberValue range;
    public ModeValue Circle;
    public ModeValue Mark;
    public ModeValue AutoBlock;
    public NumberValue HurtTime;
    public NumberValue Delay;
    public BooleanValue Swing;
    public ModeValue Rotation;
    public NumberValue speed;
    public BooleanValue AutoAttack;
    public BooleanValue Admin;
    public BooleanValue ThirdPersonView;
    public int ticks;
    public TimerUtils tim;
    public KillAura() {
        super("KillAura", HackCategory.Combat, false);
        this.Mark = ValidUtils.isMark();
        this.Circle = ValidUtils.isCircle();
        this.priority = ValidUtils.isPriority("Priority");
        this.MaxCPS = new NumberValue("MaxCPS", 8.0, 1.0, 30.0);
        this.MinCPS = new NumberValue("MinCPS", 5.0, 1.0, 29.0);
        this.HurtTime = new NumberValue("HurtTime", 10.0,0.0,10.0);
        this.range = new NumberValue("Range", 4.4, 1.0, 8.0);
        this.Delay = new NumberValue("Delay", 0.0, 0.0, 3.0);
        this.Swing = new BooleanValue("Swing", true);
        this.Admin = new BooleanValue("Admin", false);
        this.AutoAttack = new BooleanValue("AutoAttack", false);
        this.mode = new ModeValue("AttackMethod", new Mode("Packet", true), new Mode("AttackEntity", false));
        this.AutoBlock = new ModeValue("AutoBlock", new Mode("onTick", true), new Mode("Off", false));
        this.ThirdPersonView = new BooleanValue("ThirdPersonView", false);
        this.Rotation = new ModeValue("Rotation", new Mode("AAC", true), new Mode("Galacticc", false), new Mode("Raven", false), new Mode("Raven2", false), new Mode("Legit", false), new Mode("Legit2", false), new Mode("Not", false), new Mode("Lock", false));
        this.speed = new NumberValue("RotationSpeed", 1.0, 1.0, 15.0);
        this.FOV = new NumberValue("FOV", 180.0, 1.0, 360.0);
        this.addValue(this.MaxCPS, this.MinCPS, this.HurtTime, this.range, this.Delay, this.Swing, this.Admin, this.AutoAttack, this.priority, this.mode, this.AutoBlock, this.ThirdPersonView, this.Rotation, this.speed, this.FOV, this.Mark, this.Circle);
        this.timer = new TimerUtils();
        this.tim = new TimerUtils();
        this.ticks = 0;
    }

    @Override
    public void onEnable() {
        this.ticks = 0;
        target = null;
    }

    @Override
    public void onDisable() {
        if (this.ThirdPersonView.getValue()){
            Wrapper.mc().gameSettings.thirdPersonView = 0;
        }
    }

    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        target = ValidUtils.killAuraUpdate(this.priority.getModeToggled(), this.FOV.getValue(), this.range.getValue(), target, "All");

        if (Utils.IsNull(target)){
            if (this.ThirdPersonView.getValue()){
                Wrapper.mc().gameSettings.thirdPersonView = 0;
            }
            AutoBlockSx(false);
            return;
        }

        if (this.ThirdPersonView.getValue()){
            Wrapper.mc().gameSettings.thirdPersonView = 3;
        }

        if (Rotation.getMode("Raven").isToggled()) {
            float lastYaw = Utils.getTargetRotations(target)[0];
            Wrapper.player().setRotationYawHead(lastYaw);
            Wrapper.player().renderYawOffset = lastYaw;
        }else if (Rotation.getMode("Legit").isToggled()) {
            float lastYaw = Utils.getYaw(target);
            Wrapper.player().setRotationYawHead(lastYaw);
            Wrapper.player().renderYawOffset = lastYaw;
            Wrapper.player().rotationYaw = lastYaw;
        }else if (Rotation.getMode("Legit2").isToggled()) {
            float lastYaw = Utils.getYaw(target);
            Wrapper.player().setRotationYawHead(lastYaw);
            Wrapper.player().renderYawOffset = lastYaw;
            Wrapper.player().rotationYaw = lastYaw;
            Wrapper.player().rotationPitch = Utils.getPitch(target);
        }else if (Rotation.getMode("Galacticc").isToggled()) {
            float lastYaw = Utils.getRotations(target)[0];
            Wrapper.player().setRotationYawHead(lastYaw);
            Wrapper.player().renderYawOffset = lastYaw;
        }else if (Rotation.getMode("Raven2").isToggled()) {
            float lastYaw = Utils.getTargetRotations2(target)[0];
            Wrapper.player().setRotationYawHead(lastYaw);
            Wrapper.player().renderYawOffset = lastYaw;
        }else if (Rotation.getMode("AAC").isToggled()) {
            float lastYaw = Utils.getRotationsNeeded(target)[0];
            Wrapper.player().setRotationYawHead(lastYaw);
            Wrapper.player().renderYawOffset = lastYaw;
        }

        if (!this.ThirdPersonView.getValue()) {
            int i = Utils.random(this.speed.getValue().intValue(), this.speed.getValue().intValue() + 1);
            int j = Utils.random(1, 50);
            int k = Utils.random(1, 60);
            int l = Utils.random(1, 70);

            if (this.tim.isDelay(((1000 + j - k + l) / i))) {
                AutoRotation();
                this.tim.setLastMS();
            }
        }

        if (this.Admin.getValue()) {
            AutoBlockSx(true);
            Utils.attack(target);
            Wrapper.sendPacket(SPacket.CPacketUseEntity(target));
            target = null;

        }else if (this.AutoAttack.getValue()) {
            if (SUtils.AttackCooldown()) {
                this.processAttack();
                target = null;
            }
        }else{
            int i1 = Utils.random(this.MinCPS.getValue().intValue() ,this.MaxCPS.getValue().intValue());
            int j1 = Utils.random(1, 50);
            int k1 = Utils.random(1, 60);
            int l1 = Utils.random(1, 70);

            if (this.timer.isDelay(((1000 + j1 - k1 + l1) / i1))) {
                this.processAttack();
                target = null;
                this.timer.setLastMS();
            }
        }

    }

    public void AutoRotation() {
        if (Rotation.getMode("Raven").isToggled()) {
            float lastYaw = Utils.getTargetRotations(target)[0];
            float lastPitch = Utils.getTargetRotations(target)[1];
            this.SetRotation(lastYaw, lastPitch);
        }else if (Rotation.getMode("Galacticc").isToggled()) {
            float lastYaw = Utils.getRotations(target)[0];
            float lastPitch = Utils.getRotations(target)[1];
            this.SetRotation(lastYaw, lastPitch);
        }else if (Rotation.getMode("Raven2").isToggled()) {
            float lastYaw = Utils.getTargetRotations2(target)[0];
            float lastPitch = Utils.getTargetRotations2(target)[1];
            this.SetRotation(lastYaw, lastPitch);
        }else if (Rotation.getMode("AAC").isToggled()) {
            float lastYaw = Utils.getRotationsNeeded(target)[0];
            float lastPitch = Utils.getRotationsNeeded(target)[1];
            this.SetRotation(lastYaw, lastPitch);
        }
    }

    public void SetRotation(float submitYaw ,float submitPitch) {
        Wrapper.sendPacket(SPacket.CPacketPlayerPositionRotation(Wrapper.player().posX, Wrapper.player().getEntityBoundingBox().minY, Wrapper.player().posZ, submitYaw, submitPitch, Wrapper.player().onGround));
    }

    public void AutoBlockSx(boolean good){
        if (AutoBlock.getMode("Off").isToggled()) {return;}

            if (good && AutoBlock.getMode("onTick").isToggled()) {
                KeyBinding.onTick(Wrapper.mc().gameSettings.keyBindUseItem.getKeyCode());
        }
    }

    public void processAttack() {
        if(this.ticks >= this.Delay.getValue()){
            AutoBlockSx(true);

            if (this.Swing.getValue()){
                Utils.swing();
            }

            if (mode.getMode("AttackEntity").isToggled()) {
                Utils.attack(target);
            }else if (mode.getMode("Packet").isToggled()) {
                Wrapper.sendPacket(SPacket.CPacketUseEntity(target));
            }

            this.timer.setLastMS();
            this.ticks = 0;
        }

        ++this.ticks;
    }

    @Override
    public void onRenderGameOverlay(RenderGameOverlayEvent.Text event) {
        if (Utils.IsNull(target)){return;}
        if (Rotation.getMode("Lock").isToggled() || this.ThirdPersonView.getValue()) {
            if (Rotation.getMode("Raven").isToggled()) {
                Wrapper.player().rotationYaw = Utils.getTargetRotations(target)[0];
            }else if (Rotation.getMode("Legit").isToggled() || Rotation.getMode("Lock").isToggled()) {
                Wrapper.player().rotationYaw = Utils.getYaw(target);
            }else if (Rotation.getMode("Legit2").isToggled()) {
                Wrapper.player().rotationYaw = Utils.getYaw(target);
                Wrapper.player().rotationPitch = Utils.getPitch(target);
            } else if (Rotation.getMode("Galacticc").isToggled()) {
                Wrapper.player().rotationYaw = Utils.getRotations(target)[0];
            }else if (Rotation.getMode("Raven2").isToggled()) {
                Wrapper.player().rotationYaw = Utils.getTargetRotations2(target)[0];
            }else if (Rotation.getMode("AAC").isToggled()) {
                Wrapper.player().rotationYaw = Utils.getRotationsNeeded(target)[0];
            }
        }

    }

    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        RenderUtils.SCircle(this.onToggledMode("Circle"), target, event);
        RenderUtils.SMark(this.onToggledMode("Mark"), target, event);
    }

}
