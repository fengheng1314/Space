package Space.hack.hacks.Combat;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.utils.SPacket;
import Nirvana.utils.SUtils;
import Space.hack.HackCategory;
import Space.utils.Utils;
import Space.value.BooleanValue;
import Space.value.Mode;
import Space.value.ModeValue;
import Space.value.NumberValue;
import net.minecraftforge.event.entity.player.AttackEntityEvent;

public class SuperKnockback extends Hack {
    public ModeValue mode;
    public BooleanValue OnlyGround;
    public BooleanValue OnlyMove;
    public NumberValue HurtTime;
    public SuperKnockback() {
        super("SuperKnockback", HackCategory.Combat);
        this.mode = new ModeValue("Mode", new Mode("Sprint-Packet", true), new Mode("Sneak-Packet", false), new Mode("W-Tap", false));
        this.HurtTime = new NumberValue("HurtTime", 10.0,0.0,10.0);
        this.OnlyGround = new BooleanValue("OnlyGround", false);
        this.OnlyMove = new BooleanValue("OnlyMove", false);
        this.addValue(this.mode, this.HurtTime, this.OnlyGround, this.OnlyMove);
    }
    @Override
    public void onAttackEntity(final AttackEntityEvent event) {
        if (SUtils.getTarget(event).hurtResistantTime > this.HurtTime.getValue() || (this.OnlyGround.getValue() && !Wrapper.player().onGround) || (this.OnlyMove.getValue() && !Utils.isMoving())){
            return;
        }
        if (mode.getMode("Sprint-Packet").isToggled()) {
            if (Wrapper.player().isSprinting()){
                Wrapper.sendPacket(SPacket.CPacketEntityAction(Wrapper.player(), SPacket.CPacketEntityAction_STOP_SPRINTING()));
                Wrapper.sendPacket(SPacket.CPacketEntityAction(Wrapper.player(), SPacket.CPacketEntityAction_START_SPRINTING()));
                Wrapper.sendPacket(SPacket.CPacketEntityAction(Wrapper.player(), SPacket.CPacketEntityAction_STOP_SPRINTING()));
                Wrapper.sendPacket(SPacket.CPacketEntityAction(Wrapper.player(), SPacket.CPacketEntityAction_START_SPRINTING()));
                Wrapper.player().setSprinting(true);
            }
        }else if (mode.getMode("Sneak-Packet").isToggled()) {
            if (Wrapper.player().isSprinting()) {
                Wrapper.sendPacket(SPacket.CPacketEntityAction(Wrapper.player(), SPacket.CPacketEntityAction_STOP_SNEAKING()));
            }
                Wrapper.sendPacket(SPacket.CPacketEntityAction(Wrapper.player(), SPacket.CPacketEntityAction_START_SNEAKING()));
                Wrapper.sendPacket(SPacket.CPacketEntityAction(Wrapper.player(), SPacket.CPacketEntityAction_STOP_SNEAKING()));
        }else if (mode.getMode("W-Tap").isToggled()) {
            if (Wrapper.player().isSprinting()) {
                Wrapper.player().setSprinting(false);
            }
            Wrapper.player().setSprinting(true);
            Wrapper.player().setSprinting(false);
            Wrapper.player().setSprinting(true);
        }
        
    }
    
}
