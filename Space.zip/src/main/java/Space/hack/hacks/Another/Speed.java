package Space.hack.hacks.Another;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Space.hack.HackCategory;
import Space.utils.Utils;
import Space.value.Mode;
import Space.value.ModeValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Speed extends Hack {
    public ModeValue mode;
    int LBasicTick = 0;

    public Speed() {
        super("Speed", HackCategory.Another, false);
        this.mode = new ModeValue("Mode", new Mode("HYT", true), new Mode("4JUMP", false), new Mode("5JUMP", false), new Mode("HYTS", false), new Mode("Basic", false), new Mode("LBasic", false));
        this.addValue(this.mode);
    }

    @Override
    public void onEnable() {
        this.LBasicTick = 0;
    }

    @Override
    public void onInputUpdate(final Object event) {
        if (this.mode.getMode("HYT").isToggled() || this.mode.getMode("HYTS").isToggled() || this.mode.getMode("5JUMP").isToggled() || this.mode.getMode("4JUMP").isToggled()) {
            if (Wrapper.player().movementInput.moveForward > 0 || Wrapper.player().movementInput.moveStrafe > 0) {
                if (Wrapper.player().onGround) {
                    Wrapper.player().jump();
                    if (this.mode.getMode("HYTS").isToggled() || this.mode.getMode("5JUMP").isToggled() || this.mode.getMode("4JUMP").isToggled()){
                        Wrapper.player().jump();
                        if (this.mode.getMode("5JUMP").isToggled() || this.mode.getMode("4JUMP").isToggled()){
                            Wrapper.player().jump();
                            Wrapper.player().jump();
                            if (this.mode.getMode("5JUMP").isToggled()){
                                Wrapper.player().jump();
                            }
                        }
                    }
                }
            }
        }

    }

    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (this.mode.getMode("Basic").isToggled() || this.mode.getMode("LBasic").isToggled()) {
            final boolean boost = Math.abs(Wrapper.player().rotationYawHead - Wrapper.player().rotationYaw) < 90.0f;
            if (Wrapper.player().moveForward > 0.0f && Wrapper.player().hurtTime < 5) {
                if (Wrapper.player().onGround) {
                    Wrapper.player().motionY = 0.405;
                    final float f = Utils.getDirection();
                    final EntityPlayerSP player = Wrapper.player();
                    player.motionX -= Math.sin(f) * 0.2f;
                    final EntityPlayerSP player2 = Wrapper.player();
                    player2.motionZ += Math.cos(f) * 0.2f;
                } else {
                    final double currentSpeed = Math.sqrt(Wrapper.player().motionX * Wrapper.player().motionX + Wrapper.player().motionZ * Wrapper.player().motionZ);
                    final double speed = boost ? 1.0064 : 1.001;
                    final double direction = Utils.getDirection();
                    Wrapper.player().motionX = -Math.sin(direction) * speed * currentSpeed;
                    Wrapper.player().motionZ = Math.cos(direction) * speed * currentSpeed;
                }
                this.LBasicTick += 1;
                if(this.mode.getMode("LBasic").isToggled() && this.LBasicTick > 40){
                    this.setToggled(false);
                }
            }

        }

    }
}