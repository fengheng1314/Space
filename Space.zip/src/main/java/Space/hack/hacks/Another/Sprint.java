package Space.hack.hacks.Another;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Space.hack.HackCategory;
import Space.value.Mode;
import Space.value.ModeValue;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Sprint extends Hack
{
    public ModeValue Mode;
    public Sprint() {
        super("Sprint", HackCategory.Another);
        this.Mode = new ModeValue("Priority", new Mode("Strict", false), new Mode("KeepSprint", true));
        this.addValue(this.Mode);
    }

    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if(!Wrapper.player().isSprinting()) {
            if (this.Mode.getMode("Strict").isToggled()) {
                if (!Wrapper.player().onGround) {
                    return;
                }
            }
            Wrapper.player().setSprinting(true);
        }

    }
}
