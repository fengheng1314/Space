package Space.hack.hacks.Another;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Space.hack.HackCategory;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class AutoWalk extends Hack
{
    public AutoWalk() {
        super("AutoWalk", HackCategory.Another, false);
    }

    @Override
    public void onDisable() {
        KeyBinding.setKeyBindState(Wrapper.mc().gameSettings.keyBindForward.getKeyCode(), false);
    }

    @Override
    public void onClientTick(TickEvent.ClientTickEvent event) {
        KeyBinding.setKeyBindState(Wrapper.mc().gameSettings.keyBindForward.getKeyCode(), true);
    }

}
