package Space.hack.hacks.Another;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Space.hack.HackCategory;
import Space.value.BooleanValue;
import Space.value.Mode;
import Space.value.ModeValue;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class LongJump extends Hack {
    public ModeValue mode;
    int jumptick = 0;
    boolean Ground = false;
    public BooleanValue AutoExit;
    public LongJump() {
        super("LongJump", HackCategory.Another, false);
        this.mode = new ModeValue("Mode", new Mode("9JUMP", true), new Mode("12JUMP", false), new Mode("15JUMP", false), new Mode("17JUMP", false), new Mode("25JUMP", false));
        this.AutoExit = new BooleanValue("AutoExit", false);
        this.addValue(this.mode, this.AutoExit);
    }

    @Override
    public void onEnable() {
        this.jumptick = 0;
        this.Ground = false;
    }

    public int JUMP() {
        if (this.mode.getMode("9JUMP").isToggled()){
            return 9;
        }else if (this.mode.getMode("12JUMP").isToggled()){
            return 12;
        }else if (this.mode.getMode("15JUMP").isToggled()){
            return 15;
        }else if (this.mode.getMode("17JUMP").isToggled()){
            return 17;
        }else if (this.mode.getMode("25JUMP").isToggled()){
            return 25;
        }
        return 0;
    }

    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (!this.AutoExit.getValue() && this.Ground && jumptick > JUMP()){
            this.jumptick = 0;
            this.Ground = false;
        }

        if (!this.Ground && Wrapper.player().onGround) {
            this.Ground = true;
        }
        if (this.Ground && jumptick < JUMP() + 1){
            Wrapper.player().jump();
            jumptick++;
        }else if (this.AutoExit.getValue()){
            this.setToggled(false);
        }
    }
}