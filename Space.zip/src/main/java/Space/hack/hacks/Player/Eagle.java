package Space.hack.hacks.Player;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SEagle;
import Nirvana.hack.hacks.SScaffold;
import Space.hack.HackCategory;
import Space.utils.ui.RenderUtils;
import Space.value.BooleanValue;
import net.minecraft.block.BlockAir;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Eagle extends Hack
{
    public BooleanValue OnGround;
    public BooleanValue Mark;
    
    public Eagle() {
        super("Eagle", HackCategory.Player, false);
        this.OnGround = new BooleanValue("OnGround", false);
        this.Mark = new BooleanValue("Mark", true);
        this.addValue(this.OnGround,this.Mark);
    }

    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        if(!Mark.getValue()){return;}
        RenderUtils.drawBlockESP(SScaffold.Off(), 1.0f, 1.0f, 1.0f);
    }

    @Override
    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        if(OnGround.getValue()){if (!Wrapper.player().onGround){this.setToggled(false);}}
        eagle();
    }

    public static void eagle() {
        KeyBinding.setKeyBindState(Wrapper.mc().gameSettings.keyBindSneak.getKeyCode(), SEagle.getBlockUnderPlayer(Wrapper.player()) instanceof BlockAir && Wrapper.player().onGround && SEagle.LookVecY() < -0.6660000085830688);
    }

}
