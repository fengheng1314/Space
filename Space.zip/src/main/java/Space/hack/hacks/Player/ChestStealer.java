package Space.hack.hacks.Player;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SChestStealer;
import Nirvana.utils.Connection;
import Space.hack.HackCategory;
import Space.value.NumberValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class ChestStealer extends Hack
{
    public NumberValue delay;
    public int ticks;
    
    public ChestStealer() {
        super("ChestStealer", HackCategory.Player);
        this.delay = new NumberValue("Delay", 3.0,0.0,20.0);
        this.addValue(this.delay);
        this.ticks = 0;
    }
    
    @Override
    public boolean onPacket(final Object packet, final Connection.Side side) {
        return SChestStealer.onPacket(packet, side);
    }
    
    boolean isContainerEmpty(final Container container) {
        boolean temp = true;
        for (int i = 0, slotAmount = (container.inventorySlots.size() == 90) ? 54 : 35; i < slotAmount; ++i) {
            if (container.getSlot(i).getHasStack()) {
                temp = false;
            }
        }
        return temp;
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) {
            return;
        }
        final EntityPlayerSP player = Wrapper.player();
        if (!Wrapper.mc().inGameHasFocus && SChestStealer.packet != null && player.openContainer.windowId == SChestStealer.getWindowId() && Wrapper.mc().currentScreen instanceof GuiChest) {
            if (!this.isContainerEmpty(player.openContainer)) {
                for (int i = 0; i < player.openContainer.inventorySlots.size() - 36; ++i) {
                    final Slot slot = player.openContainer.getSlot(i);
                    if (slot.getHasStack() && this.ticks >= this.delay.getValue()) {
                        Wrapper.controller().windowClick(player.openContainer.windowId, i, 1, SChestStealer.QUICK_MOVE(), player);
                        this.ticks = 0;
                    }
                }
                ++this.ticks;
            }
            else {
                player.closeScreen();
                SChestStealer.packet = null;
            }
        }
    }
}