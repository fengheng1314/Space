/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https://github.com/fengheng13 14/Space
 */
package Space.hack;

public enum HackCategory
{
    Another,
    Player,
    Visual,
    Combat,
    None
}
