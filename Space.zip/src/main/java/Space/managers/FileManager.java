/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https://github.com/fengheng1 314/Space
 */
package Space.managers;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.managers.HackManager;
import Space.Disposal;
import Space.hack.HackCategory;
import Space.hack.hacks.Visual.Hud;
import Space.value.*;
import com.google.gson.*;

import java.io.*;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileManager {
    private static Gson gsonPretty;
    private static JsonParser jsonParser;
    private static File HACKS;
    private static File HUD;
    private static JsonObject Hudjson;
    private static boolean Send = false;

    public FileManager() {
        FileManager.HACKS = new File("C:\\Space\\Config\\" + Wrapper.version2 + ".Space");
        FileManager.HUD = new File("C:\\Space\\Config\\" + Wrapper.version2 + ".Hud");
        if (!FileManager.HACKS.exists()) {
            saveHacks(true);
        } else {
            loadHacks(false);
        }
        if (FileManager.HUD.exists()) {
            ExistsHud();
        }else {
            FileManager.AddHud(String.valueOf(1.0), String.valueOf(2.0), "ArrayList");
            FileManager.saveHud();
            ExistsHud();
        }

    }

    public static void ExistsHud() {
        Hack hack = HackManager.getHack("Hud");
        Hud.modexy.clear();
        for (final Value value : hack.getValues()) {
            if (value instanceof BooleanValue) {
                FileManager.loadHud(value.getName());
                Hud.modexy.add("[Name:" + "\"" + value.getName() + "\""+ " X:" + "\"" + FileManager.Hudxy("X") + "\"" + " Y:" + "\"" + FileManager.Hudxy("Y") + "\"" + "]");
            }
        }
    }

    public static void SetHud(String name, String x, String y) {
        for (int i = 0; i < Hud.modexy.size(); i++) {
            String line = Hud.modexy.get(i);
            if (line.contains("[Name:\"" + name + "\"")) {
                String updatedLine = "[Name:\"" + name + "\" X:\"" + x + "\" Y:\"" + y + "\"]";
                Hud.modexy.set(i, updatedLine);
                return;
            }
        }
    }

    public static void AddHud(String x, String y, String name) {
        String updatedLine = "[Name:\"" + name + "\" X:\"" + x + "\" Y:\"" + y + "\"]";
        Hud.modexy.add(updatedLine);
    }

    public static void loadHud(String name) {
        try {
            final BufferedReader bufferedReader = new BufferedReader(new FileReader(FileManager.HUD));
            final JsonObject jsonObject = (JsonObject) FileManager.jsonParser.parse(bufferedReader);
            bufferedReader.close();
            for (final Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                if (entry.getKey().equals(name)){
                    Hudjson = (JsonObject) entry.getValue();
                    return;
                }
            }

        } catch (Exception ignored) {}
    }

    public static double Hudxy(String xy) {
        if (xy.equals("x") || xy.equals("X")){
            return Hudjson.get("X").getAsDouble();
        }else if (xy.equals("y") || xy.equals("Y")){
            return Hudjson.get("Y").getAsDouble();
        }
        return 0;
    }

    public static void saveHud() {
        try {
            final JsonObject json = new JsonObject();

            for (int i = 0; i < Hud.modexy.size(); i++) {
                String line = Hud.modexy.get(i);

                Pattern pattern = Pattern.compile("\\[Name:\"([^\"]+)\" X:\"(\\d+(\\.\\d+)?)\" Y:\"(\\d+(\\.\\d+)?)\"\\]");
                Matcher matcher = pattern.matcher(line);

                if (!matcher.find()) {return;}
                String name = matcher.group(1);
                String X = matcher.group(2);
                String Y = matcher.group(4);

                final JsonObject jsonHack = new JsonObject();
                if (!X.equals("0") && !X.equals("1") && !X.equals("") && !X.equals(" ")){
                    jsonHack.addProperty("X", X);
                }

                if (!Y.equals("0") && !Y.equals("1") && !X.equals("") && !X.equals(" ")){
                    jsonHack.addProperty("Y", Y);
                }

                json.add(name, jsonHack);

                final PrintWriter saveJson = new PrintWriter(new FileWriter(FileManager.HUD));
                saveJson.println(FileManager.gsonPretty.toJson(json));
                saveJson.close();
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void loadHacks(boolean Reload) {
        try {
            final BufferedReader bufferedReader = new BufferedReader(new FileReader(FileManager.HACKS));
            final JsonObject jsonObject = (JsonObject) FileManager.jsonParser.parse(bufferedReader);
            bufferedReader.close();
            for (final Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                final Hack hack = HackManager.getHack(entry.getKey());
                if (hack == null) {
                    continue;
                }
                if (!Send && hack.isCategory() != HackCategory.Combat && hack.isCategory() != HackCategory.Another){
                    Disposal.Send100("All executions are complete");
                    Send = true;
                }
                final JsonObject jsonObjectHack = (JsonObject) entry.getValue();
                hack.setKey(jsonObjectHack.get("KeyValue" + "key").getAsInt());
                if (hack.Default()){
                    if (Reload){
                        hack.ReloadToggled120(false);
                    }else {
                        hack.setToggled120(false);
                    }

                }else {
                    if (Reload){
                        hack.ReloadToggled120(jsonObjectHack.get("KeyValue" + "toggled").getAsBoolean());
                    }else {
                        hack.setToggled120(jsonObjectHack.get("KeyValue" + "toggled").getAsBoolean());
                    }
                }
                if (hack.getValues().isEmpty()) {
                    continue;
                }
                for (final Value value : hack.getValues()) {
                    if (value instanceof BooleanValue) {
                        String title = "BooleanValue" + value.getName();
                        if (jsonObjectHack.has(title)){
                            value.setValue(jsonObjectHack.get(title).getAsBoolean());
                        }else {
                            value.setValue(value.getDefaultValue());
                        }

                    }
                    if (value instanceof NumberValue) {
                        String title = "NumberValue" + value.getName();
                        if (jsonObjectHack.has(title)){
                            value.setValue(jsonObjectHack.get(title).getAsDouble());
                        }else {
                            value.setValue(value.getDefaultValue());
                        }

                    }
                    if (value instanceof ModeValue) {
                        final ModeValue modeValue = (ModeValue) value;
                        String title = "ModeValue" + value.getName();
                        if (jsonObjectHack.has(title)){
                            if (modeValue.IsLegit(title)){
                                for (final Mode mode : modeValue.getModes()) {
                                    mode.setToggled(jsonObjectHack.get(title).getAsString().equals(mode.getName()));
                                }
                            }else if (modeValue.Isempty()){
                                modeValue.setValue(modeValue.getDefaultValue());
                            }

                        }else {
                            for (final Mode mode : modeValue.getModes()) {
                                mode.setToggled(value.getDefaultValue() == mode);
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void saveHacks(boolean send) {
        try {
            final JsonObject json = new JsonObject();
            final JsonObject jsonSpace = new JsonObject();
            jsonSpace.addProperty("version", Wrapper.version);
            json.add("Space", jsonSpace);
            for (final Hack hack : HackManager.getHacks()) {
                if (!Send && hack.isCategory() != HackCategory.Combat && hack.isCategory() != HackCategory.Another){
                    Disposal.Send100("All executions are complete");
                    Send=true;
                }
                final JsonObject jsonHack = new JsonObject();
                if(send){
                    jsonHack.addProperty("KeyValue" + "toggled", hack.isToggled2());
                }else {
                    jsonHack.addProperty("KeyValue" + "toggled", hack.isToggled());
                }
                jsonHack.addProperty("KeyValue" + "key", hack.getKey());
                if (!hack.getValues().isEmpty()) {
                    for (final Value value : hack.getValues()) {
                        if (value instanceof BooleanValue) {
                            Boolean temp = (Boolean) value.getValue();
                            if (value.getDefaultValue() != temp){
                                jsonHack.addProperty("BooleanValue" + value.getName(), temp);
                            }

                        }
                        if (value instanceof NumberValue) {
                            Number temp = (Number) value.getValue();
                            if (value.getDefaultValue() != temp){
                                jsonHack.addProperty("NumberValue" + value.getName(), temp);
                            }
                        }
                        if (value instanceof ModeValue) {
                            final ModeValue modeValue = (ModeValue) value;
                            for (final Mode mode : modeValue.getModes()) {
                                if (mode.isToggled() && value.getDefaultValue() != mode){
                                    jsonHack.addProperty("ModeValue" + value.getName(),  mode.getName());
                                }

                            }
                        }
                    }
                }
                json.add(hack.getName(), jsonHack);
            }
            final PrintWriter saveJson = new PrintWriter(new FileWriter(FileManager.HACKS));
            saveJson.println(FileManager.gsonPretty.toJson(json));
            saveJson.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    static {
        FileManager.gsonPretty = new GsonBuilder().setPrettyPrinting().create();
        FileManager.jsonParser = new JsonParser();
        FileManager.HACKS = null;
    }
}
