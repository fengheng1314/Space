/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * ht tps://github.com/fengheng1314/Space
 */
package Space;

import java.net.Socket;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import net.minecraftforge.fml.common.Mod;

@Mod(modid = "space", name = "Space", version = "1.0", acceptableRemoteVersions = "*")
public class Core
{
    public Core() {
        new Thread(() -> {
            try {
                Socket socket = new Socket("localhost", 23142);
                InputStream inputStream = socket.getInputStream();
                OutputStream outputStream = socket.getOutputStream();
                outputStream.write("Connected".getBytes());
                byte[] buffer = new byte[1024];
                int length;
                while ((length = inputStream.read(buffer)) != -1) {
                       String message = new String(buffer, 0, length);
                       Disposal.Tabled(outputStream,message);
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }
}
