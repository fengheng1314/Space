/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * htt ps://github.com/fengheng1314/Space
 */
package Space;

import org.lwjgl.input.Keyboard;

public class BenCore {
    public static int getKeyIndex(String arg){
        return Keyboard.getKeyIndex(arg);
    }

    public static boolean getEventKeyState() {
        return Keyboard.getEventKeyState();
    }

    public static int getEventKey() {
        return Keyboard.getEventKey();
    }
}
