/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https://githu b.com/fengheng1314/Space
 */
package Space.utils;

import com.google.common.reflect.TypeToken;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.ModContainer;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class Nan0EventRegister
{
    public static void register(final EventBus bus, final Object target) {
        final ConcurrentHashMap<Object, ArrayList<IEventListener>> listeners = (ConcurrentHashMap<Object, ArrayList<IEventListener>>)ReflectionHelper.getPrivateValue((Class)EventBus.class, (Object)bus, new String[] { "listeners" });
        final Map<Object, ModContainer> listenerOwners = (Map<Object, ModContainer>) ReflectionHelper.getPrivateValue((Class) EventBus.class, (Object) bus, new String[]{"listenerOwners"});
        if (listeners.containsKey(target)) {
            return;
        }
        final ModContainer activeModContainer = Loader.instance().getMinecraftModContainer();
        listenerOwners.put(target, activeModContainer);
        ReflectionHelper.setPrivateValue((Class)EventBus.class, (Object)bus, (Object)listenerOwners, "listenerOwners");
        final Set<? extends Class<?>> supers = (Set<? extends Class<?>>)TypeToken.of((Class)target.getClass()).getTypes().rawTypes();
        for (final Method method : target.getClass().getMethods()) {
            for (final Class<?> cls : supers) {
                try {
                    final Method real = cls.getDeclaredMethod(method.getName(), method.getParameterTypes());
                    if (real.isAnnotationPresent(SubscribeEvent.class)) {
                        final Class<?>[] nameeterTypes = method.getParameterTypes();
                        final Class<?> eventType = nameeterTypes[0];
                        register(bus, eventType, target, method, activeModContainer);
                        break;
                    }
                }
                catch (NoSuchMethodException ignored) {}
            }
        }
    }
    
    private static void register(final EventBus bus, final Class<?> eventType, final Object target, final Method method, final ModContainer owner) {
        try {
            final int busID = (int) ReflectionHelper.getPrivateValue((Class) EventBus.class, (Object) bus, new String[]{"busID"});
            final ConcurrentHashMap<Object, ArrayList<IEventListener>> listeners = (ConcurrentHashMap<Object, ArrayList<IEventListener>>)ReflectionHelper.getPrivateValue((Class)EventBus.class, (Object)bus, new String[] { "listeners" });
            final Constructor<?> ctr = eventType.getConstructor();
            ctr.setAccessible(true);
            final net.minecraftforge.fml.common.eventhandler.Event event = (Event)ctr.newInstance(new Object[0]);
            final ASMEventHandler listener = new ASMEventHandler(target, method, owner);
            event.getListenerList().register(busID, listener.getPriority(), listener);
            ArrayList<IEventListener> others = listeners.get(target);
            if (others == null) {
                others = new ArrayList<>();
                listeners.put(target, others);
                ReflectionHelper.setPrivateValue((Class)EventBus.class, (Object)bus, (Object)listeners, "listeners");
            }
            others.add(listener);
        }
        catch (Exception ignored) {}
    }
}
