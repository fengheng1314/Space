/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https://github.com/feng heng1314/Space
 */
package Space.utils.eventapi.events;

public abstract class EventStoppable implements Event
{
    private boolean stopped;
    
    public void stop() {
        this.stopped = true;
    }
    
    public boolean isStopped() {
        return this.stopped;
    }
}
