/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https://g ithub.com/fengheng1314/Space
 */
package Space.utils;

import Nirvana.Wrapper;
import Space.value.Mode;
import Nirvana.hack.Hack;
import Space.value.ModeValue;
import Nirvana.utils.SValidUtils;
import Nirvana.managers.HackManager;
import Space.hack.hacks.Another.AntiBot;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;

public class ValidUtils
{
    public static boolean isLowHealth(final EntityLivingBase entity, final EntityLivingBase entityPriority) {
        return entityPriority == null || entity.getHealth() < entityPriority.getHealth();
    }

    public static boolean isInAttackFOV(final EntityLivingBase entity, final int fov) {
        return Utils.getDistanceFromMouse(entity) <= fov;
    }

    public static ModeValue isMark() {
        return new ModeValue("Mark", new Mode("FDP", true), new Mode("Block", false), new Mode("Jello", false), new Mode("None", false));
    }

    public static ModeValue isCircle() {
        return new ModeValue("Circle", new Mode("Normal", true), new Mode("Space", false), new Mode("FDP", false), new Mode("None", false));
    }

    public static ModeValue isPriority(String name) {
        return new ModeValue(name, new Mode("Range", true), new Mode("RangeX", false), new Mode("Health", false), new Mode("HealthX", false));
    }

    public static EntityLivingBase killAuraUpdate(final String priority, final double Fov, final double Range, final EntityLivingBase target, final String kind) {
        if (!Utils.IsNull(target) && !priority.contains("X")){
            if (check(target, Fov, Range, priority, null, kind)) {
                return target;
            }
        }

        for (Object object : Utils.getEntityList()) {
            if (object instanceof EntityLivingBase) {
                EntityLivingBase entitylivingbase = (EntityLivingBase) object;
                if (check(entitylivingbase, Fov, Range, priority, target, kind)) {
                    return entitylivingbase;
                }
            }
        }

        return null;
    }

    public static boolean check (final EntityLivingBase entitylivingbase, final double Fov, final double Range, final String Name, final EntityLivingBase target, final String kind){
        return !(entitylivingbase instanceof EntityArmorStand) && SValidUtils.AttacksProhibited(entitylivingbase) && isPriority(Name, entitylivingbase, target) && (!ValidUtils.isValidEntity(entitylivingbase, kind) && (ValidUtils.isNoScreen() && (entitylivingbase != Wrapper.player() && (!entitylivingbase.isDead && (entitylivingbase.deathTime <= 0 && (!ValidUtils.isBot(entitylivingbase) && (ValidUtils.isInvisible(entitylivingbase) && (ValidUtils.isInAttackFOV(entitylivingbase, (int) (Fov / 2)) && (SValidUtils.isInAttackRange(entitylivingbase, Range) && (ValidUtils.isTeam(entitylivingbase) && ((Wrapper.player().canEntityBeSeen(entitylivingbase)))))))))))));
    }

    public static boolean isPriority(String priority, EntityLivingBase entitylivingbase, EntityLivingBase target) {
        return priority.contains("Health") && ValidUtils.isLowHealth(entitylivingbase, target) || priority.contains("Range") && SValidUtils.isRange(entitylivingbase, target);
    }

    public static boolean isValidEntity(final EntityLivingBase e, final String kind) {
        if(kind.contains("All")){
            return isValidEntity(e);
        }else if (kind.contains("Players") && e instanceof EntityPlayer){
            final Hack targets = HackManager.getHack("Targets");
            if (!targets.isToggledValue("Sleeping")) {
                return e.isPlayerSleeping();
            }
            return false;
        }else return !kind.contains("Mobs") || !(e instanceof EntityLiving);
    }

    public static boolean isValidEntity(final EntityLivingBase e) {
        final Hack targets = HackManager.getHack("Targets");
            if (targets.isToggledValue("Players") && e instanceof EntityPlayer) {
                if (!targets.isToggledValue("Sleeping")) {
                    return e.isPlayerSleeping();
                }
                return false;
            }else return !targets.isToggledValue("Mobs") || !(e instanceof EntityLiving);
    }

    public static boolean isTeam(final EntityLivingBase entity) {
        final Hack teams = HackManager.getHack("Teams");
        if (teams.isToggled() && entity instanceof EntityPlayer) {
            final EntityPlayer player = (EntityPlayer)entity;
            if (teams.isToggledModeY("Base") && player.getTeam() != null && Wrapper.player().getTeam() != null && player.getTeam().isSameTeam(Wrapper.player().getTeam())) {
                return false;
            }else return !teams.isToggledModeY("Armor") || Utils.checkEnemyColor(player);
        }
        return true;
    }

    public static boolean isBot(final EntityLivingBase entity) {
        final Hack hack = HackManager.getHack("AntiBot");
        if (hack.isToggled() && entity instanceof EntityPlayer) {
            final EntityPlayer player = (EntityPlayer)entity;
            return hack.isToggled() && AntiBot.isBot(player,hack);
        }
        return false;
    }

    public static boolean isInvisible(final EntityLivingBase entity) {
        final Hack targets = HackManager.getHack("Targets");
        return targets.isToggledValue("Invisibles") || !entity.isInvisible();
    }

    public static boolean isNoScreen() {
        return Utils.screenCheck();
    }

}
