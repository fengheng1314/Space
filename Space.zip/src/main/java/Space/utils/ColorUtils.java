/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https://github. com/fengheng1314/Space
 */
package Space.utils;

import java.awt.*;

public class ColorUtils
{

    public static int color(final double r, final double g, final double b, final double a) {
        return new Color((int) r, (int) g, (int) b, (int) a).getRGB();
    }

    public static int color(final int r, final int g, final int b, final int a) {
        return new Color(r, g, b, a).getRGB();
    }

    public static int color(final float r, final float g, final float b, final float a) {
        return new Color(r, g, b, a).getRGB();
    }

}
