/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https://gi thub.com/fengheng1314/Space
 */
package Space.utils;
import java.util.List;
import java.util.Random;
import Nirvana.Wrapper;
import Nirvana.utils.SPacket;
import Nirvana.utils.SUtils;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.Entity;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.gui.inventory.GuiContainer;

public class Utils
{
    private static final Random RANDOM;
    public static float[] rotationsToBlock;
    public static boolean nullCheck() {
        return Wrapper.player() == null || Wrapper.world() == null;
    }
    public static int random(final int min, final int max) {
        return Utils.RANDOM.nextInt(max - min) + min;
    }

    public static List<Entity> getEntityList() {
        return Wrapper.world().getLoadedEntityList();
    }

    public static float getPitch(final Entity entity) {
        return SUtils.getPitch(entity);
    }

    public static boolean IsNull(final EntityPlayer entity) {
        return entity == null;
    }

    public static boolean IsNull(final EntityLivingBase entity) {
        return entity == null;
    }

    public static void teleportToPosition(final double[] startPosition, final double[] endPosition, final double setOffset, final double slack, final boolean extendOffset, final boolean onGround) {
        boolean wasSneaking = Wrapper.player().isSneaking();
        double startX = startPosition[0];
        double startY = startPosition[1];
        double startZ = startPosition[2];
        final double endX = endPosition[0];
        final double endY = endPosition[1];
        final double endZ = endPosition[2];
        double distance = Math.abs(startX - startY) + Math.abs(startY - endY) + Math.abs(startZ - endZ);
        int count = 0;
        while (distance > slack) {
            distance = Math.abs(startX - endX) + Math.abs(startY - endY) + Math.abs(startZ - endZ);
            if (count > 120) {
                break;
            }
            final double offset = (extendOffset && (count & 0x1) == 0x0) ? (setOffset + 0.15) : setOffset;
            final double diffX = startX - endX;
            final double diffY = startY - endY;
            final double diffZ = startZ - endZ;
            if (diffX < 0.0) {
                startX += Math.min(Math.abs(diffX), offset);
            }
            if (diffX > 0.0) {
                startX -= Math.min(Math.abs(diffX), offset);
            }
            if (diffY < 0.0) {
                startY += Math.min(Math.abs(diffY), offset);
            }
            if (diffY > 0.0) {
                startY -= Math.min(Math.abs(diffY), offset);
            }
            if (diffZ < 0.0) {
                startZ += Math.min(Math.abs(diffZ), offset);
            }
            if (diffZ > 0.0) {
                startZ -= Math.min(Math.abs(diffZ), offset);
            }
            if (wasSneaking) {
                Wrapper.sendPacket(SPacket.CPacketEntityAction(Wrapper.player(), SPacket.CPacketEntityActionSTOP_SNEAKING()));
            }
            Wrapper.sendPacket(SPacket.CPacketPlayerPosition(startX, startY, startZ, onGround));
            ++count;
        }
        if (wasSneaking) {
            Wrapper.sendPacket(SPacket.CPacketEntityAction(Wrapper.player(), SPacket.CPacketEntityActionSTART_SNEAKING()));
        }
    }

    public static boolean isNullOrEmptyStack(final ItemStack stack) {
        return stack == null;
    }

    public static void windowClick(final int windowId, final int slotId, final int mouseButton, final Object type) {
        SUtils.windowClick(windowId, slotId, mouseButton, type);
    }

    public static String getPlayerName(final EntityPlayer player) {
        return player.getGameProfile().getName();
    }

    public static float getYaw(final Entity entity) {
        final double x = entity.posX - Wrapper.player().posX;
        final double z = entity.posZ - Wrapper.player().posZ;
        double yaw = Math.atan2 (x, z) * 57.29577951308232;
        yaw = -yaw;
        return (float)yaw;
    }

    public static void swing() {
        SUtils.swing();
    }

    public static float[] getRotations(Entity e) {
        double deltaX = e.posX + (e.posX - e.lastTickPosX) - Wrapper.player().posX;
        double deltaZ = e.posZ + (e.posZ - e.lastTickPosZ) - Wrapper.player().posZ;
        double deltaY = e.posY - 3.5 + e.getEyeHeight() - Wrapper.player().posY + Wrapper.player().getEyeHeight();
        double distance = Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaZ, 2));

        float yaw = (float) Math.toDegrees(-Math.atan(deltaX / deltaZ));
        float pitch = (float) -Math.toDegrees(Math.atan(deltaY/distance));

        if(deltaX < 0 && deltaZ < 0)
            yaw = (float) (90 + Math.toDegrees(Math.atan(deltaZ / deltaX)));
        else if (deltaX > 0 && deltaZ < 0)
            yaw = (float) (-90 + Math.toDegrees(Math.atan(deltaZ / deltaX)));

        return new float[] {yaw, pitch};
    }

    public static float updateRotation(final float angle, final float targetAngle, final float maxIncrease) {
        return SUtils.updateRotation(angle, targetAngle, maxIncrease);
    }

    public static int getPlayerArmorColor(final EntityPlayer player, final ItemStack stack) {
        if (player == null || stack == null || !(stack.getItem() instanceof ItemArmor)) {
            return -1;
        }
        final ItemArmor itemArmor = (ItemArmor)stack.getItem();
        if (itemArmor.getArmorMaterial() != ItemArmor.ArmorMaterial.LEATHER) {
            return -1;
        }
        return itemArmor.getColor(stack);
    }

    public static int getDistanceFromMouse(final EntityLivingBase entity) {
        return SUtils.getDistanceFromMouse(entity);
    }

    public static boolean isMoving(){
        return Wrapper.player() != null && (Wrapper.player().movementInput.moveForward != 0f || Wrapper.player().movementInput.moveStrafe != 0f);
    }

    public static boolean checkEnemyColor(final EntityPlayer enemy) {
        final int colorEnemy0 = getPlayerArmorColor(enemy, enemy.inventory.armorItemInSlot(0));
        final int colorEnemy2 = getPlayerArmorColor(enemy, enemy.inventory.armorItemInSlot(1));
        final int colorEnemy3 = getPlayerArmorColor(enemy, enemy.inventory.armorItemInSlot(2));
        final int colorEnemy4 = getPlayerArmorColor(enemy, enemy.inventory.armorItemInSlot(3));
        final int colorPlayer0 = getPlayerArmorColor(Wrapper.player(), Wrapper.player().inventory.armorItemInSlot(0));
        final int colorPlayer2 = getPlayerArmorColor(Wrapper.player(), Wrapper.player().inventory.armorItemInSlot(1));
        final int colorPlayer3 = getPlayerArmorColor(Wrapper.player(), Wrapper.player().inventory.armorItemInSlot(2));
        final int colorPlayer4 = getPlayerArmorColor(Wrapper.player(), Wrapper.player().inventory.armorItemInSlot(3));
        return (colorEnemy0 != colorPlayer0 || colorPlayer0 == -1 || colorEnemy0 == 1) && (colorEnemy2 != colorPlayer2 || colorPlayer2 == -1 || colorEnemy2 == 1) && (colorEnemy3 != colorPlayer3 || colorPlayer3 == -1 || colorEnemy3 == 1) && (colorEnemy4 != colorPlayer4 || colorPlayer4 == -1 || colorEnemy4 == 1);
    }

    public static boolean screenCheck() {
        return !(Wrapper.mc().currentScreen instanceof GuiContainer) && !(Wrapper.mc().currentScreen instanceof GuiChat) && Wrapper.mc().currentScreen == null;
    }

    public static float[] getRotationsNeeded(final Entity entity) {
        return SUtils.getRotationsNeeded(entity);
    }

    public static float getDirection() {
        float var1 = Wrapper.player().rotationYaw;
        if (Wrapper.player().moveForward < 0.0f) {
            var1 += 180.0f;
        }
        float forward = 1.0f;
        if (Wrapper.player().moveForward < 0.0f) {
            forward = -0.5f;
        }
        else if (Wrapper.player().moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (Wrapper.player().moveStrafing > 0.0f) {
            var1 -= 90.0f * forward;
        }
        if (Wrapper.player().moveStrafing < 0.0f) {
            var1 += 90.0f * forward;
        }
        var1 *= 0.017453292f;
        return var1;
    }

    public static void addEffect(final int id, final int duration, final int amplifier) {
        SUtils.addEffect(id, duration, amplifier);
    }

    public static void removeEffect(final int id) {
        SUtils.removeEffect(id);
    }

    public static boolean isPlayerInGame() {
        return Wrapper.player() != null && Wrapper.world() != null;
    }

    public static void attack(final Entity entity) {
        Wrapper.controller().attackEntity(Wrapper.player(), entity);
    }

    public static void swingMainHand() {
        SUtils.swingMainHand();
    }

    public static float[] getTargetRotations(Entity q) {
        return SUtils.getTargetRotations(q);
    }

    public static float[] getTargetRotations2(Entity entity) {
        if (entity == null) {
            return null;
        } else {
            double diffX = entity.posX - Wrapper.player().posX;
            double diffY = entity.posY + (entity.getEyeHeight() * 0.9D) - (Wrapper.player().posY + Wrapper.player().getEyeHeight());
            double diffZ = entity.posZ - Wrapper.player().posZ;
            double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);

            float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
            float pitch = (float) Math.toDegrees(-Math.atan2(diffY, dist));

            return new float[]{Wrapper.player().rotationYaw + wrapAngleTo180_float(yaw - Wrapper.player().rotationYaw),
                    Wrapper.player().rotationPitch + wrapAngleTo180_float(pitch - Wrapper.player().rotationPitch)};
        }
    }

    public static float wrapAngleTo180_float(float angle) {
        angle %= 360.0F;
        if (angle >= 180.0F) {
            angle -= 360.0F;
        }
        if (angle < -180.0F) {
            angle += 360.0F;
        }
        return angle;
    }


    static {
        Utils.rotationsToBlock = null;
        RANDOM = new Random();
    }
}
