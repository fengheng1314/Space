/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https://gith ub.com/fengheng1314/Space
 */
package Space.utils;

import java.lang.reflect.Field;

public class ReflectionHelper
{
    public static Field findField(final Class<?> clazz, final String... fieldNames) {
        Exception failed = null;
        final int length = fieldNames.length;
        int i = 0;
        while (i < length) {
            final String fieldName = fieldNames[i];
            try {
                final Field f = clazz.getDeclaredField(fieldName);
                f.setAccessible(true);
                return f;
            }
            catch (Exception e) {
                failed = e;
                ++i;
                continue;
            }
        }
        throw new UnableToFindFieldException(failed);
    }

    public static <T, E> T getPrivateValue(final Class<? super E> classToAccess, final E instance, final String... fieldNames) {
        try {
            return (T)findField(classToAccess, fieldNames).get(instance);
        }
        catch (Exception e) {
            throw new UnableToAccessFieldException(e);
        }
    }

    public static <T, E> void setPrivateValue(final Class<? super T> classToAccess, final T instance, final E value, final String... fieldNames) {
        try {
            findField(classToAccess, fieldNames).set(instance, value);
        }
        catch (Exception e) {
            throw new UnableToAccessFieldException(e);
        }
    }

    public static class UnableToAccessFieldException extends RuntimeException
    {
        private static final long serialVersionUID = 1L;

        public UnableToAccessFieldException(final Exception e) {
            super(e);
        }
    }

    public static class UnableToFindFieldException extends RuntimeException
    {
        private static final long serialVersionUID = 1L;

        public UnableToFindFieldException(final Exception e) {
            super(e);
        }
    }
}
