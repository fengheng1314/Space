/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https:// github.com/fengheng1314/Space
 */
package Space.value;

public class BooleanValue extends Value<Boolean>
{
    public BooleanValue(final String name, final Boolean defaultValue) {
        super(name, defaultValue);
    }
}
