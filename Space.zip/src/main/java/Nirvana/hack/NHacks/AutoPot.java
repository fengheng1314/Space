package Nirvana.hack.NHacks;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Space.hack.HackCategory;
import Space.utils.TimerUtils;
import Space.utils.Utils;
import Space.value.Mode;
import Space.value.ModeValue;
import Space.value.NumberValue;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionUtils;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.List;

public class AutoPot extends Hack
{
    public ModeValue Rotation;
    public NumberValue Health;
    public NumberValue Speed;
    public TimerUtils timer;
    int slot = -1;
    float Pitch = -1;
    public AutoPot() {
        super("AutoPot", HackCategory.Combat);
        this.Rotation = new ModeValue("Rotation", new Mode("Top", true), new Mode("Below", false), new Mode("None", false));
        this.Health = new NumberValue("Health", 10.0, 1.0, 20.0);
        this.Speed = new NumberValue("Speed", 2.0, 1.0, 6.0);
        this.addValue(this.Rotation, this.Health, this.Speed);
        this.timer = new TimerUtils();
    }

    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (Wrapper.player().getHealth() <= this.Health.getValue()) {
            int potionIndex = findPotionInHotbar();
            if (potionIndex != -1) {
                int i = Utils.random(this.Speed.getValue().intValue() + 3,this.Speed.getValue().intValue() + 4);
                int j = Utils.random(1, 50);
                int k = Utils.random(1, 60);
                int l = Utils.random(1, 70);
                if (this.timer.isDelay(((1000 + j - k + l) / i))) {
                    if (slot == -1){
                        slot = Wrapper.player().inventory.currentItem;
                        Pitch = Wrapper.player().rotationPitch;
                    }
                    Wrapper.player().inventory.currentItem = potionIndex;
                    if (Rotation.getMode("Top").isToggled()) {
                        Wrapper.player().rotationPitch = 90.0f;
                    }else if (Rotation.getMode("Below").isToggled()) {
                        Wrapper.player().rotationPitch = -90.0f;
                    }
                    Wrapper.sendPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
                    this.timer.setLastMS();
                }
            }
        }else {
            if (slot != -1) {
                Wrapper.player().inventory.currentItem = slot;
                Wrapper.player().rotationPitch = Pitch;
                slot = -1;
            }
        }

    }

    private int findPotionInHotbar() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = Wrapper.player().inventory.getStackInSlot(i);
            if (stack.getItem() instanceof ItemPotion) {
                List<PotionEffect> effects = PotionUtils.getEffectsFromStack(stack);
                for (PotionEffect effect : effects) {
                    if (effect.getPotion() == MobEffects.INSTANT_HEALTH) {
                        return i;
                    }
                }
            }
        }
        return -1;
    }


}
