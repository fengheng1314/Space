package Nirvana.hack.NHacks;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.utils.BlockUtils;
import Nirvana.utils.Connection;
import Nirvana.utils.PlayerControllerUtils;
import Nirvana.utils.SPacket;
import Space.hack.HackCategory;
import Space.utils.Utils;
import Space.utils.ui.RenderUtils;
import Space.value.BooleanValue;
import Space.value.Mode;
import Space.value.ModeValue;
import net.minecraft.block.*;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

public class Teleport extends Hack
{
    public ModeValue mode;
    public BooleanValue math;
    public boolean passPacket;
    private BlockPos teleportPosition;
    private boolean canDraw;
    private int delay;
    float reach;
    
    public Teleport() {
        super("Teleport", HackCategory.Another,false);
        this.passPacket = false;
        this.teleportPosition = null;
        this.reach = 0.0f;
        this.mode = new ModeValue("Mode", new Mode("Reach", true));
        this.math = new BooleanValue("Math", false);
        this.addValue(this.mode, this.math);
    }
    
    @Override
    public void onEnable() {
        if (this.mode.getMode("Reach").isToggled()) {
            this.reach = 3f;
        }
    }
    
    @Override
    public void onDisable() {
        this.canDraw = false;
        PlayerControllerUtils.setReach(Wrapper.player(), this.reach);
    }
    
    @Override
    public boolean onPacket(final Object packet, final Connection.Side side) {
        return side != Connection.Side.OUT || !(packet instanceof CPacketPlayer) || this.passPacket;
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
            if ((!Mouse.isButtonDown(0) || !Wrapper.mc().inGameHasFocus) && Wrapper.player().getItemInUseCount() == 0) {
                PlayerControllerUtils.setReach(Wrapper.player(), 100.0);
                this.canDraw = true;
            }
            else {
                this.canDraw = false;
                PlayerControllerUtils.setReach(Wrapper.player(), this.reach);
            }
            if (this.teleportPosition != null && this.delay == 0 && Mouse.isButtonDown(1)) {
                if (this.math.getValue()) {
                    final double[] playerPosition = { Wrapper.player().posX, Wrapper.player().posY, Wrapper.player().posZ };
                    final double[] blockPosition = { this.teleportPosition.getX() + 0.5f, this.teleportPosition.getY() + this.getOffset(BlockUtils.getBlock(this.teleportPosition), this.teleportPosition) + 1.0, this.teleportPosition.getZ() + 0.5f };
                    Utils.teleportToPosition(playerPosition, blockPosition, 0.25, 0.0, true, true);
                    Wrapper.player().setPosition(blockPosition[0], blockPosition[1], blockPosition[2]);
                    this.teleportPosition = null;
                }
                else {
                    final double x = this.teleportPosition.getX();
                    final double y = this.teleportPosition.getY() + 1;
                    final double z = this.teleportPosition.getZ();
                    Wrapper.player().setPosition(x, y, z);
                    for (int i = 0; i < 1; ++i) {
                        Wrapper.sendPacket(SPacket.CPacketPlayerPosition(x, y, z, Wrapper.player().onGround));
                    }
                }
                this.delay = 5;
            }
            if (this.delay > 0) {
                --this.delay;
            }
    }
    
    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
            final RayTraceResult object = Wrapper.mc().objectMouseOver;
            if (object == null) {
                return;
            }
            if (this.canDraw) {
                for (float offset = -2.0f; offset < 18.0f; ++offset) {
                    final double[] mouseOverPos = { object.getBlockPos().getX(), object.getBlockPos().getY() + offset, object.getBlockPos().getZ() };
                    final BlockPos blockBelowPos = new BlockPos(mouseOverPos[0], mouseOverPos[1], mouseOverPos[2]);
                    if (this.canRenderBox(mouseOverPos)) {
                        RenderUtils.drawBlockESP(new BlockPos(mouseOverPos[0], mouseOverPos[1], mouseOverPos[2]), 1.0f, 0.0f, 1.0f);
                        if (Wrapper.mc().inGameHasFocus) {
                            this.teleportPosition = blockBelowPos;
                            break;
                        }
                        this.teleportPosition = null;
                    }
                }
            }
            else if (object.entityHit != null) {
                for (float offset = -2.0f; offset < 18.0f; ++offset) {
                    final double[] mouseOverPos = { object.entityHit.posX, object.entityHit.posY + offset, object.entityHit.posZ };
                    final BlockPos blockBelowPos = new BlockPos(mouseOverPos[0], mouseOverPos[1], mouseOverPos[2]);
                    if (this.canRenderBox(mouseOverPos)) {
                        RenderUtils.drawBlockESP(new BlockPos(mouseOverPos[0], mouseOverPos[1], mouseOverPos[2]), 1.0f, 0.0f, 1.0f);
                        if (Wrapper.mc().inGameHasFocus) {
                            this.teleportPosition = blockBelowPos;
                            break;
                        }
                        this.teleportPosition = null;
                    }
                }
            }
            else {
                this.teleportPosition = null;
            }
    }
    
    public boolean canRenderBox(final double[] mouseOverPos) {
        boolean canTeleport = false;
        final Block blockBelowPos = BlockUtils.getBlock(new BlockPos(mouseOverPos[0], mouseOverPos[1] - 1.0, mouseOverPos[2]));
        final Block blockPos = BlockUtils.getBlock(new BlockPos(mouseOverPos[0], mouseOverPos[1], mouseOverPos[2]));
        final Block blockAbovePos = BlockUtils.getBlock(new BlockPos(mouseOverPos[0], mouseOverPos[1] + 1.0, mouseOverPos[2]));
        final boolean validBlockBelow = blockBelowPos.getCollisionBoundingBox(BlockUtils.getState(new BlockPos(mouseOverPos[0], mouseOverPos[1] - 1.0, mouseOverPos[2])), Wrapper.world(), new BlockPos(mouseOverPos[0], mouseOverPos[1] - 1.0, mouseOverPos[2])) != null;
        final boolean validBlock = this.isValidBlock(blockPos);
        final boolean validBlockAbove = this.isValidBlock(blockAbovePos);
        if (validBlockBelow && validBlock && validBlockAbove) {
            canTeleport = true;
        }
        return canTeleport;
    }
    
    public double getOffset(final Block block, final BlockPos pos) {
        final IBlockState state = BlockUtils.getState(pos);
        double offset = 0.0;
        if (block instanceof BlockSlab && !((BlockSlab)block).isDouble()) {
            offset -= 0.5;
        }
        else if (block instanceof BlockEndPortalFrame) {
            offset -= 0.20000000298023224;
        }
        else if (block instanceof BlockBed) {
            offset -= 0.4399999976158142;
        }
        else if (block instanceof BlockCake) {
            offset -= 0.5;
        }
        else if (block instanceof BlockDaylightDetector) {
            offset -= 0.625;
        }
        else if (block instanceof BlockRedstoneComparator || block instanceof BlockRedstoneRepeater) {
            offset -= 0.875;
        }
        else if (block instanceof BlockChest || block == Blocks.ENDER_CHEST) {
            offset -= 0.125;
        }
        else if (block instanceof BlockLilyPad) {
            offset -= 0.949999988079071;
        }
        else if (block == Blocks.SNOW_LAYER) {
            offset -= 0.875;
            offset += 0.125f * ((int)state.getValue((IProperty)BlockSnow.LAYERS) - 1);
        }
        else if (this.isValidBlock(block)) {
            --offset;
        }
        return offset;
    }
    
    public boolean isValidBlock(final Block block) {
        return block == Blocks.PORTAL || block == Blocks.SNOW_LAYER || block instanceof BlockTripWireHook || block instanceof BlockTripWire || block instanceof BlockDaylightDetector || block instanceof BlockRedstoneComparator || block instanceof BlockRedstoneRepeater || block instanceof BlockSign || block instanceof BlockAir || block instanceof BlockPressurePlate || block instanceof BlockTallGrass || block instanceof BlockFlower || block instanceof BlockMushroom || block instanceof BlockDoublePlant || block instanceof BlockReed || block instanceof BlockSapling || block == Blocks.CARROTS || block == Blocks.WHEAT || block == Blocks.NETHER_WART || block == Blocks.POTATOES || block == Blocks.PUMPKIN_STEM || block == Blocks.MELON_STEM || block == Blocks.HEAVY_WEIGHTED_PRESSURE_PLATE || block == Blocks.LIGHT_WEIGHTED_PRESSURE_PLATE || block == Blocks.REDSTONE_WIRE || block instanceof BlockTorch || block == Blocks.LEVER || block instanceof BlockButton;
    }
}