package Nirvana.hack.NHacks;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Space.hack.HackCategory;
import Space.value.Mode;
import Space.value.ModeValue;
import Space.value.NumberValue;

public class NoSlow extends Hack
{
     public ModeValue mode;
    private final NumberValue Slow;
    public NoSlow() {
        super("NoSlow", HackCategory.Another);
        this.mode = new ModeValue("Mode", new Mode("Vanilla", true));
        this.Slow = new NumberValue("Slow", 80.0, 0.0, 80.0);
        this.addValue(this.mode, this.Slow);

    }

    @Override
    public void onInputUpdate(final Object event) {
        if (this.mode.getMode("Vanilla").isToggled()) {
            float val = (float) (100.0F - Slow.getValue() / 100.0F);
            Wrapper.player().movementInput.moveStrafe *= val;
            Wrapper.player().movementInput.moveForward *= val;
        }
    }

}
