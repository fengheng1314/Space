package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.managers.HackManager;
import Space.hack.hacks.Visual.UI.GuiDraggableMenu;
import Space.value.BooleanValue;
import Space.value.Value;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public class GuiCustomScreen extends GuiScreen {
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 20;
    public int Create = 0;

    @Override
    public void initGui() {
        super.initGui();
        this.buttonList.clear();
        int centerX = this.width / 2;
        int centerY = this.height / 2;
        this.Create = 0;

        Hack hack = HackManager.getHack("Hud");

            for (final Value value : hack.getValues()) {
                if (value instanceof BooleanValue) {
                    Create++;
                    GuiButton button = new GuiButton(Create, centerX - BUTTON_WIDTH / 2, centerY - BUTTON_HEIGHT / 2 - 20 + (20 * Create), BUTTON_WIDTH, BUTTON_HEIGHT, value.getName());
                    this.buttonList.add(button);
                }
            }

    }

    @Override
    protected void actionPerformed(GuiButton button) {
        HackManager.getHack("Hud").setToggledD(false);
        Wrapper.mc().displayGuiScreen(new GuiDraggableMenu(button.displayString));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        String title = "Settings";
        this.drawCenteredString(this.fontRenderer, title, centerX, centerY - 30, 0xFFFFFF);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
