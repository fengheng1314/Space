package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class SFastPlace {
    public static boolean isHoldingBlock() {
        ItemStack heldItem = Wrapper.player().getHeldItemMainhand();
        if (heldItem.isEmpty()) {
            return false;
        }
        Item heldItemBlock = heldItem.getItem();
        int heldItemId = Item.getIdFromItem(heldItemBlock);
        return heldItemId >= 1 && heldItemId <= 186;
    }
}
