package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import Space.hack.hacks.Visual.Xray;
import Space.utils.Utils;
import Space.utils.ui.RenderUtils;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.RenderWorldLastEvent;

import java.util.ArrayList;
import java.util.List;

public class SXray {
    public static List<BlockPos> ren;

    public static BlockPos p;

    public static Block IRON_ORE = Blocks.IRON_ORE;

    public static Block GOLD_ORE = Blocks.GOLD_ORE;

    public static Block DIAMOND_ORE = Blocks.DIAMOND_ORE;

    public static Block EMERALD_ORE = Blocks.EMERALD_ORE;

    public static Block LAPIS_ORE = Blocks.LAPIS_ORE;

    public static Block REDSTONE_ORE = Blocks.REDSTONE_ORE;

    public static Block COAL_ORE = Blocks.COAL_ORE;

    public static Block MOB_SPAWNER = Blocks.MOB_SPAWNER;

    public static void NBlockPos(double x, double y, double z){
        SXray.p = new BlockPos(Wrapper.player().posX + x, Wrapper.player().posY + y, Wrapper.player().posZ + z);
    }

    public static void onRenderWorldLast(final RenderWorldLastEvent event) {
        if (Utils.isPlayerInGame() && !SXray.ren.isEmpty()) {
            List<BlockPos> tRen = new ArrayList<>(SXray.ren);

            for (BlockPos p : tRen) {
                dr(p);
            }
        }
    }

    private static void dr(BlockPos p) {
        int[] rgb = Xray.c(Wrapper.world().getBlockState(p).getBlock());
        if (rgb[0] + rgb[1] + rgb[2] != 0) {
            RenderUtils.drawBlockESP(p, rgb[0], rgb[1], rgb[2]);
        }

    }
}
