package Nirvana.hack.hacks;

import Nirvana.utils.Connection;
import net.minecraft.inventory.ClickType;
import net.minecraft.network.play.server.SPacketWindowItems;

public class SChestStealer {
    public static SPacketWindowItems packet;

    public static boolean onPacket(final Object packet, final Connection.Side side){
        if (side == Connection.Side.IN && packet instanceof SPacketWindowItems) {
            SChestStealer.packet = (SPacketWindowItems)packet;
        }
        return true;
    }

    public static ClickType QUICK_MOVE(){
        return ClickType.QUICK_MOVE;
    }

    public static int getWindowId(){
        return SChestStealer.packet.getWindowId();
    }
}
