package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;

public class SEagle {
    public static Block getBlock(final BlockPos pos) {
        return Wrapper.world().getBlockState(pos).getBlock();
    }

    public static Block getBlockUnderPlayer(final EntityPlayer player) {
        return getBlock(new BlockPos(player.posX, player.posY - 1.0, player.posZ));
    }

    public static double LookVecY(){
        return Wrapper.player().getLookVec().y;
    }
}
