package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.item.ItemStack;

public class SHudNSDArmorHUD {
    public static RenderItem itemRender = null;

    public static void itemRender(){
        itemRender = Wrapper.mc().getRenderItem();
    }

    public static String Strings(final ItemStack is){
        return (is.getCount() > 1) ? (String.valueOf(is.getCount())) : "";
    }
}
