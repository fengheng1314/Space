package Nirvana.hack.hacks;

import net.minecraft.network.play.server.SPacketChat;

public class SChatTranslator {
    public static boolean Instanceof(final Object packet){
        return packet instanceof SPacketChat;
    }

    public static String getmsg(final Object packet){
        return ((SPacketChat) packet).getChatComponent().getFormattedText();
    }
}
