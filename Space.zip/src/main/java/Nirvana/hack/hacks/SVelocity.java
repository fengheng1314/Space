package Nirvana.hack.hacks;

import net.minecraft.network.play.server.SPacketEntityVelocity;

public class SVelocity {
    public static Object p = null;

    public static boolean Instanceof(final Object packet){
        boolean Return = packet instanceof SPacketEntityVelocity;
        if (Return){
            p = packet;
        }
        return Return;
    }

    public static SPacketEntityVelocity getSP(){
        return (SPacketEntityVelocity) p;
    }
}
