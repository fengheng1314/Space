package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

import java.text.DecimalFormat;

public class SHudNSDEnemyInfo {
    public static String Distanse(EntityPlayer Target){
        final DecimalFormat decimalFormat = new DecimalFormat("###.#");
        return decimalFormat.format(Target.getDistance(Wrapper.player()));
    }

    public static ResourceLocation drawHead(EntityPlayer Target){
        return Wrapper.mc().getConnection().getPlayerInfo(Target.getUniqueID()).getLocationSkin();
    }
}
