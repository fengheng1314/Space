package Nirvana.hack.hacks;

import net.minecraft.network.play.client.CPacketPlayer;

import java.util.List;
import java.util.Queue;

public class SFlight {
    public static Queue<CPacketPlayer> packets;
    public static List<CPacketPlayer> p;
}
