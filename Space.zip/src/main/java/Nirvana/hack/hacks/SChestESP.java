package Nirvana.hack.hacks;

import net.minecraft.block.BlockChest;

public class SChestESP {
    public static BlockChest.Type BlockChestTypeTRAP(){
        return BlockChest.Type.TRAP;
    }
}
