package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import Nirvana.utils.BlockUtils;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;

public class SScaffold {
    public static BlockPos blockDown;

    public static BlockPos blockpos;

    public static BlockPos blockpos1;

    public static BlockPos Off(){
        return new BlockPos(Wrapper.player()).down();
    }

    public static BlockPos onRenderWorldLast(){
        return (new BlockPos(Wrapper.player())).down();
    }

    public static int findSlotWithBlock() {
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = Wrapper.inventory().getStackInSlot(i);
            if (stack.getItem() instanceof ItemBlock) {
                final Block block = Block.getBlockFromItem(stack.getItem()).getDefaultState().getBlock();
                if (block.isFullBlock(BlockUtils.getBlock(SScaffold.blockDown).getDefaultState()) && block != Blocks.SAND && block != Blocks.GRAVEL) {
                    return i;
                }
            }
        }
        return -1;
    }

    public static boolean Material(){
        return !BlockUtils.getBlock(SScaffold.blockDown).getMaterial(BlockUtils.getBlock(SScaffold.blockDown).getDefaultState()).isReplaceable();
    }
}
