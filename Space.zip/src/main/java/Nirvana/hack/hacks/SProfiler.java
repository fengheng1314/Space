package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import Space.hack.hacks.Visual.Profiler;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;

public class SProfiler {
    public static RenderItem renderItem = null;

    public static void renderItem(){
        renderItem = Wrapper.mc().getRenderItem();
    }

    public static Profiler.EnchantEntry[] enchants(){
        return new Profiler.EnchantEntry[]{new Profiler.EnchantEntry(Enchantments.PROTECTION, "Pro"), new Profiler.EnchantEntry(Enchantments.THORNS, "Th"), new Profiler.EnchantEntry(Enchantments.SHARPNESS, "Shar"), new Profiler.EnchantEntry(Enchantments.FIRE_ASPECT, "Fire"), new Profiler.EnchantEntry(Enchantments.KNOCKBACK, "Kb"), new Profiler.EnchantEntry(Enchantments.UNBREAKING, "Unb"), new Profiler.EnchantEntry(Enchantments.POWER, "Pow"), new Profiler.EnchantEntry(Enchantments.INFINITY, "Inf"), new Profiler.EnchantEntry(Enchantments.PUNCH, "Punch")};
    }
    
    public static float distance(Entity entity){
        return Wrapper.getDistance(entity) / 4.0f;
    }

    public static ItemStack inHand(){
        return Wrapper.player().getHeldItemMainhand();
    }

    public static int level(final Profiler.EnchantEntry enchant, final ItemStack stack) {
        return EnchantmentHelper.getEnchantmentLevel(enchant.getEnchant(), stack);
    }
}
