package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.managers.HackManager;
import Nirvana.utils.Connection;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

import java.lang.reflect.Field;

public class SNoFall {
    public static void CPacketPlayer(){
        Wrapper.sendPacket(new CPacketPlayer(true));
    }

    public static boolean onPacket(final Object packet, final Connection.Side side){
        if (side == Connection.Side.OUT && packet instanceof CPacketPlayer) {
            final CPacketPlayer p = (CPacketPlayer)packet;
            final Hack hack = HackManager.getHack("AntiBot");
            if (hack.onToggledMode("Mode").equals("AAC")) {
                final Field field = ReflectionHelper.findField(CPacketPlayer.class, "onGround", "field_149474_g");
                try {
                    if (!field.isAccessible()) {
                        field.setAccessible(true);
                    }
                    field.setBoolean(p, true);
                }
                catch (Exception ignored) {}
            }
        }
        return true;
    }
}
