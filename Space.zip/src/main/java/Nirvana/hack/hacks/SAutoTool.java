package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import Space.hack.hacks.Player.AutoTool;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

public class SAutoTool {
    public static void equipBestTool(final IBlockState blockState){
        int bestSlot = -1;
        double max = 0.0;
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = Wrapper.player().inventory.getStackInSlot(i);
            float speed = stack.getDestroySpeed(blockState);
            if (speed > 1.0f) {
                final int eff;
                speed += (float)(((eff = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, stack)) > 0) ? (Math.pow(eff, 2.0) + 1.0) : 0.0);
                if (speed > max) {
                    max = speed;
                    bestSlot = i;
                }
            }
        }
        if (bestSlot != -1) {
            AutoTool.equip(bestSlot);
        }
    }

    public static double damage(final ItemStack stack){
        return ((ItemSword)stack.getItem()).getAttackDamage() + EnchantmentHelper.getModifierForCreature(stack, EnumCreatureAttribute.UNDEFINED) + 1.0 + EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, stack) * 0.6000000238418579;
    }
}
