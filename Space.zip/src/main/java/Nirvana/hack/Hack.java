package Nirvana.hack;

import Nirvana.utils.Connection;
import Space.Disposal;
import Space.hack.HackCategory;
import Space.managers.FileManager;
import Space.value.*;
import net.minecraftforge.client.event.*;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;

public class Hack
{
    private final boolean Default;
    private boolean toggled;
    private int key;
    private final String name;
    private final HackCategory category;
    private boolean show;
    private final ArrayList<Value> values;

    public Hack(final String name, final HackCategory category, boolean OnDefault) {
        this.values = new ArrayList<>();
        this.name = name;
        this.category = category;
        this.toggled = false;
        this.show = true;
        this.key = 0;
        this.Default = true;
    }

    public Hack(final String name, final HackCategory category) {
        this.values = new ArrayList<>();
        this.name = name;
        this.category = category;
        this.toggled = false;
        this.show = true;
        this.key = 0;
        this.Default = false;
    }

    public boolean Default() {
        return Default;
    }

    public void toggle() {
        this.toggled = !this.toggled;
        if (this.toggled) {
            this.onEnable();
        }
        else {
            this.onDisable();
        }

        FileManager.saveHacks(false);
        System.out.print("\n" + "-------" + "\n" +"Space:The configuration is saved" + "\n" + "-------" + "\n");

        Disposal.Send0("Run " + getName() + ":" + isToggled());
    }

    public void addValue(final Value... values) {
        for (final Value value : values) {
            this.getValues().add(value);
        }
    }

    public void setModes(final String Name,String mode) {
        if (!this.getValues().isEmpty()) {
            for (final Value value : this.values) {
                if (value.getName().equals(Name)){
                    if (value instanceof BooleanValue) {
                        switch (mode) {
                            case "true":
                                value.setValue(true);
                                break;
                            case "false":
                                value.setValue(false);
                                break;
                            case "Auto":
                                boolean temp = (boolean) value.getValue();
                                value.setValue(!temp);
                                break;
                        }
                    }else if (value instanceof NumberValue) {
                        value.setValue(Double.valueOf(mode));
                    }else if (value instanceof ModeValue) {
                        final ModeValue modeValue = (ModeValue) value;
                        for (final Mode modeS : modeValue.getModes()) {
                            modeS.setToggled(mode.equals(modeS.getName()));
                        }
                    }
                }
            }
        }

    }

    public ArrayList<Value> getValues() {
        return this.values;
    }

    public void setKey(final int key) {
        this.key = key;
    }

    public String getRenderName() {
        return this.name;
    }

    public boolean isShow() {
        return this.show;
    }

    public void setShow(final boolean show) {
        this.show = show;
    }

    public void setToggled120(final boolean toggled) {
        Disposal.Send120("Feature initialization " + name + "-" + this.category + ":" + toggled);
        this.toggled = toggled;
    }

    public void ReloadToggled120(final boolean toggled) {
        Disposal.Send120("Run " + name + ":" + toggled);
        this.toggled = toggled;
    }

    public void setToggled(final boolean toggled) {
        Disposal.Send0("Run " + name + ":" + toggled);
        this.toggled = toggled;
    }

    public void setToggledD(final boolean toggled) {
        this.toggled = toggled;
    }


    public int getKey() {
        if (this.key == -1) {
            return 0;
        }
        return this.key;
    }

    public boolean isToggledModeY(final String modeName) {
        for (final Value value : this.values) {
            if (value instanceof ModeValue) {
                final ModeValue modeValue = (ModeValue)value;
                for (final Mode mode : modeValue.getModes()) {
                    if (mode.getName().equalsIgnoreCase(modeName) && mode.isToggled()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public String onToggledMode(final String Name) {
        for (final Value value : this.values) {
            if (value.getName().equals(Name)){
                if (value instanceof ModeValue) {
                    final ModeValue modeValue = (ModeValue) value;
                    for (final Mode modeS : modeValue.getModes()) {
                        if (modeS.isToggled()){
                            return modeS.getName();
                        }
                    }
                }
            }
        }
        return "";
    }


    public Double isNumberValue(final String NumberValue) {
        for (final Value value : this.values) {
            if (value.getName().equals(NumberValue)){
                if (value instanceof NumberValue) {
                    final NumberValue numbervalue = (NumberValue)value;
                    return numbervalue.getValue();
                }
            }
        }
        return 0.0;
    }

    public boolean isBooleanValue(final String BooleanValue) {
        for (final Value value : this.values) {
            if (value.getName().equals(BooleanValue)){
                if (value instanceof BooleanValue) {
                    final BooleanValue booleanValue = (BooleanValue)value;
                    return booleanValue.getValue();
                }
            }
        }
        return false;
    }

    public boolean isToggled() {
        return this.toggled;
    }

    public boolean isToggled2() {
        Disposal.Send120("Feature initialization " + name + "-" + this.category + ":" + toggled);
        return this.toggled;
    }

    public HackCategory isCategory(){
        return this.category;
    }

    public String getName() {
        return this.name;
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public boolean onPacket(final Object packet, final Connection.Side side) {
        return true;
    }

    public void onClientTick(final TickEvent.ClientTickEvent event) {
    }

    public void onLeftClickBlock(final Object event) {
    }

    public void onRightClickItem(final Object event) {
    }

    public void onAttackEntity(final AttackEntityEvent event) {
    }

    public void onPlayerMove(final PlayerEvent.LivingUpdateEvent event) {
    }

    public void onLivingUpdate(final LivingEvent.LivingUpdateEvent event) {
    }

    public void onCameraSetup(final EntityViewRenderEvent.CameraSetup event) {
    }

    public void onRenderGameOverlay(final RenderGameOverlayEvent.Text event) {
    }

    public void onMouse(final MouseEvent event) {
    }

    public void onInputUpdate(final Object event) {
    }


    public boolean isToggledValue(final String valueName) {
        for (final Value value : this.values) {
            if (value instanceof BooleanValue) {
                final BooleanValue booleanValue = (BooleanValue)value;
                if (booleanValue.getName().equalsIgnoreCase(valueName) && booleanValue.getValue()) {
                    return true;
                }
                continue;
            }
        }
        return false;
    }

    public void onRenderWorldLast(final RenderWorldLastEvent event) {
    }

    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
    }

    public void onRender3D(final RenderBlockOverlayEvent event) {
    }
}
