package Nirvana.utils;

import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;

public class SPacket {
    public static CPacketEntityAction CPacketEntityAction(Entity entityIn, CPacketEntityAction.Action actionIn){
        return new CPacketEntityAction(entityIn, actionIn);
    }

    public static CPacketUseEntity CPacketUseEntity(Entity entityIn){
        return new CPacketUseEntity(entityIn);
    }

    public static CPacketPlayer.PositionRotation CPacketPlayerPositionRotation(double posX, double minY, double posZ, float submitYaw, float submitPitch, boolean onGround){
        return new CPacketPlayer.PositionRotation(posX, minY, posZ, submitYaw, submitPitch, onGround);
    }

    public static CPacketPlayer.Position CPacketPlayerPosition(double xIn, double yIn, double zIn, boolean onGroundIn){
        return new CPacketPlayer.Position(xIn, yIn, zIn, onGroundIn);
    }

    public static CPacketEntityAction.Action CPacketEntityAction_STOP_SPRINTING(){
        return CPacketEntityAction.Action.STOP_SPRINTING;
    }

    public static CPacketEntityAction.Action CPacketEntityActionSTOP_SNEAKING(){
        return CPacketEntityAction.Action.STOP_SNEAKING;
    }

    public static CPacketEntityAction.Action CPacketEntityActionSTART_SNEAKING(){
        return CPacketEntityAction.Action.START_SNEAKING;
    }

    public static CPacketEntityAction.Action CPacketEntityAction_START_SPRINTING(){
        return CPacketEntityAction.Action.START_SPRINTING;
    }

    public static CPacketEntityAction.Action CPacketEntityAction_STOP_SNEAKING(){
        return CPacketEntityAction.Action.STOP_SNEAKING;
    }

    public static CPacketEntityAction.Action CPacketEntityAction_START_SNEAKING(){
        return CPacketEntityAction.Action.START_SNEAKING;
    }

}
