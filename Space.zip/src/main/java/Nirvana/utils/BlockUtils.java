package Nirvana.utils;

import Nirvana.Wrapper;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public final class BlockUtils
{
    
    public static IBlockState getState(final BlockPos pos) {
        return  Wrapper.world().getBlockState(pos);
    }
    
    public static Block getBlock(final BlockPos pos) {
        return getState(pos).getBlock();
    }

    public static boolean isBlockMaterial(final BlockPos blockPos) {
        return getBlock(blockPos) == Blocks.AIR;
    }

}
