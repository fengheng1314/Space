package Nirvana.utils;

import Nirvana.Wrapper;
import Space.utils.Mapping;
import Space.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.ClickType;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;

import java.lang.reflect.Field;

public class SUtils {

    public static BlockPos EventPos(final Object event){
        if (event instanceof PlayerInteractEvent.LeftClickBlock) {
            return ((PlayerInteractEvent.LeftClickBlock) event).getPos();
        }
        return null;
    }

    public static boolean AttackCooldown(){
        return Wrapper.player().getCooledAttackStrength(0.0f) == 1.0f;
    }

    public static float getPartialTicks(final RenderWorldLastEvent event){
        return event.getPartialTicks();
    }

    public static Entity getTarget(final AttackEntityEvent event){
        return event.getTarget();
    }

    public static float getPitch(final Entity entity) {
        double y = entity.posY - Wrapper.player().posY;
        y /= Wrapper.player().getDistanceSq(entity);
        double pitch = Math.asin(y) * 57.29577951308232;
        pitch = -pitch;
        return (float) pitch;
    }

    public static float[] getTargetRotations(Entity q) {
        if (q == null) {
            return null;
        } else {
            double diffX = q.posX - Wrapper.player().posX;
            double diffY;
            if (q instanceof EntityLivingBase) {
                EntityLivingBase en = (EntityLivingBase) q;
                diffY = en.posY + (double) en.getEyeHeight() * 0.9D - (Wrapper.player().posY + (double) Wrapper.player().getEyeHeight());
            } else {
                diffY = (q.getEntityBoundingBox().minY + q.getEntityBoundingBox().maxY) / 2.0D - (Wrapper.player().posY + (double) Wrapper.player().getEyeHeight());
            }

            double diffZ = q.posZ - Wrapper.player().posZ;
            double dist = MathHelper.sqrt(diffX * diffX + diffZ * diffZ);
            float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / 3.141592653589793D) - 90.0F;
            float pitch = (float) (-(Math.atan2(diffY, dist) * 180.0D / 3.141592653589793D));
            return new float[]{Wrapper.player().rotationYaw + Utils.wrapAngleTo180_float(yaw - Wrapper.player().rotationYaw),
                    Wrapper.player().rotationPitch + Utils.wrapAngleTo180_float(pitch - Wrapper.player().rotationPitch)};
        }
    }

    public static void placeBlockScaffold(final BlockPos pos) {

        final Vec3d eyesPos = new Vec3d(Wrapper.player().posX, Wrapper.player().posY + Wrapper.player().getEyeHeight(), Wrapper.player().posZ);
        EnumFacing[] values;
        for (int length = (values = EnumFacing.values()).length, i = 0; i < length; ++i) {
            final EnumFacing side = values[i];
            final BlockPos neighbor = pos.offset(side);
            final EnumFacing side2 = side.getOpposite();
            if (eyesPos.squareDistanceTo(new Vec3d(pos).addVector(0.5, 0.5, 0.5)) < eyesPos.squareDistanceTo(new Vec3d(neighbor).addVector(0.5, 0.5, 0.5)) && canBeClicked(neighbor)) {
                final Vec3d hitVec = new Vec3d(neighbor).addVector(0.5, 0.5, 0.5).add(new Vec3d(side2.getDirectionVec()).scale(0.5));
                if (eyesPos.squareDistanceTo(hitVec) <= 18.0625) {
                    faceVectorPacketInstant(hitVec);
                    Utils.swingMainHand();
                    Wrapper.controller().processRightClickBlock(Wrapper.player(), Wrapper.world(), neighbor, side2, hitVec, EnumHand.MAIN_HAND);
                    try {
                        final Field f = Minecraft.class.getDeclaredField(Mapping.rightClickDelayTimer);
                        f.setAccessible(true);
                        f.set(Wrapper.mc(), 4);
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                    return;
                }
            }
        }
    }

    public static void faceVectorPacketInstant(final Vec3d vec) {
        Utils.rotationsToBlock = getNeededRotations(vec);
    }

    public static boolean canBeClicked(final BlockPos pos) {
        return BlockUtils.getBlock(pos).canCollideCheck(BlockUtils.getState(pos), false);
    }

    public static void swing() {
        EntityPlayer p = Wrapper.player();
        int armSwingEnd = p.isPotionActive(MobEffects.HASTE) ? 6 - (1 + p.getActivePotionEffect(MobEffects.HASTE).getAmplifier()) : (p.isPotionActive(MobEffects.MINING_FATIGUE) ? 6 + (1 + p.getActivePotionEffect(MobEffects.MINING_FATIGUE).getAmplifier()) * 2 : 6);
        if (!p.isSwingInProgress || p.swingProgressInt >= armSwingEnd / 2 || p.swingProgressInt < 0) {
            p.swingProgressInt = -1;
            p.isSwingInProgress = true;
        }
    }

    public static float updateRotation(final float angle, final float targetAngle, final float maxIncrease) {
        float var4 = MathHelper.wrapDegrees(targetAngle - angle);
        if (var4 > maxIncrease) {
            var4 = maxIncrease;
        }
        if (var4 < -maxIncrease) {
            var4 = -maxIncrease;
        }
        return angle + var4;
    }

    public static int getDistanceFromMouse(final EntityLivingBase entity) {
        final float[] neededRotations = Utils.getRotationsNeeded(entity);
        if (neededRotations != null) {
            final float neededYaw = Wrapper.player().rotationYaw - neededRotations[0];
            final float neededPitch = Wrapper.player().rotationPitch - neededRotations[1];
            final float distanceFromMouse = MathHelper.sqrt(neededYaw * neededYaw + neededPitch * neededPitch * 2.0f);
            return (int)distanceFromMouse;
        }
        return -1;
    }

    public static float[] getNeededRotations(final Vec3d vec) {
        final Vec3d eyesPos = getEyesPos();
        final double diffX = vec.x - eyesPos.x;
        final double diffY = vec.y - eyesPos.y;
        final double diffZ = vec.z - eyesPos.z;
        final double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        final float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        final float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[] { Wrapper.player().rotationYaw + MathHelper.wrapDegrees(yaw - Wrapper.player().rotationYaw), Wrapper.player().rotationPitch + MathHelper.wrapDegrees(pitch - Wrapper.player().rotationPitch) };
    }

    public static float[] getRotationsNeeded(final Entity entity) {
        if (entity == null) {
            return null;
        }
        final double diffX = entity.posX - Wrapper.player().posX;
        final double diffZ = entity.posZ - Wrapper.player().posZ;
        double diffY;
        if (entity instanceof EntityLivingBase) {
            final EntityLivingBase entityLivingBase = (EntityLivingBase)entity;
            diffY = entityLivingBase.posY + entityLivingBase.getEyeHeight() - (Wrapper.player().posY + Wrapper.player().getEyeHeight());
        }
        else {
            diffY = (entity.getEntityBoundingBox().minY + entity.getEntityBoundingBox().maxY) / 2.0 - (Wrapper.player().posY + Wrapper.player().getEyeHeight());
        }
        final double dist = MathHelper.sqrt(diffX * diffX + diffZ * diffZ);
        final float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 90.0f;
        final float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / 3.141592653589793));
        return new float[] { Wrapper.player().rotationYaw + MathHelper.wrapDegrees(yaw - Wrapper.player().rotationYaw), Wrapper.player().rotationPitch + MathHelper.wrapDegrees(pitch - Wrapper.player().rotationPitch) };
    }

    public static Vec3d getEyesPos() {
        return new Vec3d(Wrapper.player().posX, Wrapper.player().posY + Wrapper.player().getEyeHeight(), Wrapper.player().posZ);
    }

    public static void swingMainHand() {
        Wrapper.player().swingArm(EnumHand.MAIN_HAND);
    }

    public static void windowClick(final int windowId, final int slotId, final int mouseButton, final Object type) {
        Wrapper.controller().windowClick(windowId, slotId, mouseButton, (ClickType) type, Wrapper.player());
    }

    public static void removeEffect(final int id) {
        Wrapper.player().removePotionEffect(Potion.getPotionById(id));
    }

    public static void addEffect(final int id, final int duration, final int amplifier) {
        Wrapper.player().addPotionEffect(new PotionEffect(Potion.getPotionById(id), duration, amplifier));
    }
}
