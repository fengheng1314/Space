package Nirvana.utils;

import Nirvana.Wrapper;
import Space.utils.EnumChatFormatting;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
public class ChatUtils
{
    public static void component(final ITextComponent component) {
        Wrapper.mc().ingameGUI.getChatGUI().printChatMessage(new TextComponentString(EnumChatFormatting.RED + "[" + EnumChatFormatting.GOLD + "Space" + EnumChatFormatting.RED + "]" + EnumChatFormatting.WHITE + " ").appendSibling(component));
    }

    public static void message(final String message) {
        component(new TextComponentString(message));
    }
    
    public static void warning(final String message) {
        message(EnumChatFormatting.RED + "[" + EnumChatFormatting.GOLD + EnumChatFormatting.BOLD + "WARNING" + EnumChatFormatting.RED + "]" + EnumChatFormatting.WHITE + " " + message);
    }
    
    public static void error(final String message) {
        message(EnumChatFormatting.RED + "[" + EnumChatFormatting.DARK_RED + "" + EnumChatFormatting.BOLD + "ERROR" + EnumChatFormatting.RED + "]" + EnumChatFormatting.WHITE + " " + message);
    }
    
    public static void success(final String message) {
        message(EnumChatFormatting.GREEN + "[" + EnumChatFormatting.DARK_GREEN + EnumChatFormatting.BOLD + "SUCCESS" + EnumChatFormatting.GREEN + "]" + EnumChatFormatting.WHITE + " " + message);
    }

}
