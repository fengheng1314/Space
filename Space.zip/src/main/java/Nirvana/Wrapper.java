package Nirvana;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.network.Packet;

public class Wrapper
{

    public static String version = "2.00-1.12.2";
    public static String version2 = "1.12.2";

    public static Minecraft mc() {
        return Minecraft.getMinecraft();
    }

    public static FontRenderer fontRenderer() {
        return mc().fontRenderer;
    }
    
    public static EntityPlayerSP player() {
        return mc().player;
    }

    public static WorldClient world() {
        return mc().world;
    }

    public static void sendPacket(final Packet packet) {
        player().connection.sendPacket(packet);
    }

    public static InventoryPlayer inventory() {
        return player().inventory;
    }

    public static PlayerControllerMP controller() {
        return mc().playerController;
    }

    public static float getDistance(final EntityLivingBase entity){
        return Wrapper.player().getDistance(entity);
    }

    public static float getDistance(final Entity entity){
        return Wrapper.player().getDistance(entity);
    }

}
