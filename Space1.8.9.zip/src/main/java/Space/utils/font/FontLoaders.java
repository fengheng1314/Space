/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https://github.co m/fengheng1314/Space
 */
package Space.utils.font;

import java.awt.*;

public abstract class FontLoaders
{
    public static CFontRenderer default18 = new CFontRenderer(new Font("default", 0, 18), true, true);
    public static CFontRenderer default29 = new CFontRenderer(new Font("default", 0, 29), true, true);
    public static CFontRenderer default14 = new CFontRenderer(new Font("default", 0, 14), true, true);
    public static CFontRenderer SFB17 = new CFontRenderer(getSFB(17), true, true);
    
    private static Font getSFB(final int size) {
        return new Font("default", 0, size);
    }

}
