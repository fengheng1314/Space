/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https://github.com/fengh eng1314/Space
 */
package Space.utils.eventapi.events;

public interface Event
{
}
