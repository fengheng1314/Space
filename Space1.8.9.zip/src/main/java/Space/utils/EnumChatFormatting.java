/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https://github .com/fengheng1314/Space
 */
package Space.utils;

import java.util.HashMap;
import java.util.Map;

public enum EnumChatFormatting
{
    BLACK('0'), 
    DARK_BLUE('1'), 
    DARK_GREEN('2'), 
    DARK_AQUA('3'), 
    DARK_RED('4'), 
    DARK_PURPLE('5'), 
    GOLD('6'), 
    GRAY('7'), 
    DARK_GRAY('8'), 
    BLUE('9'), 
    GREEN('a'), 
    AQUA('b'), 
    RED('c'), 
    LIGHT_PURPLE('d'), 
    YELLOW('e'), 
    WHITE('f'), 
    OBFUSCATED('k', true), 
    BOLD('l', true), 
    STRIKETHROUGH('m', true), 
    UNDERLINE('n', true), 
    ITALIC('o', true), 
    RESET('r');
    
    private static final Map formattingCodeMapping;
    private static final Map nameMapping;
    private final char formattingCode;
    private final String controlString;

    
    EnumChatFormatting(final char p_i1336_3_) {
        this(p_i1336_3_, false);
    }

    EnumChatFormatting(final char p_i1337_3_, final boolean p_i1337_4_) {
        this.formattingCode = p_i1337_3_;
        this.controlString = "\u00A7" + p_i1337_3_;
    }
    
    public char getFormattingCode() {
        return this.formattingCode;
    }
    
    public String getFriendlyName() {
        return this.name().toLowerCase();
    }
    
    @Override
    public String toString() {
        return this.controlString;
    }

    static {
        formattingCodeMapping = new HashMap();
        nameMapping = new HashMap();
        for (final EnumChatFormatting var4 : values()) {
            EnumChatFormatting.formattingCodeMapping.put(var4.getFormattingCode(), var4);
            EnumChatFormatting.nameMapping.put(var4.getFriendlyName(), var4);
        }
    }
}
