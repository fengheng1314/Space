/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https://github.c om/fengheng1314/Space
 */
package Space.utils.ui;

import Nirvana.Wrapper;
import Nirvana.utils.SUtils;
import Nirvana.utils.ui.SRenderUtils;
import Space.utils.TimerUtils;
import Space.utils.Utils;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class RenderUtils
{
    public static TimerUtils splashTimer;
    public static int splashTickPos;
    public static boolean isSplash;
    private static final Map<Integer, Boolean> glCapMap = new HashMap<>();
    public static void drawBorderedRect(final double x, final double y, final double x2, final double y2, final int col) {
        drawRect((int)x, (int)y, (int)x2, (int)y2, col);

        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);

        GL11.glLineWidth(1.0f);

        GL11.glBegin(GL11.GL_LINE_LOOP);

        GL11.glVertex2d(x, y);
        GL11.glVertex2d(x, y2);
        GL11.glVertex2d(x2, y2);
        GL11.glVertex2d(x2, y);

        GL11.glEnd();

        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
    }

    public static void CircleSpace(EntityLivingBase target, final RenderWorldLastEvent event) {
        float red = 71;
        float Green = 41;
        float Blue = 32;
        float Alpha = 255;
        float Accuracy = 20;

        if(Utils.IsNull(target)){return;}
        GL11.glPushMatrix();
        GL11.glTranslated(
                target.lastTickPosX + (target.posX - target.lastTickPosX) * Wrapper.player().lastTickPosY - Wrapper.mc().getRenderManager().viewerPosX,
                Wrapper.player().lastTickPosY + (Wrapper.player().posY - Wrapper.player().lastTickPosY) * Wrapper.player().lastTickPosY - Wrapper.mc().getRenderManager().viewerPosY,
                target.lastTickPosZ + (target.posZ - target.lastTickPosZ) * Wrapper.player().lastTickPosY - Wrapper.mc().getRenderManager().viewerPosZ
        );

        GL11.glEnable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        GL11.glLineWidth(1F);
        GL11.glColor4f(red / 255.0F, Green / 255.0F, Blue / 255.0F, Alpha / 255.0F);
        GL11.glRotatef(90F, 1F, 0F, 0F);
        GL11.glBegin(GL11.GL_LINE_STRIP);

        for (int i = 0; i <= 360; i += 61 - Accuracy) {
            GL11.glVertex2f((float) (Math.cos(i * Math.PI / 180.0) * 2.8), (float) (Math.sin(i * Math.PI / 180.0) * 2.8));
            GL11.glVertex2f((float) (Math.cos(360 * Math.PI / 180.0) * 2.8), (float) (Math.sin(360 * Math.PI / 180.0) * 2.8));
        }
        GL11.glEnd();

        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);

        GL11.glPopMatrix();
    }

    public static void SCircle(String text, EntityLivingBase target, final RenderWorldLastEvent event){
        if (text.equals("Normal")) {
            RenderUtils.CircleNormal(4, event);
        }else if (text.equals("Space") && !Utils.IsNull(target)) {
            RenderUtils.CircleSpace(target, event);
        }else if (text.equals("FDP")){
            RenderUtils.CircleFDP(4, event);
        }
    }

    public static void SMark(String text, EntityLivingBase target, final RenderWorldLastEvent event){
        SRenderUtils.SMark(text, target, event);
    }

    public static void drawRoundedCornerRect(float x, float y, float x1, float y1, float radius, int color) {
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        final boolean hasCull = GL11.glIsEnabled(GL11.GL_CULL_FACE);
        GL11.glDisable(GL11.GL_CULL_FACE);

        glColor(color);
        drawRoundedCornerRect(x, y, x1, y1, radius);

        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        setGlState(GL11.GL_CULL_FACE, hasCull);
    }

    public static void drawRoundedCornerRect(float x, float y, float x1, float y1, float radius) {
        GL11.glBegin(GL11.GL_POLYGON);

        float xRadius = (float) Math.min((x1 - x) * 0.5, radius);
        float yRadius = (float) Math.min((y1 - y) * 0.5, radius);
        quickPolygonCircle(x + xRadius,y + yRadius, xRadius, yRadius,180,270);
        quickPolygonCircle(x1 - xRadius,y + yRadius, xRadius, yRadius,90,180);
        quickPolygonCircle(x1 - xRadius,y1 - yRadius, xRadius, yRadius,0,90);
        quickPolygonCircle(x + xRadius,y1 - yRadius, xRadius, yRadius,270,360);

        GL11.glEnd();
    }

    private static void quickPolygonCircle(float x, float y, float xRadius, float yRadius, int start, int end) {
        for(int i = end; i >= start; i -= 4) {
            GL11.glVertex2d(x + Math.sin(i * Math.PI / 180.0D) * xRadius, y + Math.cos(i * Math.PI / 180.0D) * yRadius);
        }
    }

    public static void drawCircle(final Entity entity, final float partialTicks, final float pos) {
        GL11.glPushMatrix();
        GL11.glEnable(3042);
        GL11.glDisable(2929);
        GL11.glDisable(3553);
        GL11.glShadeModel(7425);
        GL11.glLineWidth(1.0f);
        final double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * partialTicks - Wrapper.mc().getRenderManager().viewerPosX;
        final double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * partialTicks - Wrapper.mc().getRenderManager().viewerPosY + pos;
        final double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * partialTicks - Wrapper.mc().getRenderManager().viewerPosZ;
        GL11.glBegin(3);
        for (int i = 0; i <= 180; ++i) {
            final double c1 = i * 3.141592653589793 * 2.0 / 180.0;
            GlStateManager.color(2.0f, 1.0f, 1.0f, 1.0f);
            GL11.glVertex3d(x + 0.5 * Math.cos(c1), y, z + 0.5 * Math.sin(c1));
        }
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glShadeModel(7424);
        GL11.glEnable(2929);
        GL11.glDisable(3042);
        GL11.glPopMatrix();
    }

    public static void drawShadow(final Entity entity, final float partialTicks, final float pos, final boolean direction) {
        GL11.glPushMatrix();
        GL11.glEnable(3042);
        GL11.glDisable(2929);
        GL11.glDisable(3553);
        GL11.glShadeModel(7425);
        final double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * partialTicks - Wrapper.mc().getRenderManager().viewerPosX;
        final double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * partialTicks - Wrapper.mc().getRenderManager().viewerPosY + pos;
        final double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * partialTicks - Wrapper.mc().getRenderManager().viewerPosZ;
        GL11.glBegin(8);
        for (int i = 0; i <= 180; ++i) {
            final double c1 = i * 3.141592653589793 * 2.0 / 180.0;
            final double c2 = (i + 1) * 3.141592653589793 * 2.0 / 180.0;
            GlStateManager.color(1.0f, 1.0f, 1.0f, 0.3f);
            GL11.glVertex3d(x + 0.5 * Math.cos(c1), y, z + 0.5 * Math.sin(c1));
            GL11.glVertex3d(x + 0.5 * Math.cos(c2), y, z + 0.5 * Math.sin(c2));
            GlStateManager.color(1.0f, 1.0f, 1.0f, 0.0f);
            GL11.glVertex3d(x + 0.5 * Math.cos(c1), y + (direction ? -0.2 : 0.2), z + 0.5 * Math.sin(c1));
            GL11.glVertex3d(x + 0.5 * Math.cos(c2), y + (direction ? -0.2 : 0.2), z + 0.5 * Math.sin(c2));
        }
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glShadeModel(7424);
        GL11.glEnable(2929);
        GL11.glDisable(3042);
        GL11.glPopMatrix();
    }
    
    public static double easeInOutQuad(double x) {
        if (x < 0.5) {
            return 2 * x * x;
        } else {
            return 1 - Math.pow(-2 * x + 2, 2) / 2;
        }
    }

    public static void enableGlCap(final int cap) {
        setGlCap(cap, true);
    }

    public static void resetCaps() {
        glCapMap.forEach(RenderUtils::setGlState);
    }

    public static void setGlState(final int cap, final boolean state) {
        if (state)
            GL11.glEnable(cap);
        else
            GL11.glDisable(cap);
    }

    public static void setGlCap(final int cap, final boolean state) {
        glCapMap.put(cap, GL11.glGetBoolean(cap));
        setGlState(cap, state);
    }

    public static void drawEntityBox(final Entity entity, final Color color, final boolean outline, final RenderWorldLastEvent event) {
        SRenderUtils.drawEntityBox(entity, color, outline, event);
    }

    public static void glColor(final int red, final int green, final int blue, final int alpha) {
        GL11.glColor4f(red / 255F, green / 255F, blue / 255F, alpha / 255F);
    }

    public static void disableGlCap(final int... caps) {
        for (final int cap : caps)
            setGlCap(cap, false);
    }

    public static void CircleNormal(double Range, final RenderWorldLastEvent event) {
        float red = 255;
        float Green = 255;
        float Blue = 255;
        float Alpha = 255;
        float Accuracy = 60;

        GL11.glPushMatrix();
        GL11.glTranslated(
                Wrapper.player().lastTickPosX + (Wrapper.player().posX - Wrapper.player().lastTickPosX) * SUtils.getPartialTicks(event) - Wrapper.mc().getRenderManager().viewerPosX,
                Wrapper.player().lastTickPosY + (Wrapper.player().posY - Wrapper.player().lastTickPosY) * SUtils.getPartialTicks(event) - Wrapper.mc().getRenderManager().viewerPosY,
                Wrapper.player().lastTickPosZ + (Wrapper.player().posZ - Wrapper.player().lastTickPosZ) * SUtils.getPartialTicks(event) - Wrapper.mc().getRenderManager().viewerPosZ
        );
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        GL11.glLineWidth(2F);
        GL11.glColor4f(red / 255.0F, Green / 255.0F, Blue / 255.0F, Alpha / 255.0F);
        GL11.glRotatef(-Wrapper.player().rotationYaw, 0.0F, 1.0F, 0.0F);
        GL11.glBegin(GL11.GL_LINE_LOOP);

        for (int i = 0; i <= 360; i += 61 - Accuracy) {
            double x = Math.sin(i * Math.PI / 180) * Range;
            double z = Math.cos(i * Math.PI / 180) * Range;
            GL11.glVertex3d(x, 0, z);
        }
        GL11.glEnd();

        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    public static void CircleFDP(double Range, final RenderWorldLastEvent event) {
        float Accuracy = 60;

        GL11.glPushMatrix();
        GL11.glTranslated(
                Wrapper.player().lastTickPosX + (Wrapper.player().posX - Wrapper.player().lastTickPosX) * SUtils.getPartialTicks(event) - Wrapper.mc().getRenderManager().viewerPosX,
                Wrapper.player().lastTickPosY + (Wrapper.player().posY - Wrapper.player().lastTickPosY) * SUtils.getPartialTicks(event) - Wrapper.mc().getRenderManager().viewerPosY,
                Wrapper.player().lastTickPosZ + (Wrapper.player().posZ - Wrapper.player().lastTickPosZ) * SUtils.getPartialTicks(event) - Wrapper.mc().getRenderManager().viewerPosZ
        );
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        double radius = (Wrapper.player().getEntityBoundingBox().maxX - Wrapper.player().getEntityBoundingBox().minX) + 0.3;
        GL11.glLineWidth((float)(radius * 5));

        //GL11.glLineWidth(2F);
        GL11.glRotatef(-Wrapper.player().rotationYaw, 0.0F, 1.0F, 0.0F);
        GL11.glBegin(GL11.GL_LINE_LOOP);

        for (int i = 0; i <= 360; i += 61 - Accuracy) {
            float[] hsv = new float[]{(float) ((Wrapper.player().ticksExisted / 70.0f + Math.sin(i / 50.0 * 1.75)) % 1.0f), 0.7f, 1.0f};
            int color = Color.HSBtoRGB(hsv[0], hsv[1], hsv[2]);
            float red = ((color >> 16) & 0xFF) / 255.0f;
            float green = ((color >> 8) & 0xFF) / 255.0f;
            float blue = (color & 0xFF) / 255.0f;
            GL11.glColor3f(red, green, blue);


            double x = Math.sin(i * Math.PI / 180) * Range;
            double z = Math.cos(i * Math.PI / 180) * Range;
            GL11.glVertex3d(x, 0, z);
        }
        GL11.glEnd();

        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    public static void drawBlockESP(final Object pos, final float red, final float green, final float blue) {
        SRenderUtils.drawBlockESP(pos, red, green, blue);
    }

    public static void drawSelectionBoundingBox(final Object boundingBox) {
        SRenderUtils.drawSelectionBoundingBox(boundingBox);
    }

    public static void drawColorBox(final Object axisalignedbb, final float red, final float green, final float blue, final float alpha) {
        SRenderUtils.drawColorBox(axisalignedbb, red, green, blue, alpha);
    }

    public static void color(final int color) {
        final float f = (color >> 24 & 0xFF) / 255.0f;
        final float f2 = (color >> 16 & 0xFF) / 255.0f;
        final float f3 = (color >> 8 & 0xFF) / 255.0f;
        final float f4 = (color & 0xFF) / 255.0f;
        GL11.glColor4f(f2, f3, f4, f);
    }

    public static void glColor(final int color) {
        GlStateManager.color((color >> 16 & 0xFF) / 255.0f, (color >> 8 & 0xFF) / 255.0f, (color & 0xFF) / 255.0f, (color >> 24 & 0xFF) / 255.0f);
    }

    public static void drawRect(float left, float top, float right, float bottom, final int color) {
        if (left < right) {
            final float var5 = left;
            left = right;
            right = var5;
        }
        if (top < bottom) {
            final float var5 = top;
            top = bottom;
            bottom = var5;
        }
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(2848);
        GL11.glPushMatrix();
        glColor(color);
        GL11.glBegin(7);
        GL11.glVertex2d(left, bottom);
        GL11.glVertex2d(right, bottom);
        GL11.glVertex2d(right, top);
        GL11.glVertex2d(left, top);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable(3553);
        GL11.glDisable(2848);
    }

    public static void drawTracer(final Entity entity, final float red, final float green, final float blue, final float alpha, final float ticks) {
        SRenderUtils.drawTracer(entity, red, green, blue, alpha, ticks);
    }

    static {
        RenderUtils.splashTimer = new TimerUtils();
        RenderUtils.splashTickPos = 0;
        RenderUtils.isSplash = false;
    }

}