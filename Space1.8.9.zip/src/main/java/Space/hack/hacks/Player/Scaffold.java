package Space.hack.hacks.Player;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SScaffold;
import Nirvana.utils.SUtils;
import Space.hack.HackCategory;
import Space.utils.Utils;
import Space.utils.ui.RenderUtils;
import Space.value.BooleanValue;
import Space.value.Mode;
import Space.value.ModeValue;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Scaffold extends Hack
{
    public ModeValue mode;
    public BooleanValue Mark;
    public ModeValue AutoBlock;
    int Spoof = -1;
    

    public Scaffold() {
        super("Scaffold", HackCategory.Player, false);
        this.mode = new ModeValue("Mode", new Mode("Simple", true), new Mode("AAC", false));
        this.AutoBlock = new ModeValue("AutoBlock", new Mode("Keep", true), new Mode("Spoof", false), new Mode("Off", false));
        this.Mark = new BooleanValue("Mark", true);
        this.addValue(this.mode, this.AutoBlock, this.Mark);
        SScaffold.blockDown = null;
    }

    @Override
    public void onEnable() {
        SScaffold.blockDown = null;
        this.Spoof = -1;
    }

    @Override
    public void onDisable() {
        if(this.mode.getMode("AAC").isToggled()){
            KeyBinding.setKeyBindState(Wrapper.mc().gameSettings.keyBindSneak.getKeyCode(), false);
            KeyBinding.setKeyBindState(Wrapper.mc().gameSettings.keyBindBack.getKeyCode(), false);
        }

        if (this.AutoBlock.getMode("Spoof").isToggled() && this.Spoof != -1){
            Wrapper.inventory().currentItem = Spoof;
        }
    }

    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (this.mode.getMode("AAC").isToggled()){
            KeyBinding.setKeyBindState(Wrapper.mc().gameSettings.keyBindRight.getKeyCode(), false);
            KeyBinding.setKeyBindState(Wrapper.mc().gameSettings.keyBindLeft.getKeyCode(), false);
            KeyBinding.setKeyBindState(Wrapper.mc().gameSettings.keyBindBack.getKeyCode(), true);
        }

        int oldSlot = -1;
        if(!this.AutoBlock.getMode("Off").isToggled()){
            SScaffold.blockDown = SScaffold.Off();
            if (SScaffold.Material()) {
                return;
            }
            final int newSlot = SScaffold.findSlotWithBlock();
            if (newSlot == -1) {
                return;
            }
            oldSlot = Wrapper.inventory().currentItem;
            Wrapper.inventory().currentItem = newSlot;
            if (this.AutoBlock.getMode("Spoof").isToggled() && this.Spoof == -1){
                this.Spoof = oldSlot;
            }
        }

            if (this.mode.getMode("Simple").isToggled()) {
                SUtils.placeBlockScaffold(SScaffold.blockDown);
            }else if (this.mode.getMode("AAC").isToggled()){
                AAC();
            }

        if (this.AutoBlock.getMode("Keep").isToggled() && oldSlot != -1) {
            Wrapper.inventory().currentItem = oldSlot;
        }

    }

    void AAC() {
        Wrapper.player().rotationPitch = Utils.updateRotation(Wrapper.player().rotationPitch, 82.0F, 15.0F);
        KeyBinding.onTick(Wrapper.mc().gameSettings.keyBindUseItem.getKeyCode());
    }

    @Override
    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        if (this.mode.getMode("AAC").isToggled()){
            Eagle.eagle();
        }
    }

    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        if(!Mark.getValue()){return;}
        if (SScaffold.blockDown != null) {
            RenderUtils.drawBlockESP(SScaffold.blockDown, 1.0f, 1.0f, 1.0f);
            if (this.mode.getMode("AAC").isToggled()) {
                SScaffold.blockpos = SScaffold.onRenderWorldLast();
                SScaffold.blockpos1 = SScaffold.onRenderWorldLast();

                if (Wrapper.player().getHorizontalFacing() == EnumFacing.EAST) {
                    SScaffold.blockpos = SScaffold.onRenderWorldLast().west();
                    SScaffold.blockpos1 = SScaffold.onRenderWorldLast().west(2);
                } else if (Wrapper.player().getHorizontalFacing() == EnumFacing.NORTH) {
                    SScaffold.blockpos = SScaffold.onRenderWorldLast().south();
                    SScaffold.blockpos1 = SScaffold.onRenderWorldLast().south(2);
                } else if (Wrapper.player().getHorizontalFacing() == EnumFacing.SOUTH) {
                    SScaffold.blockpos = SScaffold.onRenderWorldLast().north();
                    SScaffold.blockpos1 = SScaffold.onRenderWorldLast().north(2);
                } else if (Wrapper.player().getHorizontalFacing() == EnumFacing.WEST) {
                    SScaffold.blockpos = SScaffold.onRenderWorldLast().east();
                    SScaffold.blockpos1 = SScaffold.onRenderWorldLast().east(2);
                }

                RenderUtils.drawBlockESP(SScaffold.blockpos, 1.0F, 0.0F, 0.0F);
                RenderUtils.drawBlockESP(SScaffold.blockpos1, 1.0F, 0.0F, 0.0F);
            }
        }
    }

}
