package Space.hack.hacks.Player;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SFastPlace;
import Space.hack.HackCategory;
import Space.utils.ReflectionHelper;
import Space.value.BooleanValue;
import Space.value.NumberValue;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.lang.reflect.Field;

public class FastPlace extends Hack {
    final NumberValue delaySlider;
    public BooleanValue OnlyBox;
    public FastPlace() {
        super("FastPlace", HackCategory.Player);
        this.delaySlider = new NumberValue("delaySlider", 0.0, 0.0, 2.0);
        this.OnlyBox = new BooleanValue("OnlyBox", false);
        this.addValue(this.delaySlider,this.OnlyBox);
    }

    @Override
    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        boolean Only = true;
        if(OnlyBox.getValue()) {
            Only = SFastPlace.isHoldingBlock();
        }

        final Field field = ReflectionHelper.findField(Minecraft.class, "field_71467_ac", "rightClickDelayTimer");
        if (Only){
            try {
                field.setInt(Wrapper.mc(), delaySlider.getValue().intValue());
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }

    }
}