package Space.hack.hacks.Player;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SNoFall;
import Nirvana.utils.Connection;
import Space.hack.HackCategory;
import Space.value.Mode;
import Space.value.ModeValue;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class NoFall extends Hack
{
    public ModeValue mode;

    public NoFall() {
        super("NoFall", HackCategory.Player);
        this.mode = new ModeValue("Mode", new Mode("AAC", false), new Mode("Simple", true));
        this.addValue(this.mode);
    }

    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (this.mode.getMode("Simple").isToggled() && Wrapper.player().fallDistance > 2.0f) {
            SNoFall.CPacketPlayer();
        }
    }
    
    @Override
    public boolean onPacket(final Object packet, final Connection.Side side) {
        return SNoFall.onPacket(packet, side);
    }
}
