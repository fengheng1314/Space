package Space.hack.hacks.Player;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SReach;
import Space.hack.HackCategory;
import Space.value.NumberValue;
import net.minecraft.entity.Entity;
import net.minecraftforge.client.event.MouseEvent;

import java.util.Random;

public class Reach extends Hack
{
    private static NumberValue reachMinVal;
    private static NumberValue reachMaxVal;
    public Random r;
    public Reach() {
        super("Reach", HackCategory.Player);
        Reach.reachMinVal = new NumberValue("ReachMin", 4.46, 3.0, 8.0);
        Reach.reachMaxVal = new NumberValue("ReachMax", 5.0, 3.0, 9.0);
        this.r = new Random();
        this.addValue(Reach.reachMinVal, Reach.reachMaxVal);
    }

    @Override
    public void onMouse(final MouseEvent event) {
        if (Wrapper.mc().objectMouseOver != null && Wrapper.mc().objectMouseOver.typeOfHit != null && Wrapper.mc().objectMouseOver.typeOfHit == SReach.RayTraceResultTypeBLOCK()) {
            return;
        }
        final double range = Reach.reachMinVal.getValue() + this.r.nextDouble() * (Reach.reachMaxVal.getValue() - Reach.reachMinVal.getValue());
        final Object[] mouseOver = SReach.getMouseOver(range, 0.0);
        if (mouseOver == null) {
            return;
        }
        Wrapper.mc().objectMouseOver = SReach.RayTraceResult(mouseOver);
        Wrapper.mc().pointedEntity = (Entity)mouseOver[0];
    }

}
