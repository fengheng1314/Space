package Space.hack.hacks.Player;

import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SChatTranslator;
import Nirvana.utils.Connection;
import Space.Disposal;
import Space.hack.HackCategory;
import Space.value.Mode;
import Space.value.ModeValue;

public class ChatTranslator extends Hack {

    public ModeValue mode;

    public ChatTranslator() {
        super("ChatTranslator", HackCategory.Player);
        this.mode = new ModeValue("Mode", new Mode("Strict", true), new Mode("Insist", false));
        this.addValue(this.mode);
    }

    @Override
    public boolean onPacket(final Object packet, final Connection.Side side) {
        if (SChatTranslator.Instanceof(packet)) {

            String msg = SChatTranslator.getmsg(packet);
            if(!msg.contains("<") && !msg.contains(">") && !msg.contains(":")){
                return true;
            }

            if(msg.equals(" ") || msg.equals("0") || msg.equals("\n") || msg.equals("/") || msg.contains("gg") || msg.contains("GG") || msg.contains("----") || msg.contains("====") || msg.contains("+") || msg.contains("    ") || msg.contains("(!)") || msg.contains("joined the ") || msg.contains("lobby") || msg.contains("hub") || msg.contains(" found ") || msg.contains("The game starts") || msg.equals("`") || msg.equals("~") || msg.equals("!") || msg.equals(".") || msg.equals(",") || msg.equals("*") || msg.equals("?")){
                return true;
            }

            if (mode.getMode("Strict").isToggled()) {
                Disposal.Send50("ChatTranslator:[" + msg + "]-Strict");
            }else if (mode.getMode("Insist").isToggled()) {
                Disposal.Send50("ChatTranslator:[" + msg + "]-Insist");
            }

        }
        return true;
    }

}