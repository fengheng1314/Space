package Space.hack.hacks.Player;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SAutoArmor;
import Nirvana.hack.hacks.SChestStealer;
import Nirvana.utils.Connection;
import Space.hack.HackCategory;
import Space.utils.Utils;
import Space.value.BooleanValue;
import Space.value.NumberValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.InventoryEffectRenderer;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class AutoArmor extends Hack
{
    public BooleanValue useEnchantments;
    public BooleanValue swapWhileMoving;
    public NumberValue delay;
    private int timer;
    
    public AutoArmor() {
        super("AutoArmor", HackCategory.Player);
        this.useEnchantments = new BooleanValue("Enchantments", true);
        this.swapWhileMoving = new BooleanValue("SwapWhileMoving", false);
        this.delay = new NumberValue("Delay", 2.0, 0.0, 20.0);
        this.addValue(this.useEnchantments, this.swapWhileMoving, this.delay);
    }
    
    @Override
    public void onEnable() {
        this.timer = 0;
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (this.timer > 0) {
            --this.timer;
            return;
        }
        if (Wrapper.mc().currentScreen instanceof GuiContainer && !(Wrapper.mc().currentScreen instanceof InventoryEffectRenderer)) {
            return;
        }
        final InventoryPlayer inventory = Wrapper.inventory();
        if (!this.swapWhileMoving.getValue() && (Wrapper.player().movementInput.moveForward != 0.0f || Wrapper.player().movementInput.moveStrafe != 0.0f)) {
            return;
        }
        final int[] bestArmorSlots = new int[4];
        final int[] bestArmorValues = new int[4];
        for (int type = 0; type < 4; ++type) {
            bestArmorSlots[type] = -1;
            final ItemStack stack = inventory.armorItemInSlot(type);
            if (stack.getItem() instanceof ItemArmor) {
                final ItemArmor item = (ItemArmor) stack.getItem();
                bestArmorValues[type] = this.getArmorValue(item, stack);
            }
        }
        for (int slot = 0; slot < 36; ++slot) {
            final ItemStack stack = inventory.getStackInSlot(slot);
            if (stack.getItem() instanceof ItemArmor) {
                final ItemArmor item = (ItemArmor) stack.getItem();
                final int armorType = SAutoArmor.armorType(item);
                final int armorValue = this.getArmorValue(item, stack);
                if (armorValue > bestArmorValues[armorType]) {
                    bestArmorSlots[armorType] = slot;
                    bestArmorValues[armorType] = armorValue;
                }
            }
        }
        final ArrayList<Integer> types = new ArrayList<>(Arrays.asList(0, 1, 2, 3));
        Collections.shuffle(types);
        for (final int type2 : types) {
            int slot2 = bestArmorSlots[type2];
            if (slot2 == -1) {
                continue;
            }
            if (inventory.getFirstEmptyStack() == -1) {
                continue;
            }
            if (slot2 < 9) {
                slot2 += 36;
            }
            Utils.windowClick(0, 8 - type2, 0, SChestStealer.QUICK_MOVE());
            Utils.windowClick(0, slot2, 0, SChestStealer.QUICK_MOVE());
            break;
        }
    }
    
    @Override
    public boolean onPacket(final Object packet, final Connection.Side side) {
        if (side == Connection.Side.OUT && SAutoArmor.Instanceof(packet)) {
            this.timer = this.delay.getValue().intValue();
        }
        return true;
    }
    
    int getArmorValue(final ItemArmor item, final ItemStack stack) {
        final int armorPoints = item.damageReduceAmount;
        int prtPoints = 0;
        final int armorToughness = SAutoArmor.armorToughness(item, stack);
        final int armorType = SAutoArmor.armorType2(item);
        if (this.useEnchantments.getValue()) {
            final Enchantment protection = SAutoArmor.EnchantmentsPROTECTION();
            final int prtLvl = SAutoArmor.prtLvl(protection, stack);
            final EntityPlayerSP player = Wrapper.player();
            final DamageSource dmgSource = DamageSource.causePlayerDamage(player);
            prtPoints = protection.calcModifierDamage(prtLvl, dmgSource);
        }
        return armorPoints * 5 + prtPoints * 3 + armorToughness + armorType;
    }
}