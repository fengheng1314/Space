package Space.hack.hacks.Player;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SAutoTool;
import Nirvana.utils.SUtils;
import Space.hack.HackCategory;
import Space.utils.Utils;
import Space.value.Mode;
import Space.value.ModeValue;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraftforge.event.entity.player.AttackEntityEvent;

public class AutoTool extends Hack
{
    public ModeValue priority;
    public AutoTool() {
        super("AutoTool", HackCategory.Player);
        this.priority = new ModeValue("Priority", new Mode("Weapon", false),new Mode("Tool", false),new Mode("All", true));
        this.addValue(this.priority);
    }

    @Override
    public void onLeftClickBlock(final Object event) {
        if (this.priority.getMode("Weapon").isToggled()){return;}
        Utils.nullCheck();
        this.equipBestTool(Wrapper.world().getBlockState(SUtils.EventPos(event)));
    }
    
    @Override
    public void onAttackEntity(final AttackEntityEvent event) {
        if (this.priority.getMode("Tool").isToggled()){return;}
        Utils.nullCheck();
        equipBestWeapon();
    }
    
    private void equipBestTool(final IBlockState blockState) {
        SAutoTool.equipBestTool(blockState);
    }

    public static void equipBestWeapon() {
        int bestSlot = -1;
        double maxDamage = 0.0;
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = Wrapper.player().inventory.getStackInSlot(i);
            if (stack != null && stack.getItem() instanceof ItemSword) {
                final double damage = SAutoTool.damage(stack);
                if (damage > maxDamage) {
                    maxDamage = damage;
                    bestSlot = i;
                }
            }
        }
        if (bestSlot != -1) {
            equip(bestSlot);
        }
    }

    public static void equip(final int slot) {
        Wrapper.player().inventory.currentItem = slot;
    }
}
