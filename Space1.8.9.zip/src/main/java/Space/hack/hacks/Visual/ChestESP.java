package Space.hack.hacks.Visual;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SChestESP;
import Nirvana.utils.ChatUtils;
import Space.hack.HackCategory;
import Space.utils.Utils;
import Space.utils.ui.RenderUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityMinecartChest;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraftforge.client.event.RenderWorldLastEvent;

import java.util.ArrayDeque;

public class ChestESP extends Hack
{
    private final int maxChests;
    public boolean shouldInform;
    private final ArrayDeque<TileEntityChest> emptyChests;
    private final ArrayDeque<TileEntityChest> nonEmptyChests;
    private final String[] chestClasses;
    
    public ChestESP() {
        super("ChestESP", HackCategory.Visual);
        this.maxChests = 1000;
        this.shouldInform = true;
        this.emptyChests = new ArrayDeque<>();
        this.nonEmptyChests = new ArrayDeque<>();
        this.chestClasses = new String[] { "TileEntityIronChest", "TileEntityGoldChest", "TileEntityDiamondChest", "TileEntityCopperChest", "TileEntitySilverChest", "TileEntityCrystalChest", "TileEntityObsidianChest", "TileEntityDirtChest" };
    }
    
    @Override
    public void onEnable() {
        this.shouldInform = true;
        this.emptyChests.clear();
        this.nonEmptyChests.clear();

    }

    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        int chests = 0;
        for (int i = 0; i < Wrapper.world().loadedTileEntityList.size(); ++i) {
            final TileEntity tileEntity = Wrapper.world().loadedTileEntityList.get(i);
            if (chests >= this.maxChests) {
                break;
            }
            if (tileEntity instanceof TileEntityChest) {
                ++chests;
                final TileEntityChest chest = (TileEntityChest)tileEntity;
                final boolean trapped = chest.getChestType() == SChestESP.BlockChestTypeTRAP();
                if (this.emptyChests.contains(tileEntity)) {
                    RenderUtils.drawBlockESP(chest.getPos(), 0.25f, 0.25f, 0.25f);
                }
                else if (this.nonEmptyChests.contains(tileEntity)) {
                    if (trapped) {
                        RenderUtils.drawBlockESP(chest.getPos(), 0.0f, 1.0f, 0.0f);
                    }
                    else {
                        RenderUtils.drawBlockESP(chest.getPos(), 1.0f, 0.0f, 0.0f);
                    }
                }
                else if (trapped) {
                    RenderUtils.drawBlockESP(chest.getPos(), 0.0f, 1.0f, 0.0f);
                }
                else {
                    RenderUtils.drawBlockESP(chest.getPos(), 1.0f, 0.0f, 0.0f);
                }
                if (trapped) {
                    RenderUtils.drawBlockESP(chest.getPos(), 0.0f, 1.0f, 0.0f);
                }
                else {
                    RenderUtils.drawBlockESP(chest.getPos(), 1.0f, 0.0f, 0.0f);
                }
            }
            else if (tileEntity instanceof TileEntityEnderChest) {
                ++chests;
                RenderUtils.drawBlockESP(tileEntity.getPos(), 1.0f, 0.0f, 1.0f);
            }
            else {
                try {
                    for (final String chestClass : this.chestClasses) {
                        final Class<?> clazz = Class.forName("cpw.mods.ironchest.common.tileentity.chest." + chestClass);
                        if (clazz.isInstance(tileEntity)) {
                            RenderUtils.drawBlockESP(tileEntity.getPos(), 0.7f, 0.7f, 0.7f);
                        }
                    }
                }
                catch (ClassNotFoundException ignored) {}
            }
        }
        for (int i = 0; i < Utils.getEntityList().size(); ++i) {
            final Entity entity = Utils.getEntityList().get(i);
            if (chests >= this.maxChests) {
                break;
            }
            if (entity instanceof EntityMinecartChest) {
                ++chests;
                RenderUtils.drawBlockESP(entity.getPosition(), 1.0f, 1.0f, 1.0f);
            }
        }
        if (chests >= this.maxChests && this.shouldInform) {
            ChatUtils.warning("To prevent lag, it will only show the first " + this.maxChests + " chests.");
            this.shouldInform = false;
        }
        else if (chests < this.maxChests) {
            this.shouldInform = true;
        }
    }
}
