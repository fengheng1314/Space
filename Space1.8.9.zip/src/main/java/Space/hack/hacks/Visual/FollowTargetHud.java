package Space.hack.hacks.Visual;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.utils.SUtils;
import Nirvana.utils.SValidUtils;
import Space.hack.HackCategory;
import Space.utils.Utils;
import Space.utils.ui.RenderUtils;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class FollowTargetHud extends Hack {
    EntityLivingBase target = null;

    public FollowTargetHud() {
        super("FollowTargetHud", HackCategory.Visual);
    }

    @Override
    public void onAttackEntity(final AttackEntityEvent event) {
        EntityLivingBase Target = (EntityLivingBase) SUtils.getTarget(event);
        if (Utils.IsNull(target)) {
            target = Target;
        }else if (SValidUtils.isRange(Target, target)){
            target = Target;
        }
    }

    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event){
        if (!Utils.IsNull(target)) {
            if (target.getHealth() == 0){
                target = null;
                return;
            }
            fsdf(target, target.getName(), event);
        }

    }

    public void fsdf(EntityLivingBase entity, String tag, final RenderWorldLastEvent event){
        float xChange = 0F * 20;
        GL11.glPushMatrix();
        RenderManager renderManager = Wrapper.mc().getRenderManager();
        GL11.glTranslated(
                entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * SUtils.getPartialTicks(event) - renderManager.viewerPosX,
                entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * SUtils.getPartialTicks(event) - renderManager.viewerPosY + entity.height + 0.55F,
                entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * SUtils.getPartialTicks(event) - renderManager.viewerPosZ);

        GL11.glRotatef(-renderManager.playerViewY, 0F, 1F, 0F);
        GL11.glRotatef(renderManager.playerViewX, 1F, 0F, 0F);

        double distance = Wrapper.getDistance(entity) / 4F;

        if (distance < 1F){
            distance = 1F;
        }

        RenderUtils.disableGlCap(GL11.GL_LIGHTING, GL11.GL_DEPTH_TEST);

        RenderUtils.enableGlCap(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        float scale = (float) ((distance / 150F) * 1F);

        float healthPercent = entity.getHealth() / entity.getMaxHealth();

        if (healthPercent> 1) {
            healthPercent = 1F;
        }

        GL11.glScalef(-scale * 2, -scale * 2, scale * 2);
        RenderUtils.drawRoundedCornerRect(-120f + xChange, -16f, -50f + xChange, 10f, 5f, new Color(64, 64, 64, 255).getRGB());
        RenderUtils.drawRoundedCornerRect(-110f + xChange, 0f,   -20f + xChange, 35f, 5f, new Color(96, 96, 96, 255).getRGB());

        Wrapper.fontRenderer().drawString("Attacking", (int) (-105 + xChange), -13, Color.WHITE.getRGB());
        Wrapper.fontRenderer().drawString(tag, (int) (-106 + xChange), 10, Color.WHITE.getRGB());

        String distanceString = "\u2912" + (  ( Wrapper.getDistance(entity) * 10f ) * 0.1f );
        Wrapper.fontRenderer().drawString(distanceString, (int) (-25 - Wrapper.fontRenderer().getStringWidth(distanceString) + xChange), 10, Color.WHITE.getRGB());

        RenderUtils.drawRoundedCornerRect(-104f + xChange, 22f, -50f + xChange, 30f, 1f, new Color(64, 64, 64, 255).getRGB());
        RenderUtils.drawRoundedCornerRect(-104f + xChange, 22f, -104f + (healthPercent * 54) + xChange, 30f, 1f, Color.WHITE.getRGB());

        RenderUtils.resetCaps();

        GlStateManager.resetColor();
        GL11.glColor4f(1F, 1F, 1F, 1F);

        GL11.glPopMatrix();
    }
}
