package Space.hack.hacks.Visual;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Space.hack.HackCategory;
import Space.utils.Utils;
import Space.value.Mode;
import Space.value.ModeValue;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class NightVision extends Hack
{
    public ModeValue mode;
    
    public NightVision() {
        super("NightVision", HackCategory.Visual);
        this.mode = new ModeValue("Mode", new Mode("Brightness", true), new Mode("Effect", false));
        this.addValue(this.mode);
    }

    @Override
    public void onDisable() {
        if (this.mode.getMode("Brightness").isToggled()) {
            Wrapper.mc().gameSettings.gammaSetting = 1.0f;
        }
        else {
            Utils.removeEffect(16);
        }
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (this.mode.getMode("Brightness").isToggled()) {
            Wrapper.mc().gameSettings.gammaSetting = 10.0f;
        }
        else {
            Utils.addEffect(16, 1000, 3);
        }
    }
}
