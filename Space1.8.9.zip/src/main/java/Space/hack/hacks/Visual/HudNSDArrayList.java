package Space.hack.hacks.Visual;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.managers.HackManager;
import Space.hack.HackCategory;
import Space.utils.font.FontLoaders;
import Space.value.*;

import java.awt.*;
import java.util.ArrayList;

public class HudNSDArrayList extends Hack
{
    public NumberValue TitleRed;
    public BooleanValue ListRainbow;
    public BooleanValue TitleRainbow;
    public NumberValue TagsColor;
    public NumberValue ListRed;
    public NumberValue ListGreen;
    public NumberValue ListBlue;
    public ModeValue TitleName;
    public ModeValue TagsStyle;
    public NumberValue TitleGreen;
    public NumberValue TitleBlue;
    public HudNSDArrayList() {
        super("HudNSDArrayList", HackCategory.None, true);
        this.TitleName = new ModeValue("TitleName", new Mode("Space", false), new Mode("Nirvana", true), new Mode("Zelix", false), new Mode("Leave", false), new Mode("VapeV4", false), new Mode("VapeLite", false), new Mode("LiquidBounce", false), new Mode("None", false));
        this.TagsStyle = new ModeValue("TagsStyle", new Mode("Default", true), new Mode("One", false), new Mode("Two", false), new Mode("Three", false), new Mode("Four", false), new Mode("Five", false));

        this.TitleRainbow = new BooleanValue("TitleRainbow", false);
        this.TitleRed = new NumberValue("TitleRed", 79.0,0.0,255.0);
        this.TitleGreen = new NumberValue("TitleGreen", 79.0,0.0,255.0);
        this.TitleBlue = new NumberValue("TitleBlue", 79.0,0.0,255.0);

        this.ListRainbow = new BooleanValue("ListRainbow", false);
        this.ListRed = new NumberValue("ListRed", 50.0,0.0,255.0);
        this.ListGreen = new NumberValue("ListGreen", 205.0,0.0,255.0);
        this.ListBlue = new NumberValue("ListBlue", 50.0,0.0,255.0);
        this.TagsColor = new NumberValue("TagsColor", 7.0,0.0,10.0);
        this.addValue(this.TitleName, this.TagsStyle, this.TitleRainbow, this.TitleRed, this.TitleGreen, this.TitleBlue, this.ListRainbow, this.ListRed, this.ListGreen, this.ListBlue, this.TagsColor);
    }

    public static String GetTagsStyle(String Nn1, String Nn2){
        if (HackManager.getHack("HudNSDArrayList").isNumberValue("TagsColor").intValue() == 10) {
            return GetTags(Nn1 + Nn2, "");
        } else {
            return GetTags(Nn1 + "\u00A7" + HackManager.getHack("HudNSDArrayList").isNumberValue("TagsColor").intValue(), Nn2);
        }
    }

    public static String GetTags(String front, String behind){
        String hack = HackManager.getHack("HudNSDArrayList").onToggledMode("TagsStyle");
        switch (hack) {
            case "Default":
                return front + " " + behind;
            case "One":
                return front + " - " + behind;
            case "Two":
                return front + " | " + behind;
            case "Three":
                return front + " (" + behind + ")";
            case "Four":
                return front + " [" + behind + "]";
            case "Five":
                return front + " <" + behind + ">";
        }
        return "";
    }

    public static String GetName(){
        return HackManager.getHack("HudNSDArrayList").onToggledMode("TitleName");
    }


    public static void HArrayList(double X, double Y){
        if (HackManager.getHack("HudNSDArrayList").isBooleanValue("TitleRainbow")){
            FontLoaders.default29.drawString(GetName(), X, Y, Hud.SameColor, false);
        }else {
            FontLoaders.default29.drawString(GetName(), X, Y, new Color(HackManager.getHack("HudNSDArrayList").isNumberValue("TitleRed").intValue(), HackManager.getHack("HudNSDArrayList").isNumberValue("TitleGreen").intValue(), HackManager.getHack("HudNSDArrayList").isNumberValue("TitleBlue").intValue()).getRGB(), false);
        }
        double index = Y + 16;
        int DrawColor;
        ArrayList<Hack> hacks = new ArrayList<>();
        hacks.addAll(HackManager.hacks);
        for (Hack h : HackManager.getSortedHacks()) {
            String modeName = "";
            if (!h.isToggled()) {
                continue;
            }
            for (Value value : h.getValues()) {
                if (value instanceof ModeValue) {
                    ModeValue modeValue = (ModeValue) value;
                    if (!modeValue.getModeName().equals("Mode")) {
                        continue;
                    }
                    for (Mode mode : modeValue.getModes()) {
                        if (mode.isToggled()) {
                            modeName = GetTagsStyle(modeName, mode.getName());
                        }
                    }
                }
            }

            if (HackManager.getHack("HudNSDArrayList").isBooleanValue("ListRainbow")) {
                DrawColor = Hud.SameColor;
            }else {
                DrawColor = new Color(HackManager.getHack("HudNSDArrayList").isNumberValue("ListRed").intValue(), HackManager.getHack("HudNSDArrayList").isNumberValue("ListGreen").intValue(), HackManager.getHack("HudNSDArrayList").isNumberValue("ListBlue").intValue()).getRGB();
            }
            if (!h.getRenderName().equals("Hud") && !h.getRenderName().equals("NightVision") && !h.getRenderName().equals("PacketChat") && !h.getRenderName().contains("NSD")) {
                FontLoaders.SFB17.drawString(h.getRenderName() + modeName, (float) X + 2, (int) (index + 3), DrawColor);
                index += Wrapper.fontRenderer().FONT_HEIGHT;
            }
        }
    }
}