package Space.hack.hacks.Visual.UI.keystrokesmod;

import Nirvana.Wrapper;
import Nirvana.managers.HackManager;
import Space.hack.hacks.Visual.Hud;
import Space.managers.FileManager;
import net.minecraft.client.gui.ScaledResolution;

import java.awt.*;

public class KeystrokesRenderer
{
    private final Key[] movementKeys;
    private final MouseButton[] mouseButtons;

    public KeystrokesRenderer() {
        this.movementKeys = new Key[4];
        this.mouseButtons = new MouseButton[2];
        this.movementKeys[0] = new Key(Wrapper.mc().gameSettings.keyBindForward, 26, 2);
        this.movementKeys[1] = new Key(Wrapper.mc().gameSettings.keyBindBack, 26, 26);
        this.movementKeys[2] = new Key(Wrapper.mc().gameSettings.keyBindLeft, 2, 26);
        this.movementKeys[3] = new Key(Wrapper.mc().gameSettings.keyBindRight, 50, 26);
        this.mouseButtons[0] = new MouseButton(0, 2, 50);
        this.mouseButtons[1] = new MouseButton(1, 38, 50);
    }
    
    public void renderKeystrokes(int x, int y) {
        int textColor;
        if (HackManager.getHack("HudNSDKeystrokes").isBooleanValue("TitleRainbow")){
            textColor = Hud.SameColor;
        }else {
            textColor = new Color(HackManager.getHack("HudNSDKeystrokes").isNumberValue("TitleRed").intValue(), HackManager.getHack("HudNSDKeystrokes").isNumberValue("TitleGreen").intValue(), HackManager.getHack("HudNSDKeystrokes").isNumberValue("TitleBlue").intValue()).getRGB();
        }

        final boolean showingMouseButtons = HackManager.getHack("HudNSDKeystrokes").isBooleanValue("Mouse");
        final ScaledResolution res = new ScaledResolution(Wrapper.mc());
        final int height = showingMouseButtons ? 74 : 50;
        if (x < 0) {
            FileManager.SetHud("Keystrokes" , String.valueOf(0), String.valueOf(y));
        }
        else if (x > res.getScaledWidth() - 74) {
            FileManager.SetHud("Keystrokes" , String.valueOf(res.getScaledWidth() - 74), String.valueOf(y));
        }
        if (y < 0) {
            FileManager.SetHud("Keystrokes" , String.valueOf(x), String.valueOf(0));
        }
        else if (y > res.getScaledHeight() - height) {
            FileManager.SetHud("Keystrokes" , String.valueOf(x), String.valueOf(res.getScaledHeight() - height));
        }
        this.drawMovementKeys(x, y, textColor);
        if (showingMouseButtons) {
            this.drawMouseButtons(x, y, textColor);
        }
    }

    private void drawMovementKeys(final int x, final int y, final int textColor) {
        for (final Key key : this.movementKeys) {
            key.renderKey(x, y, textColor);
        }
    }
    
    private void drawMouseButtons(final int x, final int y, final int textColor) {
        for (final MouseButton button : this.mouseButtons) {
            button.renderMouseButton(x, y, textColor);
        }
    }

}
