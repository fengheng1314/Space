package Space.hack.hacks.Visual;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Space.hack.HackCategory;

public class NoBob extends Hack
{
    public NoBob() {
        super("NoBob", HackCategory.Visual);
    }

    @Override
    public void onInputUpdate(final Object event) {
        Wrapper.player().distanceWalkedModified = 0;
    }
}