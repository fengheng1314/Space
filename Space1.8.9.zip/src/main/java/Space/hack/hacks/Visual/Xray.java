package Space.hack.hacks.Visual;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SXray;
import Space.hack.HackCategory;
import Space.utils.Utils;
import Space.value.BooleanValue;
import Space.value.NumberValue;
import net.minecraft.block.Block;
import net.minecraftforge.client.event.RenderWorldLastEvent;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class Xray extends Hack {
   private Timer t;
   public NumberValue Range;
   public BooleanValue Iron;
   public BooleanValue Gold;
   public BooleanValue Diamond;
   public BooleanValue Emerald;
   public BooleanValue Lapis;
   public BooleanValue Redstone;
   public BooleanValue Coal;
   public BooleanValue Spawner;
   public Xray() {
      super("Xray", HackCategory.Visual, false);
      this.Range = new NumberValue("Range",20.0, 5.0, 50.0);
      this.Iron = new BooleanValue("Iron", true);
      this.Gold = new BooleanValue("Gold", true);
      this.Diamond = new BooleanValue("Diamond", true);
      this.Emerald = new BooleanValue("Emerald", true);
      this.Lapis = new BooleanValue("Lapis", true);
      this.Redstone = new BooleanValue("Redstone", true);
      this.Coal = new BooleanValue("Coal", true);
      this.Spawner = new BooleanValue("Spawner", true);
      this.addValue(this.Range, this.Iron, this.Gold, this.Diamond, this.Emerald, this.Lapis, this.Redstone, this.Coal,this.Spawner);

   }

   @Override
   public void onEnable() {
      SXray.ren = new ArrayList<>();
      (this.t = new Timer()).scheduleAtFixedRate(this.t(), 0L, 200L);
   }

   @Override
   public void onDisable() {
      if (this.t != null) {
         this.t.cancel();
         this.t.purge();
         this.t = null;
      }
   }

   private TimerTask t() {
      return new TimerTask() {
         public void run() {
            SXray.ren.clear();
            int ra = Range.getValue().intValue();

            for(int y = ra; y >= -ra; --y) {
               for(int x = -ra; x <= ra; ++x) {
                  for(int z = -ra; z <= ra; ++z) {
                     if (Utils.isPlayerInGame()) {
                        SXray.NBlockPos(x, y, z);
                        Block bl = Wrapper.world().getBlockState(SXray.p).getBlock();
                        if ((Iron.getValue() && bl.equals(SXray.IRON_ORE)) || 
                                (Gold.getValue() && bl.equals(SXray.GOLD_ORE)) ||
                                (Diamond.getValue() && bl.equals(SXray.DIAMOND_ORE)) ||
                                (Emerald.getValue() && bl.equals(SXray.EMERALD_ORE)) ||
                                (Lapis.getValue() && bl.equals(SXray.LAPIS_ORE)) ||
                                (Redstone.getValue() && bl.equals(SXray.REDSTONE_ORE)) ||
                                (Coal.getValue() && bl.equals(SXray.COAL_ORE)) ||
                                (Spawner.getValue() && bl.equals(SXray.MOB_SPAWNER))) {
                           SXray.ren.add(SXray.p);
                        }
                     }
                  }
               }
            }

         }
      };
   }

   @Override
   public void onRenderWorldLast(final RenderWorldLastEvent event) {
      SXray.onRenderWorldLast(event);
   }

   public static int[] c(Block b) {
      int red = 0;
      int green = 0;
      int blue = 0;
      if (b.equals(SXray.IRON_ORE)) {
         red = 255;
         green = 255;
         blue = 255;
      } else if (b.equals(SXray.GOLD_ORE)) {
         red = 255;
         green = 255;
      } else if (b.equals(SXray.DIAMOND_ORE)) {
         green = 220;
         blue = 255;
      } else if (b.equals(SXray.EMERALD_ORE)) {
         red = 35;
         green = 255;
      } else if (b.equals(SXray.LAPIS_ORE)) {
         green = 50;
         blue = 255;
      } else if (b.equals(SXray.REDSTONE_ORE)) {
         red = 255;
      } else if (b.equals(SXray.MOB_SPAWNER)) {
         red = 30;
         blue = 135;
      }

      return new int[]{red, green, blue};
   }
}
