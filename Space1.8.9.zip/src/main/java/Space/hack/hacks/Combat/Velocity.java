package Space.hack.hacks.Combat;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SVelocity;
import Nirvana.utils.Connection;
import Nirvana.utils.MathUtils;
import Space.hack.HackCategory;
import Space.value.BooleanValue;
import Space.value.Mode;
import Space.value.ModeValue;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Velocity extends Hack
{
    public ModeValue mode;
    public BooleanValue OnlyGround;

    public Velocity() {
        super("Velocity", HackCategory.Combat);
        this.mode = new ModeValue("Mode", new Mode("Simple", true), new Mode("Jump", false), new Mode("Hypixel", false));
        this.OnlyGround = new BooleanValue("OnlyGround", false);
        this.addValue(this.mode,this.OnlyGround);
    }

    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if(inStrafe()){
            return;
        }

        if (this.mode.getMode("Jump").isToggled()) {
            if (Wrapper.player().hurtTime > 0 && Wrapper.player().onGround) {
                Wrapper.player().motionY = 0.42;
                float yaw = Wrapper.player().rotationYaw * 0.017453292F;
                Wrapper.player().motionX -= MathUtils.sin(yaw) * 0.2;
                Wrapper.player().motionZ += MathUtils.cos(yaw) * 0.2;
            }
        }

    }
    
    @Override
    public boolean onPacket(final Object packet, final Connection.Side side) {
        if(!this.mode.getMode("Simple").isToggled() && !this.mode.getMode("Hypixel").isToggled()){
            return true;
        }
        if(inStrafe()){
            return true;
        }

        if (SVelocity.Instanceof(packet) && this.mode.getMode("Simple").isToggled() && Wrapper.player().hurtTime >= 0) {
            return SVelocity.getSP().getEntityID() != Wrapper.player().getEntityId();
        } else if (SVelocity.Instanceof(packet) && this.mode.getMode("Hypixel").isToggled() && Wrapper.player().hurtTime >= 0) {
            if (SVelocity.getSP().getEntityID() == Wrapper.player().getEntityId()) {
                Wrapper.player().motionY = SVelocity.getSP().getMotionY() / 8000.0;
            }
        }

        return true;
    }

    public boolean inStrafe() {
        return OnlyGround.getValue() && !Wrapper.player().onGround;
    }

}

