package Space.hack.hacks.Combat;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.utils.SPacket;
import Nirvana.utils.SUtils;
import Space.hack.HackCategory;
import Space.utils.TimerUtils;
import Space.utils.Utils;
import Space.utils.ValidUtils;
import Space.value.BooleanValue;
import Space.value.Mode;
import Space.value.ModeValue;
import Space.value.NumberValue;
import net.minecraft.entity.EntityLivingBase;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class InfiniteAura extends Hack
{
    public ModeValue mode;
    public EntityLivingBase target;
    public ModeValue priority;
    public NumberValue MaxCPS;
    public NumberValue MinCPS;
    public NumberValue FOV;
    public NumberValue range;
    public TimerUtils timer;
    public BooleanValue AutoAim;
    public BooleanValue walls;
    public BooleanValue Situ;
    public InfiniteAura() {
        super("InfiniteAura", HackCategory.Combat, false);
        this.priority = ValidUtils.isPriority("Priority");
        this.mode = new ModeValue("Mode", new Mode("Packet", true), new Mode("Simple", false), new Mode("Off", false));
        this.MaxCPS = new NumberValue("MaxCPS", 8D, 1.0D, 22D);
        this.MinCPS = new NumberValue("MinCPS", 7D, 1.0D, 21D);
        this.FOV = new NumberValue("FOV", 360D, 1.0D, 360D);
        this.range = new NumberValue("Range", 100.0D, 1.0D, 100.0D);
        this.Situ = new BooleanValue("Situ", true);
        this.AutoAim = new BooleanValue("AutoAim", true);
        this.walls = new BooleanValue("ThroughWalls", false);
        this.addValue(this.mode, this.priority, this.MaxCPS, this.MinCPS, this.FOV, this.range, this.Situ, this.AutoAim, this.walls);
        this.timer = new TimerUtils();
    }

    @Override
    public void onEnable() {
        target = null;
        this.timer = new TimerUtils();
    }

    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        target = ValidUtils.killAuraUpdate(this.priority.getModeToggled(), this.FOV.getValue(), this.range.getValue(), target, "All");

        if (Utils.IsNull(target)){return;}
        
            if(AutoAim.getValue()) {
                Wrapper.player().rotationYaw = Utils.getYaw(this.target);
            }
            int i = Utils.random(this.MinCPS.getValue().intValue() ,this.MaxCPS.getValue().intValue());
            int j = Utils.random(1, 50);
            int k = Utils.random(1, 60);
            int l = Utils.random(1, 70);

            if (this.timer.isDelay(((1000 + j - k + l) / i))) {
                double d0 = target.posX + 1  - 3.5D * Math.cos(Math.toRadians((Utils.getYaw(target) + 90.0F)));
                double d1 = target.posZ + 1  - 3.5D * Math.sin(Math.toRadians((Utils.getYaw(target) + 90.0F)));
                if (!this.Situ.getValue()){
                    Wrapper.sendPacket(SPacket.CPacketPlayerPositionRotation(d0, target.posY + 1 , d1, Utils.getYaw(target), Utils.getPitch(target), target.onGround));
                }
                SUtils.swingMainHand();
                if (mode.getMode("Simple").isToggled()){
                    Wrapper.mc().playerController.attackEntity(Wrapper.player(), target);
                }else if (mode.getMode("Packet").isToggled()){
                    Wrapper.sendPacket(SPacket.CPacketUseEntity(target));
                }
                if (!this.Situ.getValue()){
                    Wrapper.sendPacket(SPacket.CPacketPlayerPosition(target.posX + 1 , target.posY, target.posZ + 1 , target.onGround));
                }
                this.timer.setLastMS();
            }

    }
}
