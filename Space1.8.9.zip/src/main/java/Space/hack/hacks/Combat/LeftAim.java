package Space.hack.hacks.Combat;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.utils.SValidUtils;
import Space.hack.HackCategory;
import Space.utils.TimerUtils;
import Space.utils.Utils;
import Space.utils.ValidUtils;
import Space.utils.ui.RenderUtils;
import Space.value.BooleanValue;
import Space.value.Mode;
import Space.value.ModeValue;
import Space.value.NumberValue;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.EntityLivingBase;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class LeftAim extends Hack {
    public static EntityLivingBase target = null;
    public ModeValue mode;
    public ModeValue priority;
    public NumberValue MaxCPS;
    public NumberValue MinCPS;
    public NumberValue FOV;
    public NumberValue range;
    public NumberValue CpsCappedRange;
    public TimerUtils timer;
    public BooleanValue CpsCapped;
    public BooleanValue NoAttack;
    public ModeValue Circle;
    public ModeValue Mark;
    public LeftAim() {
        super("LeftAim", HackCategory.Combat, false);
        this.Mark = ValidUtils.isMark();
        this.Circle = ValidUtils.isCircle();
        this.priority = ValidUtils.isPriority("Priority");
        this.mode = new ModeValue("Mode", new Mode("Simple", true),new Mode("Yaw", false),new Mode("Pitch", false),new Mode("Off", false));
        this.MaxCPS = new NumberValue("MaxCPS", 30.0, 1.0, 90.0);
        this.MinCPS = new NumberValue("MinCPS", 29.0, 1.0, 89.0);
        this.FOV = new NumberValue("FOV", 360.0, 1.0, 360.0);
        this.range = new NumberValue("Range", 4.4, 1.0, 10.0);
        this.NoAttack = new BooleanValue("NoAttack", false);
        this.CpsCapped = new BooleanValue("CpsCapped", false);
        this.CpsCappedRange = new NumberValue("CpsRange", 4.4, 1.0, 10.0);
        this.addValue(this.mode, this.priority, this.MaxCPS, this.MinCPS, this.FOV, this.range, this.Mark, this.Circle, this.NoAttack, this.CpsCapped, this.CpsCappedRange);
        this.timer = new TimerUtils();
    }

    @Override
    public void onEnable() {
        target = null;
    }

    @Override
    public void onRenderGameOverlay(final RenderGameOverlayEvent.Text event) {
        target = ValidUtils.killAuraUpdate(this.priority.getModeToggled(), this.FOV.getValue(), this.range.getValue(), target, "All");

        if (Utils.IsNull(target)){return;}

        if (!mode.getMode("Off").isToggled()) {
            if (mode.getMode("Simple").isToggled()) {
                Wrapper.player().rotationYaw = Utils.getYaw(target);
                Wrapper.player().rotationPitch = Utils.getPitch(target);
            } else if (mode.getMode("Yaw").isToggled()) {
                Wrapper.player().rotationYaw = Utils.getYaw(target);
            } else if (mode.getMode("Pitch").isToggled()) {
                Wrapper.player().rotationPitch = Utils.getPitch(target);
            }
        }
        if(NoAttack.getValue()){return;}
        if (!CpsCapped.getValue()){
            attack();
        }else {
            if (SValidUtils.isInAttackRange(target, this.CpsCappedRange.getValue())) {KeyBinding.onTick(Wrapper.mc().gameSettings.keyBindUseItem.getKeyCode());}else {attack();}}

    }

    @Override
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        RenderUtils.SCircle(this.onToggledMode("Circle"), target, event);
        RenderUtils.SMark(this.onToggledMode("Mark"), target, event);
    }

    public void attack() {
        int i = Utils.random(this.MinCPS.getValue().intValue() ,this.MaxCPS.getValue().intValue());
        int j = Utils.random(1, 50);
        int k = Utils.random(1, 60);
        int l = Utils.random(1, 70);

        if (this.timer.isDelay(((1000 + j - k + l) / i))) {
            KeyBinding.onTick(Wrapper.mc().gameSettings.keyBindUseItem.getKeyCode());
            this.timer.setLastMS();
        }
    }

}
