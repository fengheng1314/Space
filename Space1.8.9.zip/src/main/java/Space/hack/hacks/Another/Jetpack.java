package Space.hack.hacks.Another;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Space.hack.HackCategory;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Jetpack extends Hack {
    public Jetpack() {
        super("Jetpack", HackCategory.Another, false);
    }

    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (Wrapper.mc().gameSettings.keyBindJump.isKeyDown()) {
            Wrapper.player().jump();
        }
    }
}
