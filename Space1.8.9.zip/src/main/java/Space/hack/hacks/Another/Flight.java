package Space.hack.hacks.Another;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SFlight;
import Space.hack.HackCategory;
import Space.value.BooleanValue;
import Space.value.Mode;
import Space.value.ModeValue;
import Space.value.NumberValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.LinkedList;

public class Flight extends Hack
{
    public NumberValue flytimer;
    public BooleanValue XYZ;
    boolean send;
    public ModeValue mode;
    int ticks;
    
    public Flight() {
        super("Flight", HackCategory.Another, false);
        SFlight.packets = new LinkedList<>();
        SFlight.p = new ArrayList<>();
        this.send = false;
        this.ticks = 0;
        this.mode = new ModeValue("Mode", new Mode("Simple", true), new Mode("Dynamic", false), new Mode("Hypixel", false));
        this.flytimer = new NumberValue("Timer", 1.0, 0.1, 1.2);
        this.XYZ = new BooleanValue("AntiKick", true);
        this.addValue(this.mode,this.flytimer, this.XYZ);
    }
    
    @Override
    public void onEnable() {
        this.ticks = 0;
    }

    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        final EntityPlayerSP player = Wrapper.player();
        if (this.mode.getMode("Hypixel").isToggled()) {
            player.motionY = 0.0;
            player.setSprinting(true);
            player.onGround = true;
            ++this.ticks;
            if (this.ticks == 2 || this.ticks == 4 || this.ticks == 6 || this.ticks == 8 || this.ticks == 10 || this.ticks == 12 || this.ticks == 14 || this.ticks == 16 || this.ticks == 18 || this.ticks == 20) {
                player.setPosition(player.posX + flytimer.getValue(), player.posY + 1.28E-9, player.posZ + flytimer.getValue());
            }
            if (this.ticks == 20) {
                this.ticks = 0;
            }
        }
        else if (this.mode.getMode("Simple").isToggled()) {
            player.capabilities.isFlying = true;
           if(Wrapper.mc().gameSettings.keyBindForward.isKeyDown()) {
               player.motionX = player.motionX * this.flytimer.getValue();
               player.motionZ = player.motionZ * this.flytimer.getValue();
            }
        }
        else if (this.mode.getMode("Dynamic").isToggled()) {
            if (this.XYZ.getValue() && Wrapper.player().ticksExisted % 4 == 0) {
                Wrapper.player().motionY = -0.03999999910593033;
            }
            final Double flyspeed = this.flytimer.getValue();
            player.jumpMovementFactor = 0.4f;
            player.motionX = 0.0;
            player.motionY = 0.0;
            player.motionZ = 0.0;
            player.jumpMovementFactor *= flyspeed * 3.0f;
            if (Wrapper.mc().gameSettings.keyBindJump.isKeyDown()) {
                if (this.XYZ.getValue()) {
                    Wrapper.player().motionY = ((Wrapper.player().ticksExisted % 20 == 0) ? -0.03999999910593033 : flyspeed);
                }
                else {
                    player.motionY += flyspeed;
                }
            }
        }
    }
    
    @Override
    public void onDisable() {
        if (this.mode.getMode("Simple").isToggled()) {
            Wrapper.player().capabilities.isFlying = false;
        }
        SFlight.packets.clear();
    }
}
