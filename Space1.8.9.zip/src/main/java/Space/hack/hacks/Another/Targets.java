package Space.hack.hacks.Another;

import Nirvana.hack.Hack;
import Space.hack.HackCategory;
import Space.value.BooleanValue;

public class Targets extends Hack
{
    public BooleanValue players;
    public BooleanValue mobs;
    public BooleanValue invisibles;
    public BooleanValue sleeping;

    public Targets() {
        super("Targets", HackCategory.Another);
        this.players = new BooleanValue("Players",true);
        this.mobs = new BooleanValue("Mobs", true);
        this.invisibles = new BooleanValue("Invisibles", false);
        this.sleeping = new BooleanValue("Sleeping", false);
        this.addValue(this.players, this.mobs, this.invisibles, this.sleeping);
    }

}
