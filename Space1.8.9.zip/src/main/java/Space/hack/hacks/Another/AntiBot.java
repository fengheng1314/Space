package Space.hack.hacks.Another;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.SAntiBot;
import Space.hack.HackCategory;
import Space.value.BooleanValue;
import Space.value.NumberValue;
import net.minecraft.entity.player.EntityPlayer;

public class AntiBot extends Hack
{
    public AntiBot() {
        super("AntiBot", HackCategory.Another);
        BooleanValue LivingTime = new BooleanValue("LivingTime", false);
        NumberValue tick = new NumberValue("LivingTicks", 18.0, 0.1, 30.0);
        BooleanValue ifInvisible = new BooleanValue("Invisible", false);
        BooleanValue ifArmor = new BooleanValue("Armor", false);
        BooleanValue ifInAir = new BooleanValue("InAir", false);
        BooleanValue ifHealth = new BooleanValue("Health", false);
        BooleanValue ifGround = new BooleanValue("OnGround", false);
        BooleanValue ifEntityId = new BooleanValue("EntityId", false);
        BooleanValue NameNPC = new BooleanValue("NameNPC", false);
        addValue(LivingTime, tick, ifInvisible, ifArmor, ifInAir, ifHealth, ifGround, ifEntityId, NameNPC);
    }

    public static boolean isBot(final EntityPlayer bot, Hack hack) {
        if (hack.isBooleanValue("LivingTime")) {
            double ticks = hack.isNumberValue("LivingTicks");
            if (ticks > 0.0 && bot.ticksExisted < ticks) {
                return true;
            }
        }
        if (hack.isBooleanValue("InAir") && bot.isInvisible() && bot.motionY == 0.0 && bot.posY > Wrapper.player().posY + 1.0 && SAntiBot.InAir(bot)) {
            return true;
        }
        if (hack.isBooleanValue("OnGround") && bot.motionY == 0.0 && SAntiBot.collidedVertically(bot) && bot.onGround && bot.posY % 1.0 != 0.0 && bot.posY % 0.5 != 0.0) {
            return true;
        }
        if (hack.isBooleanValue("Health") && (bot.getHealth() <= 0.0f || bot.getHealth() > 20F)) {
            return true;
        }
        if (hack.isBooleanValue("Invisible") && bot.isInvisible()) {
            return true;
        }
        if (hack.isBooleanValue("EntityId") && bot.getEntityId() >= 1000000000) {
            return true;
        }
        if (hack.isBooleanValue("NameNPC")) {
            if (bot.getName().contains("[") && bot.getName().contains("N") && bot.getName().contains("P") && bot.getName().contains("C") && bot.getName().contains("]")){
                return true;
            }

        }
        if (hack.isBooleanValue("Armor")) {
            if (SAntiBot.Armor(bot)) {
                return true;
            }
        }

        return false;
    }
}