package Space.hack.hacks.Another;

import Nirvana.hack.Hack;
import Space.hack.HackCategory;
import Space.value.Mode;
import Space.value.ModeValue;

public class Teams extends Hack
{
    public ModeValue mode;

    public Teams() {
        super("Teams", HackCategory.Another);
        this.mode = new ModeValue("Mode", new Mode("Base", false), new Mode("Armor", true));
        this.addValue(this.mode);
    }

}
