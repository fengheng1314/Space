/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * h ttps://github.com/fengheng1314/Space
 */
package Space;

import Nirvana.EventsHandler;
import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.hack.hacks.GuiCustomScreen;
import Nirvana.managers.HackManager;
import Nirvana.utils.ChatUtils;
import Space.managers.FileManager;
import Space.utils.Nan0EventRegister;
import Space.value.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.FMLCommonHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.management.ManagementFactory;

public class Disposal {
    private static OutputStream outputStream;
    public static String message;
    private static String SendX_ = "";
    public static void Tabled(OutputStream a,String v){
        outputStream=a;message=v;
          if(v.equals("initialize")){
              String processName = ManagementFactory.getRuntimeMXBean().getName();
              long pid = Long.parseLong(processName.split("@")[0]);
              Send50("[----------" + "Pid[" + pid + "]" + "@@" + "[GetC-" + "C:\\Space\\Config\\" + Wrapper.version2 + ".Space"+ "]@@----------]");
          }else if(v.equals("Next")) {
              initialize();
          }else if(v.contains("Toggle ")) {
              v = v.replace("Toggle ", "");
              HackManager.getHack(v).toggle();
          }else if(v.contains("Ui ")) {
              v = v.replace("Ui ", "");
              StringBuilder Temp = new StringBuilder("[----------");
              for (final Hack h : HackManager.getHacks()) {
                  if (h.getName().equals(v)){
                      for (final Value x : h.getValues()) {
                          if (x instanceof BooleanValue) {
                              Temp.append("BooleanValue").append(x.getName()).append(":").append(x.getValue()).append("@@");
                          }
                          if (x instanceof NumberValue) {
                              Temp.append("NumberValue").append(x.getName()).append(":").append(x.getValue()).append("[").append("\"").append(((NumberValue) x).getMin()).append("\"").append("-").append("\"").append(((NumberValue) x).getMax()).append("\"").append("]").append("@@");
                          }
                          if (x instanceof ModeValue) {
                              final ModeValue modeValue = (ModeValue) x;
                              for (final Mode modeS : modeValue.getModes()) {
                                  Temp.append("ModeValue").append(x.getName()).append(":").append(modeS.getName()).append("-").append(modeS.isToggled()).append("@@");
                              }
                          }
                      }
                  }
              }

              Send100(Temp + "[Key-" + HackManager.getHack(v).getKey() + "]" + "@@" + "UIALLInfo@@----------]");

          }else if(v.contains("#")) {
              String[] parts = v.split("\\s+");
              String Name = parts[0].substring(1);
              String Mode = parts[1];
              String value = parts[2];

              HackManager.getHack(Name).setModes(Mode, value);
          }else if(v.contains("!KEY ")){
              String[] parts = v.split("\\s+");
              String Name = parts[1];
              String Key = parts[2];
              for (final Hack h : HackManager.getHacks()) {
                  if (h.getName().equals(Name)) {
                      h.setKey(Integer.parseInt(Key));
                  }
              }
              Send50("[Key-" + Key + "]");
          }else if(v.contains("!KEY2 ")){
              String[] parts = v.split("\\s+");
              String Name = parts[1];
              String Key = parts[2];
              for (final Hack h : HackManager.getHacks()) {
                  if (h.getName().equals(Name)) {
                      h.setKey(BenCore.getKeyIndex(Key));
                  }
              }
              Send50("[Key-" + BenCore.getKeyIndex(Key) + "]");
          }else if(v.equals("Reload")){
              FileManager.loadHacks(true);
          }else if(v.equals("&Hud.Settings")){
              if(Wrapper.world() == null){return;}
              Wrapper.mc().displayGuiScreen(new GuiCustomScreen());
          }
    }
    private static void initialize(){
        if(Wrapper.world() != null){
            ChatUtils.message("Synchronizing!");
        }
        new HackManager();
        new FileManager();
        EventsHandler eventsHandler = new EventsHandler();
        Nan0EventRegister.register(MinecraftForge.EVENT_BUS, eventsHandler);
        Nan0EventRegister.register(FMLCommonHandler.instance().bus(), eventsHandler);
    }

    public static void Send50(String v){
        try {
            Thread.sleep(50);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            outputStream.write(v.getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void Send100(String v){
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            outputStream.write(v.getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void Send120(String v){
        try {
            Thread.sleep(120);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            outputStream.write(v.getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void Send0(String v){
        try {
            outputStream.write(v.getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void SendX(String v){
        if (SendX_.equals(v)){return;}
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        try {
            SendX_ = v;
            String text = "@X[" + v +"]" ;
            outputStream.write(text.getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
