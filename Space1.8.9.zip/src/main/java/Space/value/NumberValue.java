/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https ://github.com/fengheng1314/Space
 */
package Space.value;

public class NumberValue extends Value<Double>
{
    protected Double min;
    protected Double max;

    public NumberValue(final String name, final Double defaultValue, final Double min, final Double max) {
        super(name, defaultValue);
        this.min = min;
        this.max = max;
    }

    @Override
    public Double getValue() {
        return super.getValue();
    }

    public Double getMin() {
        return this.min;
    }

    public Double getMax() {
        return this.max;
    }
}
