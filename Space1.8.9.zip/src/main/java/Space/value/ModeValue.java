/*
 * Space2 And Nirvana By FengHeng, fengheng@tom.com/3547694806@qq.com
 * This project is open source.
 * https: //github.com/fengheng1314/Space
 */
package Space.value;

public class ModeValue extends Value<Mode>
{
    private Mode[] modes;
    private String modeName;
    
    public Mode[] getModes() {
        return this.modes;
    }
    
    public ModeValue(final String modeName, final Mode... modes) {
        super(modeName, Modedefault(modes));
        this.modeName = modeName;
        this.modes = modes;
    }

    private static Mode Modedefault(final Mode... modes) {
        for (int i = 0; i < modes.length; ++i) {
            if (modes[i].isToggled()){
                return modes[i];
            }
        }

        return null;
    }
    
    public ModeValue(final String modeName, final String[] modes) {
        super(modeName, null);
        this.modeName = modeName;
        for (int i = 0; i < modes.length; ++i) {
            if (i == 0) {
                this.modes[i] = new Mode(modes[i], true);
            }
            else {
                this.modes[i] = new Mode(modes[i], false);
            }
        }
    }
    
    public Mode getMode(final String name) {
        Mode m = null;
        for (final Mode mode : this.modes) {
            if (mode.getName().equals(name)) {
                m = mode;
            }
        }
        return m;
    }

    public String getModeName() {
        return this.modeName;
    }

    public boolean Isempty(){
        for (final Mode mode : modes) {
            if (mode.isToggled()){
                return false;
            }
        }
        return true;
    }

    public boolean IsLegit(String name){
        for (final Mode mode : modes) {
            if (mode.getName().contains(name)){
                return true;
            }
        }
        return false;
    }

    public String getModeToggled() {
        for (final Mode mode : this.modes) {
            if (mode.isToggled()) {
                return mode.getName();
            }
        }
        return "";
    }
}
