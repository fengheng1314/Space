package Nirvana.managers;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Space.hack.hacks.Another.*;
import Space.hack.hacks.Combat.*;
import Space.hack.hacks.Player.*;
import Space.hack.hacks.Visual.*;
import Space.value.Mode;
import Space.value.ModeValue;
import Space.value.Value;
import net.minecraftforge.client.event.*;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.List;

public class HackManager
{
    public static ArrayList<Hack> hacks = new ArrayList<>();

    public HackManager() {
        this.addHacks();
    }

    public void addHacks() {
        //Another
        addHack(new AntiBot());
        addHack(new Targets());
        addHack(new Teams());

        //Combat
        addHack(new SuperKnockback());
        addHack(new AutoClicker());
        addHack(new InfiniteAura());
        addHack(new AuraAim());
        addHack(new LeftAim());
        addHack(new KillAura());
        addHack(new Criticals());
        addHack(new Velocity());

        //Player
        addHack(new ChatTranslator());
        addHack(new ChestStealer());
        addHack(new AutoArmor());
        addHack(new AutoTool());
        addHack(new Scaffold());
        addHack(new FastPlace());
        addHack(new Eagle());
        addHack(new Reach());
        addHack(new NoFall());

        //Movement
        addHack(new LongJump());
        addHack(new AutoWalk());
        addHack(new Jetpack());
        addHack(new Speed());
        addHack(new Sprint());
        addHack(new Flight());

        //Visual
        addHack(new FollowTargetHud());
        addHack(new Trajectories());
        addHack(new ChestESP());
        addHack(new Hud());
        addHack(new HudNSDArrayList());
        addHack(new HudNSDKeystrokes());
        addHack(new HudNSDArmorHUD());
        addHack(new HudNSDEnemyInfo());
        addHack(new Xray());
        addHack(new Fov());
        addHack(new NightVision());
        addHack(new Profiler());
        addHack(new Tracers());
        addHack(new NoBob());
    }

    public static ArrayList<Hack> getHacks() {
        return HackManager.hacks;
    }


    public static void addHack(final Hack hack) {
        HackManager.hacks.add(hack);
    }

    public static Hack getHack(final String name) {
        Hack hack = null;
        for (final Hack h : getHacks()) {
            if (h.getName().equals(name)) {
                hack = h;
            }
        }
        return hack;
    }

    public static void onClientTick(final TickEvent.ClientTickEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onClientTick(event);
            }
        }
    }

    public static void onAttackEntity(final AttackEntityEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onAttackEntity(event);
            }
        }
    }

    public static void onLivingUpdate(final LivingEvent.LivingUpdateEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onLivingUpdate(event);
            }
        }
    }

    public static void onPlayerMove(final PlayerEvent.LivingUpdateEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onPlayerMove(event);
            }
        }
    }

    public static void onLeftClickBlock(final PlayerInteractEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onLeftClickBlock(event);
            }
        }
    }

    public static void onCameraSetup(final EntityViewRenderEvent.CameraSetup event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onCameraSetup(event);
            }
        }
    }

    public static void onRightClickItem(final PlayerInteractEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onRightClickItem(event);
            }
        }
    }

    public static void onRenderGameOverlay(final RenderGameOverlayEvent.Text event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onRenderGameOverlay(event);
            }
        }
    }

    public static void onMouse(final MouseEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onMouse(event);
            }
        }
    }

    public static void onInputUpdate(final TickEvent.PlayerTickEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onInputUpdate(event);
            }
        }
    }

    public static void onRenderWorldLast(final RenderWorldLastEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onRenderWorldLast(event);
            }
        }
    }

    public static void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onPlayerTick(event);
            }
        }
    }

    public static void onRender3D(final RenderBlockOverlayEvent event) {
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                hack.onRender3D(event);
            }
        }
    }

    public static List<Hack> getSortedHacks() {
        final List<Hack> list = new ArrayList<>();
        for (final Hack hack : getHacks()) {
            if (hack.isToggled()) {
                if (!hack.isShow()) {
                    continue;
                }
                list.add(hack);
            }
        }
        list.sort((h1, h2) -> {
            StringBuilder s1 = new StringBuilder(h1.getRenderName());
            StringBuilder s2 = new StringBuilder(h2.getRenderName());
            for (final Value value : h1.getValues()) {
                if (value instanceof ModeValue) {
                    final ModeValue modeValue = (ModeValue)value;
                    if (!modeValue.getName().equals("Mode")) {
                        continue;
                    }
                    for (final Mode mode : modeValue.getModes()) {
                        if (mode.isToggled()) {
                            s1.append(" ").append(mode.getName());
                        }
                    }
                }
            }
            for (final Value value : h2.getValues()) {
                if (value instanceof ModeValue) {
                    final ModeValue modeValue = (ModeValue)value;
                    if (!modeValue.getName().equals("Mode")) {
                        continue;
                    }
                    for (final Mode mode : modeValue.getModes()) {
                        if (mode.isToggled()) {
                            s2.append(" ").append(mode.getName());
                        }
                    }
                }
            }
            final int cmp = Wrapper.fontRenderer().getStringWidth(s2.toString()) - Wrapper.fontRenderer().getStringWidth(s1.toString());
            return (cmp != 0) ? cmp : s2.toString().compareTo(s1.toString());
        });
        return list;
    }

}
