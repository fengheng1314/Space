package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import Space.hack.hacks.Player.AutoTool;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

public class SAutoTool {
    public static void equipBestTool(final IBlockState blockState){
        int bestSlot = -1;
        double max = 0.0;
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = Wrapper.player().inventory.getStackInSlot(i);
            if (!(stack == null)) {

                float speed = stack.getItem().getDigSpeed(stack, blockState);
                if (speed > 1.0f) {

                    float eff = EnchantmentHelper.getEnchantmentLevel(Enchantment.efficiency.effectId, stack);
                    if (eff > 0) {
                        speed += (float)(Math.pow(eff, 2.0) + 1.0);
                    } else {
                        speed += 0.0;
                    }

                    if (speed > max) {
                        max = speed;
                        bestSlot = i;
                    }
                }
            }
        }
        if (bestSlot != -1) {
            AutoTool.equip(bestSlot);
        }
    }

    public static double damage(final ItemStack stack){
        final double baseDamage = ((ItemSword) stack.getItem()).getDamageVsEntity();
        final double enchantmentBonus = EnchantmentHelper.getEnchantmentLevel(Enchantment.sharpness.effectId, stack) * 0.6000000238418579;
        return baseDamage + enchantmentBonus + 1.0;
    }
}
