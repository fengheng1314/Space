package Nirvana.hack.hacks;

import net.minecraft.network.play.client.C03PacketPlayer;

import java.util.List;
import java.util.Queue;

public class SFlight {
    public static Queue<C03PacketPlayer> packets;
    public static List<C03PacketPlayer> p;
}
