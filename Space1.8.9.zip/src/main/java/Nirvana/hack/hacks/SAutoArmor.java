package Nirvana.hack.hacks;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C0EPacketClickWindow;

public class SAutoArmor {
    public static int armorType(final ItemArmor item){
        return item.armorType;
    }

    public static boolean Instanceof(final Object packet){
        return packet instanceof C0EPacketClickWindow;
    }
    
    public static int armorToughness(final ItemArmor item, final ItemStack stack){
        return item.getMaxDamage() - item.getDamage(stack);
    }

    public static int armorType2(final ItemArmor item){
        return item.getArmorMaterial().getDamageReductionAmount(2);
    }

    public static Enchantment EnchantmentsPROTECTION(){
        return Enchantment.protection;
    }

    public static int prtLvl(final Enchantment protection, final ItemStack stack){
        return EnchantmentHelper.getEnchantmentLevel(protection.effectId, stack);
    }
}
