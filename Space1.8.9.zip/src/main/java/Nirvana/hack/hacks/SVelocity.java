package Nirvana.hack.hacks;

import net.minecraft.network.play.server.S12PacketEntityVelocity;

public class SVelocity {
    public static Object p = null;

    public static boolean Instanceof(final Object packet){
        boolean Return = packet instanceof S12PacketEntityVelocity;
        if (Return){
            p = packet;
        }
        return Return;
    }

    public static S12PacketEntityVelocity getSP(){
        return (S12PacketEntityVelocity) p;
    }
}
