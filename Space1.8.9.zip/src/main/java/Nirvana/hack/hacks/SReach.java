package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

import java.util.List;

public class SReach {
    public static MovingObjectPosition.MovingObjectType RayTraceResultTypeBLOCK(){
        return MovingObjectPosition.MovingObjectType.BLOCK;
    }
    
    public static MovingObjectPosition RayTraceResult(Object[] mouseOver){
        return new MovingObjectPosition((Entity)mouseOver[0], (Vec3)mouseOver[1]);
    }

    public static Object[] getMouseOver(final double Range, final double bbExpand) {
        final Entity renderViewEntity = Wrapper.mc().getRenderViewEntity();
        Entity entity = null;
        if (renderViewEntity == null || Wrapper.world() == null) {
            return null;
        }
        Wrapper.mc().mcProfiler.startSection("pick");
        final Vec3 positionEyes = renderViewEntity.getPositionEyes(0.0f);
        final Vec3 renderViewEntityLook = renderViewEntity.getLook(0.0f);
        final Vec3 vector = positionEyes.addVector(renderViewEntityLook.xCoord * Range, renderViewEntityLook.yCoord * Range, renderViewEntityLook.zCoord * Range);
        Vec3 ve = null;
        final List<Entity> entitiesWithinAABB = Wrapper.world().getEntitiesWithinAABBExcludingEntity(renderViewEntity, renderViewEntity.getEntityBoundingBox().expand(renderViewEntityLook.xCoord * Range, renderViewEntityLook.yCoord * Range, renderViewEntityLook.zCoord * Range).expand(1.0, 1.0, 1.0));
        double range = Range;
        for (final Entity e : entitiesWithinAABB) {
            if (e.canBeCollidedWith()) {
                final float size = e.getCollisionBorderSize();
                AxisAlignedBB bb = e.getEntityBoundingBox().expand(size, size, size);
                bb = bb.expand(bbExpand, bbExpand, bbExpand);
                final MovingObjectPosition objectPosition = bb.calculateIntercept(positionEyes, vector);
                if (bb.isVecInside(positionEyes)) {
                    if (0.0 < range || range == 0.0) {
                        entity = e;
                        ve = ((objectPosition == null) ? positionEyes : objectPosition.hitVec);
                        range = 0.0;
                    }
                } else if (objectPosition != null) {
                    final double v;
                    if ((v = positionEyes.distanceTo(objectPosition.hitVec)) < range || range == 0.0) {
                        if (e == renderViewEntity.ridingEntity) {
                            if (range == 0.0) {
                                entity = e;
                                ve = objectPosition.hitVec;
                            }
                        } else {
                            entity = e;
                            ve = objectPosition.hitVec;
                            range = v;
                        }
                    }
                }
            }
        }
        if (range < Range && !(entity instanceof EntityLivingBase) && !(entity instanceof EntityItemFrame)) {
            entity = null;
        }
        Wrapper.mc().mcProfiler.endSection();
        if (entity == null || ve == null) {
            return null;
        }
        return new Object[] { entity, ve };
    }

}
