package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import Space.hack.hacks.Visual.Xray;
import Space.utils.Utils;
import Space.utils.ui.RenderUtils;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraftforge.client.event.RenderWorldLastEvent;

import java.util.ArrayList;
import java.util.List;

public class SXray {
    public static List<BlockPos> ren;

    public static BlockPos p;

    public static Block IRON_ORE = Blocks.iron_ore;

    public static Block GOLD_ORE = Blocks.gold_ore;

    public static Block DIAMOND_ORE = Blocks.diamond_ore;

    public static Block EMERALD_ORE = Blocks.emerald_ore;

    public static Block LAPIS_ORE = Blocks.lapis_ore;

    public static Block REDSTONE_ORE = Blocks.redstone_ore;

    public static Block COAL_ORE = Blocks.coal_ore;

    public static Block MOB_SPAWNER = Blocks.mob_spawner;

    public static void NBlockPos(double x, double y, double z){
        SXray.p = new BlockPos(Wrapper.player().posX + x, Wrapper.player().posY + y, Wrapper.player().posZ + z);
    }

    public static void onRenderWorldLast(final RenderWorldLastEvent event) {
        if (Utils.isPlayerInGame() && !SXray.ren.isEmpty()) {
            List<BlockPos> tRen = new ArrayList<>(SXray.ren);

            for (BlockPos p : tRen) {
                dr(p);
            }
        }
    }

    private static void dr(BlockPos p) {
        int[] rgb = Xray.c(Wrapper.world().getBlockState(p).getBlock());
        if (rgb[0] + rgb[1] + rgb[2] != 0) {
            RenderUtils.drawBlockESP(p, rgb[0], rgb[1], rgb[2]);
        }

    }
}
