package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

import java.text.DecimalFormat;

public class SHudNSDEnemyInfo {
    public static String Distanse(EntityPlayer Target){
        final DecimalFormat decimalFormat = new DecimalFormat("###.#");
        return decimalFormat.format(Target.getDistanceToEntity(Wrapper.player()));
    }

    public static ResourceLocation drawHead(EntityPlayer Target){
        AbstractClientPlayer abstractPlayer = (AbstractClientPlayer) Target;
        return abstractPlayer.getLocationSkin();
    }
}
