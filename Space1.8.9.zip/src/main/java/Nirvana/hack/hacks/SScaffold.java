package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import Nirvana.utils.BlockUtils;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;

public class SScaffold {
    public static BlockPos blockDown;

    public static BlockPos blockpos;

    public static BlockPos blockpos1;

    public static BlockPos Off(){
        return new BlockPos(Wrapper.player()).down();
    }
    
    public static BlockPos onRenderWorldLast(){
        return (new BlockPos(Wrapper.player())).down();
    }

    public static int findSlotWithBlock() {
        for (int i = 0; i < 9; ++i) {
            ItemStack itemstack = Wrapper.inventory().getStackInSlot(i);

            if (itemstack != null && itemstack.getItem() instanceof ItemBlock) {
                Block block = Block.getBlockFromItem(itemstack.getItem()).getDefaultState().getBlock();

                if (block.isFullBlock() && block != Blocks.sand && block != Blocks.gravel) {
                    return i;
                }
            }
        }

        return -1;
    }

    public static boolean Material(){
        return !BlockUtils.getBlock(SScaffold.blockDown).getMaterial().isReplaceable();
    }
}
