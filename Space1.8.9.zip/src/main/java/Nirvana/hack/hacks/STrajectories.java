package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import Nirvana.utils.SUtils;
import net.minecraft.item.*;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class STrajectories {
    public static Vec3 playerVector = null;

    public static AxisAlignedBB bb = null;

    public static double arrowPosX(final RenderWorldLastEvent event, final float yawAim){
        return Wrapper.player().lastTickPosX + (Wrapper.player().posX - Wrapper.player().lastTickPosX) * SUtils.getPartialTicks(event) - MathHelper.cos((float)Math.toRadians(yawAim)) * 0.16f;
    }

    public static double arrowPosZ(final RenderWorldLastEvent event, final float yawAim){
        return Wrapper.player().lastTickPosZ + (Wrapper.player().posZ - Wrapper.player().lastTickPosZ) * SUtils.getPartialTicks(event) - MathHelper.sin((float)Math.toRadians(yawAim)) * 0.16f;
    }

    public static float arrowMotionX(float yaw, float pitch, float arrowMotionFactor){
        return -MathHelper.sin(yaw) * MathHelper.cos(pitch) * arrowMotionFactor;
    }

    public static double arrowPosY(final RenderWorldLastEvent event){
        return Wrapper.player().lastTickPosY + (Wrapper.player().posY - Wrapper.player().lastTickPosY) * SUtils.getPartialTicks(event) + Wrapper.player().getEyeHeight() - 0.1;
    }

    public static float arrowMotionY(float pitch, float arrowMotionFactor){
        return -MathHelper.sin(pitch) * arrowMotionFactor;
    }

    public static float arrowMotionZ(float yaw, float pitch, float arrowMotionFactor){
        return MathHelper.cos(yaw) * MathHelper.cos(pitch) * arrowMotionFactor;
    }

    public static void AxisAlignedBB(double renderX, double renderY, double renderZ){
        bb = new AxisAlignedBB(renderX - 0.5, renderY - 0.5, renderZ - 0.5, renderX + 0.5, renderY + 0.5, renderZ + 0.5);
    }

    public static void playerVector(){
        playerVector = new Vec3(Wrapper.player().posX, Wrapper.player().posY + Wrapper.player().getEyeHeight(), Wrapper.player().posZ);
    }

    public static Vec3 Vec3d(double arrowPosX, double arrowPosY, double arrowPosZ){
        return new Vec3(arrowPosX, arrowPosY, arrowPosZ);
    }

    public static boolean sd(final Item item){
        return !(item instanceof ItemBow || item instanceof ItemSnowball || item instanceof ItemEgg || item instanceof ItemEnderPearl || item instanceof ItemPotion || item instanceof ItemFishingRod);
    }

}
