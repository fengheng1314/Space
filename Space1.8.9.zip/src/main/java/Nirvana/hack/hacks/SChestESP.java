package Nirvana.hack.hacks;

public class SChestESP {
    public static int BlockChestTypeTRAP(){
        return 1;
    }
}
