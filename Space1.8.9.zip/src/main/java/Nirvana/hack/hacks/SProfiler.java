package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import Space.hack.hacks.Visual.Profiler;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;

public class SProfiler {
    public static RenderItem renderItem = null;

    public static void renderItem(){
        renderItem = Wrapper.mc().getRenderItem();
    }
    
    public static Profiler.EnchantEntry[] enchants(){
        return new Profiler.EnchantEntry[]{new Profiler.EnchantEntry(Enchantment.protection, "Pro"), new Profiler.EnchantEntry(Enchantment.thorns, "Th"), new Profiler.EnchantEntry(Enchantment.sharpness, "Shar"), new Profiler.EnchantEntry(Enchantment.fireAspect, "Fire"), new Profiler.EnchantEntry(Enchantment.knockback, "Kb"), new Profiler.EnchantEntry(Enchantment.unbreaking, "Unb"), new Profiler.EnchantEntry(Enchantment.power, "Pow"), new Profiler.EnchantEntry(Enchantment.infinity, "Inf"), new Profiler.EnchantEntry(Enchantment.punch, "Punch")};
    }

    public static float distance(Entity entity){
        return Wrapper.getDistance(entity) / 4.0f;
    }

    public static ItemStack inHand(){
        return Wrapper.player().inventory.getCurrentItem();
    }

    public static int level(final Profiler.EnchantEntry enchant, final ItemStack stack) {
        return EnchantmentHelper.getEnchantmentLevel(enchant.getEnchant().effectId, stack);
    }
}
