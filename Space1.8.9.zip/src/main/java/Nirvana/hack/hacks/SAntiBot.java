package Nirvana.hack.hacks;

import Nirvana.utils.BlockUtils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;

public class SAntiBot {
    public static boolean InAir(final EntityPlayer bot){
        return BlockUtils.isBlockMaterial(new BlockPos(bot).down());
    }

    public static boolean Armor(final EntityPlayer bot){
        return bot.inventory.armorInventory[0] == null && bot.inventory.armorInventory[1] == null
                && bot.inventory.armorInventory[2] == null && bot.inventory.armorInventory[3] == null;
    }

    public static boolean collidedVertically(final EntityPlayer bot){
        return !bot.isCollidedVertically;
    }
}
