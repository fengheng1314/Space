package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.item.ItemStack;

public class SHudNSDArmorHUD {
    public static RenderItem itemRender = null;
    
    public static void itemRender(){
        itemRender = Wrapper.mc().getRenderItem();
    }
    
    public static String Strings(final ItemStack is){
        final String s;
        if (is.stackSize > 1) {
            s = Integer.toString(is.stackSize);
        } else {
            s = "";
        }
        return s;
    }
}
