package Nirvana.hack.hacks;

import Nirvana.Wrapper;
import Nirvana.hack.Hack;
import Nirvana.managers.HackManager;
import Nirvana.utils.Connection;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

import java.lang.reflect.Field;

public class SNoFall {
    public static void CPacketPlayer(){
        Wrapper.sendPacket(new C03PacketPlayer(true));
    }

    public static boolean onPacket(final Object packet, final Connection.Side side){
        if (side == Connection.Side.OUT && packet instanceof C03PacketPlayer) {
            final C03PacketPlayer p = (C03PacketPlayer)packet;
            final Hack hack = HackManager.getHack("AntiBot");
            if (hack.onToggledMode("Mode").equals("AAC")) {
                final Field field = ReflectionHelper.findField(C03PacketPlayer.class, "onGround", "field_149474_g");
                try {
                    if (!field.isAccessible()) {
                        field.setAccessible(true);
                    }
                    field.setBoolean(p, true);
                }
                catch (Exception ignored) {}
            }
        }
        return true;
    }
}
