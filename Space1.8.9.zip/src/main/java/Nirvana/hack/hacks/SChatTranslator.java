package Nirvana.hack.hacks;

import net.minecraft.network.play.server.S02PacketChat;

public class SChatTranslator {
    public static boolean Instanceof(final Object packet){
        return packet instanceof S02PacketChat;
    }
    
    public static String getmsg(final Object packet){
        return ((S02PacketChat) packet).getChatComponent().getFormattedText();
    }
}
