package Nirvana.hack.hacks;

import Nirvana.utils.Connection;
import net.minecraft.network.play.server.S30PacketWindowItems;

public class SChestStealer {
    public static S30PacketWindowItems packet;

    public static boolean onPacket(final Object packet, final Connection.Side side){
        if (side == Connection.Side.IN && packet instanceof S30PacketWindowItems) {
            SChestStealer.packet = (S30PacketWindowItems)packet;
        }
        return true;
    }

    public static int QUICK_MOVE(){
        return 1;
    }

    public static int getWindowId(){
        return SChestStealer.packet.func_148911_c();
    }
}
