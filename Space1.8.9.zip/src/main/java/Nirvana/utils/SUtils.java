package Nirvana.utils;

import Nirvana.Wrapper;
import Space.utils.Mapping;
import Space.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;

import java.lang.reflect.Field;

public class SUtils {

    public static BlockPos EventPos(final Object event){
        if (event instanceof PlayerInteractEvent) {
            return ((PlayerInteractEvent) event).pos;
        }
        return null;
    }

    public static boolean AttackCooldown(){
        return Wrapper.player().isSwingInProgress && Wrapper.player().swingProgressInt == 0;
    }

    public static float getPartialTicks(final RenderWorldLastEvent event){
        return event.partialTicks;
    }

    public static Entity getTarget(final AttackEntityEvent event){
        return event.target;
    }

    public static float getPitch(final Entity entity) {
        double y = entity.posY - Wrapper.player().posY;
        y /= Wrapper.player().getDistanceSqToEntity(entity);
        double pitch = Math.asin(y) * 57.29577951308232;
        pitch = -pitch;
        return (float) pitch;
    }

    public static float[] getTargetRotations(Entity q) {
        if (q == null) {
            return null;
        } else {
            double diffX = q.posX - Wrapper.player().posX;
            double diffY;
            if (q instanceof EntityLivingBase) {
                EntityLivingBase en = (EntityLivingBase) q;
                diffY = en.posY + (double) en.getEyeHeight() * 0.9D - (Wrapper.player().posY + (double) Wrapper.player().getEyeHeight());
            } else {
                diffY = (q.getEntityBoundingBox().minY + q.getEntityBoundingBox().maxY) / 2.0D - (Wrapper.player().posY + (double) Wrapper.player().getEyeHeight());
            }

            double diffZ = q.posZ - Wrapper.player().posZ;
            double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);
            float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / 3.141592653589793D) - 90.0F;
            float pitch = (float) (-(Math.atan2(diffY, dist) * 180.0D / 3.141592653589793D));
            return new float[]{Wrapper.player().rotationYaw + Utils.wrapAngleTo180_float(yaw - Wrapper.player().rotationYaw),
                    Wrapper.player().rotationPitch + Utils.wrapAngleTo180_float(pitch - Wrapper.player().rotationPitch)};
        }
    }

    public static boolean placeBlockScaffold(BlockPos pos) {
        Vec3 eyesPos = new Vec3(Wrapper.player().posX, Wrapper.player().posY + (double) Wrapper.player().getEyeHeight(), Wrapper.player().posZ);
        EnumFacing[] values;
        int length = (values = EnumFacing.values()).length;

        for (int i = 0; i < length; ++i) {
            EnumFacing side = values[i];
            BlockPos neighbor = pos.offset(side);
            EnumFacing side2 = side.getOpposite();

            if (eyesPos.squareDistanceTo((new Vec3(pos)).addVector(0.5D, 0.5D, 0.5D)) < eyesPos.squareDistanceTo((new Vec3(neighbor)).addVector(0.5D, 0.5D, 0.5D)) && canBeClicked(neighbor)) {
                Vec3 hitVec = (new Vec3(neighbor)).addVector(0.5D, 0.5D, 0.5D).add(new Vec3(side2.getDirectionVec()));

                if (eyesPos.squareDistanceTo(hitVec) <= 18.0625D) {
                    faceVectorPacketInstant(hitVec);
                    swingMainHand();
                    Wrapper.mc().playerController.onPlayerRightClick(Wrapper.player(), Wrapper.world(), Wrapper.player().getItemInUse(), neighbor, side2, hitVec);

                    try {
                        Field e = Minecraft.class.getDeclaredField(Mapping.rightClickDelayTimer);

                        e.setAccessible(true);
                        e.set(Wrapper.mc(), 4);
                    } catch (Exception exception) {
                        exception.printStackTrace();
                    }

                    return true;
                }
            }
        }

        return false;
    }

    public static void faceVectorPacketInstant(final Vec3 vec) {
        Utils.rotationsToBlock = getNeededRotations(vec);
    }

    public static boolean canBeClicked(final BlockPos pos) {
        return BlockUtils.getBlock(pos).canCollideCheck(BlockUtils.getState(pos), false);
    }

    public static void swing() {
        EntityPlayerSP p = Wrapper.player();
        int armSwingEnd = p.isPotionActive(Potion.digSpeed) ? 6 - (1 + p.getActivePotionEffect(Potion.digSpeed).getAmplifier()) : (p.isPotionActive(Potion.digSlowdown) ? 6 + (1 + p.getActivePotionEffect(Potion.digSlowdown).getAmplifier()) * 2 : 6);
        if (!p.isSwingInProgress || p.swingProgressInt >= armSwingEnd / 2 || p.swingProgressInt < 0) {
            p.swingProgressInt = -1;
            p.isSwingInProgress = true;
        }
    }

    public static float updateRotation(final float angle, final float targetAngle, final float maxIncrease) {
        float var4 = MathHelper.wrapAngleTo180_float(targetAngle - angle);
        if (var4 > maxIncrease) {
            var4 = maxIncrease;
        }
        if (var4 < -maxIncrease) {
            var4 = -maxIncrease;
        }
        return angle + var4;
    }

    public static int getDistanceFromMouse(final EntityLivingBase entity) {
        final float[] neededRotations = getRotationsNeeded(entity);
        if (neededRotations != null) {
            final float neededYaw = Wrapper.player().rotationYaw - neededRotations[0];
            final float neededPitch = Wrapper.player().rotationPitch - neededRotations[1];
            final float distanceFromMouse = (float) Math.sqrt(neededYaw * neededYaw + neededPitch * neededPitch * 2.0f);
            return (int)distanceFromMouse;
        }
        return -1;
    }

    public static float[] getNeededRotations(Vec3 vec) {
        Vec3 eyesPos = getEyesPos();
        double diffX = vec.xCoord - eyesPos.xCoord;
        double diffY = vec.yCoord - eyesPos.yCoord;
        double diffZ = vec.zCoord - eyesPos.zCoord;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
        float pitch = (float) (-Math.toDegrees(Math.atan2(diffY, diffXZ)));

        return new float[] { Wrapper.player().rotationYaw + MathHelper.wrapAngleTo180_float(yaw - Wrapper.player().rotationYaw), Wrapper.player().rotationPitch + MathHelper.wrapAngleTo180_float(pitch - Wrapper.player().rotationPitch)};
    }

    public static float[] getRotationsNeeded(final Entity entity) {
        if (entity == null) {
            return null;
        }
        final double diffX = entity.posX - Wrapper.player().posX;
        final double diffZ = entity.posZ - Wrapper.player().posZ;
        double diffY;
        if (entity instanceof EntityLivingBase) {
            final EntityLivingBase entityLivingBase = (EntityLivingBase)entity;
            diffY = entityLivingBase.posY + entityLivingBase.getEyeHeight() - (Wrapper.player().posY + Wrapper.player().getEyeHeight());
        }
        else {
            diffY = (entity.getEntityBoundingBox().minY + entity.getEntityBoundingBox().maxY) / 2.0 - (Wrapper.player().posY + Wrapper.player().getEyeHeight());
        }
        final double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        final float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 90.0f;
        final float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / 3.141592653589793));
        return new float[] { Wrapper.player().rotationYaw + MathHelper.wrapAngleTo180_float(yaw - Wrapper.player().rotationYaw), Wrapper.player().rotationPitch + MathHelper.wrapAngleTo180_float(pitch - Wrapper.player().rotationPitch) };
    }

    public static Vec3 getEyesPos() {
        return new Vec3(Wrapper.player().posX, Wrapper.player().posY + (double) Wrapper.player().getEyeHeight(), Wrapper.player().posZ);
    }

    public static void swingMainHand() {
        Wrapper.player().swingItem();
    }

    public static void windowClick(final int windowId, final int slotId, final int mouseButton, final Object type) {
        Wrapper.controller().windowClick(windowId, slotId, mouseButton, (Integer) type, Wrapper.player());
    }

    public static void removeEffect(final int id) {
        Potion potion = getPotionById(id);
        if (potion != null) {
            Wrapper.player().removePotionEffect(potion.getId());
        }
    }

    private static Potion getPotionById(int id) {
        for (Potion potion : Potion.potionTypes) {
            if (potion != null && potion.getId() == id) {
                return potion;
            }
        }
        return null;
    }

    public static void addEffect(final int id, final int duration, final int amplifier) {
        Potion potion = getPotionById(id);
        if (potion != null) {
            Wrapper.player().addPotionEffect(new PotionEffect(id, duration, amplifier));
        }
    }
}
