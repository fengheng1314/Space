package Nirvana.utils;

import Nirvana.Wrapper;
import net.minecraft.entity.EntityLivingBase;

public class SValidUtils
{
    public static boolean AttacksProhibited(final EntityLivingBase entity) {
        return entity.getDistanceToEntity(Wrapper.player()) > 0.4;
    }

    public static boolean isRange(final EntityLivingBase entity, final EntityLivingBase entityPriority) {
        return entityPriority == null || Wrapper.player().getDistanceToEntity(entity) < Wrapper.player().getDistanceToEntity(entityPriority);
    }

    public static boolean isInAttackRange(final EntityLivingBase entity, final double range) {
        return entity.getDistanceToEntity(Wrapper.player()) <= range;
    }

}
