package Nirvana.utils;

import Nirvana.Wrapper;
import Space.utils.Mapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.WorldSettings;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

public class PlayerControllerUtils
{
    public static void setReach(final Entity entity, final double range) {
        final Minecraft mc = Wrapper.mc();
        final EntityPlayer player = Wrapper.player();
        if (player == entity) {
            class RangePlayerController extends PlayerControllerMP
            {
                private float range;
                
                public RangePlayerController(final Minecraft mcIn, final NetHandlerPlayClient netHandler) {
                    super(mcIn, netHandler);
                    this.range = 3f;
                }
                
                public float getBlockReachDistance() {
                    return this.range;
                }
                
                public void setBlockReachDistance(final float range) {
                    this.range = range;
                }
            }
            if (!(Wrapper.mc().playerController instanceof RangePlayerController)) {
                final WorldSettings.GameType gameType = ReflectionHelper.getPrivateValue(PlayerControllerMP.class, Wrapper.mc().playerController, new String[] { Mapping.currentGameType });
                final NetHandlerPlayClient netClient = ReflectionHelper.getPrivateValue(PlayerControllerMP.class,Wrapper.mc().playerController, new String[] { Mapping.connection });
                final RangePlayerController controller = new RangePlayerController(mc, netClient);
                final boolean isFlying = player.capabilities.isFlying;
                final boolean allowFlying = player.capabilities.allowFlying;
                controller.setGameType(gameType);
                player.capabilities.isFlying = isFlying;
                player.capabilities.allowFlying = allowFlying;
                Wrapper.mc().playerController = controller;
            }
            ((RangePlayerController)Wrapper.mc().playerController).setBlockReachDistance((float)range);
        }
    }

}
