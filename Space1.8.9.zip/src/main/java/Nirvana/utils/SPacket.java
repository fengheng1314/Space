package Nirvana.utils;

import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0BPacketEntityAction;

public class SPacket {
    public static C0BPacketEntityAction CPacketEntityAction(Entity entityIn, C0BPacketEntityAction.Action actionIn){
        return new C0BPacketEntityAction(entityIn, actionIn);
    }

    public static C02PacketUseEntity CPacketUseEntity(Entity entityIn){
        return new C02PacketUseEntity(entityIn, C02PacketUseEntity.Action.ATTACK);
    }

    public static C03PacketPlayer.C06PacketPlayerPosLook CPacketPlayerPositionRotation(double posX, double minY, double posZ, float submitYaw, float submitPitch, boolean onGround){
        return new C03PacketPlayer.C06PacketPlayerPosLook(posX, minY, posZ, submitYaw, submitPitch, onGround);
    }

    public static C03PacketPlayer.C04PacketPlayerPosition CPacketPlayerPosition(double xIn, double yIn, double zIn, boolean onGroundIn){
        return new C03PacketPlayer.C04PacketPlayerPosition(xIn, yIn, zIn, onGroundIn);
    }

    public static C0BPacketEntityAction.Action CPacketEntityAction_STOP_SPRINTING(){
        return C0BPacketEntityAction.Action.STOP_SPRINTING;
    }

    public static C0BPacketEntityAction.Action CPacketEntityActionSTOP_SNEAKING(){
        return C0BPacketEntityAction.Action.STOP_SNEAKING;
    }

    public static C0BPacketEntityAction.Action CPacketEntityActionSTART_SNEAKING(){
        return C0BPacketEntityAction.Action.START_SNEAKING;
    }

    public static C0BPacketEntityAction.Action CPacketEntityAction_START_SPRINTING(){
        return C0BPacketEntityAction.Action.START_SPRINTING;
    }

    public static C0BPacketEntityAction.Action CPacketEntityAction_STOP_SNEAKING(){
        return C0BPacketEntityAction.Action.STOP_SNEAKING;
    }

    public static C0BPacketEntityAction.Action CPacketEntityAction_START_SNEAKING(){
        return C0BPacketEntityAction.Action.START_SNEAKING;
    }


}
