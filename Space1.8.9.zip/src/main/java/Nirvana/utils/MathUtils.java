package Nirvana.utils;

import net.minecraft.util.MathHelper;

public class MathUtils
{
    public static int getMiddle(final int i, final int j) {
        return (i + j) / 2;
    }

    public static float sin(final float value) {
        return MathHelper.sin(value);
    }

    public static float cos(final float value) {
        return MathHelper.cos(value);
    }

}
