package Nirvana;

import Nirvana.hack.Hack;
import Nirvana.managers.HackManager;
import Nirvana.utils.Connection;
import Space.BenCore;
import Space.utils.Utils;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraftforge.client.event.*;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class EventsHandler {
    private boolean initialized;
    public String map;
    public WorldClient upworld;

    public EventsHandler() {
        this.initialized = false;
        this.map = "";
        this.upworld = null;
    }

    @SubscribeEvent
    public void onKeyInput(final InputEvent.KeyInputEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            final int key = BenCore.getEventKey();
            if (key == 0 || key == -1) {
                return;
            }
            if (BenCore.getEventKeyState()) {
                for (final Hack hack : HackManager.getHacks()) {
                    if (hack.getKey() == key) {
                        hack.toggle();
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    public boolean onPacket(final Object packet, final Connection.Side side) {
        boolean suc = true;
        for (final Hack hack : HackManager.getHacks()) {
            if (hack.isToggled()) {
                if (Wrapper.world() == null) {
                    continue;
                }
                suc &= hack.onPacket(packet, side);
            }
        }
        return suc;
    }

    @SubscribeEvent
    public void onCameraSetup(final EntityViewRenderEvent.CameraSetup event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onCameraSetup(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (Utils.nullCheck()) {

            this.initialized = false;
            return;
        }
        try {
            if (!this.initialized) {
                new Connection(this);
                this.initialized = true;
            }
            if (!Wrapper.world().equals(this.upworld)) {
                this.upworld = Wrapper.world();
                this.map = "";
            }
            HackManager.onClientTick(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onLeftClickBlock(final PlayerInteractEvent event) {
        if (event.action != event.action.LEFT_CLICK_BLOCK || event.isCanceled()) {
            return;
        }
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onLeftClickBlock(event);
        } catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onRightClickItem(final PlayerInteractEvent event) {
        if (event.action != event.action.RIGHT_CLICK_AIR && event.action != event.action.RIGHT_CLICK_BLOCK || event.isCanceled()) {
            return;
        }
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onRightClickItem(event);
        } catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onRenderGameOverlay(final RenderGameOverlayEvent.Text event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onRenderGameOverlay(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onMouse(final MouseEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onMouse(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onAttackEntity(final AttackEntityEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onAttackEntity(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onInputUpdateEvent(final TickEvent.PlayerTickEvent event) {
        if (event.phase != event.phase.START || Utils.nullCheck() || event.player != Wrapper.player()) {
            return;
        }
        try {
            HackManager.onInputUpdate(event);
        } catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onLivingUpdate(final LivingEvent.LivingUpdateEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onLivingUpdate(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onPlayerMove(PlayerEvent.LivingUpdateEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onPlayerMove(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onRenderWorldLast(final RenderWorldLastEvent event) {
        if (Utils.nullCheck() || Wrapper.mc().gameSettings.hideGUI) {
            return;
        }
        try {
            HackManager.onRenderWorldLast(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            HackManager.onPlayerTick(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }

    @SubscribeEvent
    public void onRender3D(final RenderBlockOverlayEvent event) {
        if (Wrapper.mc().gameSettings.hideGUI) {
            return;
        }
        try {
            HackManager.onRender3D(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }

}
